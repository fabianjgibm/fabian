<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
        }
        .loginNregister {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff; /* White background for form */
            padding: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Light shadow */
        }
        .loginNregister h2 {
            margin-bottom: 20px;
            font-weight: bold;
            text-align: center;
            color: #343a40; /* Dark gray text */
        }
        .loginNregister label {
            font-weight: 500;
        }
        .loginNregister input[type="text"], 
        .loginNregister input[type="email"], 
        .loginNregister input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
        .loginNregister button {
            width: 100%;
            padding: 10px;
            background-color: #fd7e14; /* Bootstrap warning color */
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .loginNregister button:hover {
            background-color: #e67600; /* Darker orange on hover */
        }
        .loginNregister a {
            display: block;
            text-align: center;
            margin-top: 20px;
            color: #fd7e14; /* Matching link color */
            text-decoration: none;
            font-weight: bold;
        }
        .loginNregister a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php include 'navbar2.php'; ?>
    <div class="loginNregister" id="register">
        <h2>Register</h2>
        <?php
            $messages = [
                'success' => 'success',
                'failed1' => 'failed1',
                'failed2' => 'failed2',
            ];

            // Loop through the messages array to display alerts
            foreach ($messages as $key => $value) {
                if (isset($_SESSION[$value])): ?>
                    <div class="alert alert-<?php echo $key === 'success' ? 'success' : 'danger'; ?> d-flex justify-content-between align-items-center" role="alert">
                        <span>
                            <?php 
                            echo $_SESSION[$value]; 
                            unset($_SESSION[$value]); // Clear the message after displaying
                            ?>
                        </span>
                        <?php if ($key === 'success'): ?>
                            <a href="login.php" class="btn btn-primary btn-sm">Go to Login</a>
                        <?php endif; ?>
                    </div>
                <?php endif; 
            }
            ?>

        <form method="POST" action="logics/registerL.php">
            <label for="Fname">First Name</label>
            <input type="text" id="Fname" name="Fname" placeholder="First Name" pattern="[A-Za-z]+" required 
            title="Please enter letters only">
            
            <label for="Lname">Last Name</label>
            <input type="text" id="Lname" name="Lname" placeholder="Last Name" pattern="[A-Za-z]+" required 
            title="Please enter letters only">
            
            <label for="email">Email</label>
            <input type="email" id="email" name="email" placeholder="Email" required>
            
            <label for="pass">Password</label>
            <input type="password" id="pass" name="pass" placeholder="Password" 
            pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" 
            title="Password must be at least 8 characters long, and contain one uppercase letter, one lowercase letter, one digit, and one special character" 
            required>
            
            <label for="Mnum">Mobile Number</label>
            <input type="text" id="Mnum" name="Mnum" placeholder="Mobile Number" 
            pattern="09\d{9}" title="Please enter an 11-digit phone number starting with '09'" required>
            
            <button type="submit">Create</button>
            <a href="login.php">Back to login</a>
        </form>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>