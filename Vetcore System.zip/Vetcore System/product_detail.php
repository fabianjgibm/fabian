<?php
require "logics/sqlcon.php";
session_start();
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: login.php");
    exit();
}

if (!isset($_GET['id'])) {
    header("Location: order.php");
    exit();
}

$product_id = $_GET['id'];

// Fetch product details based on the product ID
$sql = "SELECT product.*, 
            COALESCE(SUM(CASE 
                WHEN product_detail.expiration_date > CURRENT_DATE 
                    OR product_detail.expiration_date IS NULL 
                    OR product_detail.expiration_date = '0000-00-00' 
                THEN product_detail.remaining_stock 
                ELSE 0 
            END), 0) AS stock
        FROM product
        LEFT JOIN product_detail ON product.id = product_detail.product_id
        WHERE product.id = :id
        GROUP BY product.id";

$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $product_id]);
$product = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$product) {
    echo "Product not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title><?php echo htmlspecialchars($product['name']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* General styling */
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .product-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 86px;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }
        .product-image {
            width: 45%;
        }
        .product-image img {
            border-radius: 10px;
            width: 100%;
            height: auto;
            object-fit: cover;
        }
        .product-details {
            width: 50%;
            padding-left: 30px;
        }
        .product-details h2 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: #333;
        }
        .product-details p {
            font-size: 1.2rem;
            color: #555;
            margin-bottom: 15px;
        }
        .price {
            font-weight: bold;
            font-size: 1.5rem;
            color: #007bff;
        }
        .quantity-input {
            display: flex;
            align-items: center;
            margin: 20px 0;
            margin-top: 100px;
        }
        .quantity-input button {
            width: 40px;
            height: 40px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 50%;
            font-size: 1.5rem;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }
        .quantity-input button:hover {
            background-color: #0056b3;
        }
        .quantity-input input {
            width: 60px;
            height: 40px;
            text-align: center;
            font-size: 1.2rem;
            margin: 0 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .btn-primary {
            background-color: #28a745;
            border: none;
            padding: 12px 20px;
            font-size: 1.2rem;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #218838;
        }
        .text-danger {
            font-weight: bold;
            color: #dc3545;
        }
        .t3{
            margin-top: 20px;
            margin-left: 20px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="container">
        <div class="product-container">
            <div class="product-image">
                <img src="data:image/jpeg;base64,<?php echo base64_encode($product['image']); ?>" alt="Product Image" class="img-fluid">
            </div>

            <!-- Details section -->
            <div class="product-details">
                <h2><?php echo htmlspecialchars($product['name']); ?></h2>
                <p class="price">Price: PHP <?php echo number_format($product['price'], 2); ?></p>
                <p>Available Stock: <?php echo $product['stock'] > 0 ? $product['stock'] : '<span class="text-danger">Out of stock</span>'; ?></p>

                <?php if ($product['stock'] > 0): ?>
                    <form method="POST" action="logics/cartL.php">
                        <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                        <input type="hidden" name="price" value="<?php echo $product['price']; ?>">

                        <div class="quantity-input">
                            <button type="button" class="btn btn-secondary" id="decrease">-</button>
                            <input type="number" name="quantity" id="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>" class="form-control">
                            <button type="button" class="btn btn-secondary" id="increase">+</button>
                        </div>

                        <button type="submit" name="addToCart" class="btn btn-primary">Add to Cart</button>
                    </form>
                <?php else: ?>
                    <p class="text-danger">OUT OF STOCK</p>
                <?php endif; ?>
                <a href="order.php" class="btn btn-primary t3">Cancel</a>
            </div>
        </div>
    </div>

    <script>
    document.getElementById('decrease').addEventListener('click', function() {
        let quantity = document.getElementById('quantity');
        if (quantity.value > 1) {
            quantity.value--;
        }
    });

    document.getElementById('increase').addEventListener('click', function() {
        let quantity = document.getElementById('quantity');
        if (quantity.value < <?php echo $product['stock']; ?>) {
            quantity.value++;
        }
    });
    </script>
</body>
</html>
