<?php
require 'logics/sqlcon.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['U_id'];

// Retrieve vaccinations grouped by upcoming, missed, and today's vaccination
$sql_today = "SELECT pd.pet_name, pd.pet_image, pd.schedule 
        FROM pet_details AS pd 
        WHERE pd.schedule = CURDATE() AND pd.owner_id = :owner_id"; // Today's schedule
$stmt_today = $conn->prepare($sql_today);
$stmt_today->execute([':owner_id' => $user_id]);
$todays_vaccinations = $stmt_today->fetchAll(PDO::FETCH_ASSOC);

$sql_missed = "SELECT pd.pet_name, pd.pet_image, pd.schedule 
        FROM pet_details AS pd 
        WHERE pd.schedule < CURDATE() AND pd.owner_id = :owner_id"; // Missed schedules
$stmt_missed = $conn->prepare($sql_missed);
$stmt_missed->execute([':owner_id' => $user_id]);
$missed_vaccinations = $stmt_missed->fetchAll(PDO::FETCH_ASSOC);

$sql_upcoming = "SELECT pd.pet_name, pd.pet_image, pd.schedule 
        FROM pet_details AS pd 
        WHERE pd.schedule > CURDATE() AND pd.owner_id = :owner_id"; // Upcoming schedules
$stmt_upcoming = $conn->prepare($sql_upcoming);
$stmt_upcoming->execute([':owner_id' => $user_id]);
$upcoming_vaccinations = $stmt_upcoming->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Vaccination Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .t1{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 100px;
            height: 47px;
        }
        .t2, .t3, .t4 {
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: white;
            border-radius: 8px;
            width: 300px;
            height: 47px;
            margin: 0 auto;
        }
        .bg {
            background-color: white;
            border-radius: 5px;
        }
        .hidden {
            display: none;
        }
        .btn-custom {
            width: 150px; /* Set a fixed width */
            height: 50px; /* Set a fixed height */
            font-size: 1.2em; /* Set font size */
            margin: 5px; /* Add some margin */
        }
        .sz{
            width: 500px;
            margin-left: 26%;
            text-align: center;
            margin: 0 auto;
        }
    </style>
    <script>
        function showSection(section) {
            document.querySelectorAll('.vaccination-section').forEach(function(el) {
                el.classList.add('hidden');
            });
            document.getElementById(section).classList.remove('hidden');
        }
    </script>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container mt-5">
        <h1 class="t1">Vaccination Schedule</h1>
        <div class="text-center mb-4">
            <button class="btn btn-success btn-custom" onclick="showSection('upcoming')">Upcoming</button>
            <button class="btn btn-warning btn-custom" onclick="showSection('today')">Today</button>
            <button class="btn btn-danger btn-custom" onclick="showSection('missed')">Missed</button>
        </div>

        <div class="row text-center">
            <!-- Upcoming Vaccinations Section -->
            <div id="upcoming" class="vaccination-section">
                <h3 class="t2 text-success">Upcoming</h3>
                <?php if ($upcoming_vaccinations): ?>
                    <div class="list-group sz">
                        <?php foreach ($upcoming_vaccinations as $vaccination): ?>
                            <div class="list-group-item">
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle" style="width: 100px; height: 100px; margin-bottom: 10px;">
                                <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                <p>Scheduled for <?php echo (new DateTime($vaccination['schedule']))->format('F j, Y'); ?>.</p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="bg">No upcoming vaccinations.</p>
                <?php endif; ?>
            </div>

            <!-- Today's Vaccinations Section -->
            <div id="today" class="vaccination-section hidden">
                <h3 class="t3 text-warning">Today</h3>
                <?php if ($todays_vaccinations): ?>
                    <div class="list-group sz">
                        <?php foreach ($todays_vaccinations as $vaccination): ?>
                            <div class="list-group-item">
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle" style="width: 100px; height: 100px; margin-bottom: 10px;">
                                <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                <p>You have a vaccination scheduled today.</p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="bg">No vaccinations scheduled for today.</p>
                <?php endif; ?>
            </div>

            <!-- Missed Vaccinations Section -->
            <div id="missed" class="vaccination-section hidden">
                <h3 class="t4 text-danger">Missed</h3>
                <?php if ($missed_vaccinations): ?>
                    <div class="list-group sz">
                        <?php foreach ($missed_vaccinations as $vaccination): ?>
                            <div class="list-group-item">
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle" style="width: 100px; height: 100px; margin-bottom: 10px;">
                                <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                <p>Missed on <?php echo (new DateTime($vaccination['schedule']))->format('F j, Y'); ?>.</p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="bg">No missed vaccinations.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
