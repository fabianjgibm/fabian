<?php
require "logics/sqlcon.php";
session_start();

// Fetch categories from the database
$category_sql = "SELECT DISTINCT category FROM product";
$category_result = $conn->query($category_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">    
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .title1 {
            text-align: center;
            margin-top: 20px;
            font-size: 2rem;
            color: white;
            background-color: #28a745;
            border-radius: 8px;
        }
        .div001 {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            width: 250px;
            background-color: #f8f9fa;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .product-card:hover {
            transform: scale(1.05);
        }
        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .product-title {
            font-size: 1.1rem;
            margin-top: 10px;
            color: #333;
            font-weight: bold;
        }
        .product-price {
            margin-top: 5px;
            font-size: 1.2rem;
            color: #f76c6c;
            font-weight: bold;
        }
        .stock {
            margin-top: 5px;
            font-size: 0.9rem;
            color: #555;
        }
        .sidebar {
            padding-right: 15px;
            margin-right: 20px;
        }
        .h5categ{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 20px;
            height: 47px;
        }
        .t123{
            display: flex;
        }
        .t123 input{
            width: 500px;
            margin-right: 10px;
        }
        .t123 button{
            margin-top: 0px;
        }
    </style>
</head>
<body>
    <?php include 'navbar2.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="sidebar">
                    <h5 class="h5categ">Categories</h5>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <a href="order2.php">All Products</a>
                        </li>
                        <?php
                        if ($category_result->rowCount() > 0) {
                            while ($category_row = $category_result->fetch(PDO::FETCH_ASSOC)) {
                                echo "<li class='list-group-item'>
                                    <a href='order2.php?category=" . urlencode($category_row['category']) . "'>" . htmlspecialchars(ucfirst($category_row['category'])) . "</a>
                                </li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No Categories Available</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>

            <!-- Main content for products -->
            <div class="col-md-9">
                <div class="title1">
                    <h2>Shop</h2>
                </div>

                <!-- Search Bar -->
                <form method="GET" action="order2.php" class="mb-4 t123">
                    <input type="text" class="form-control" name="search" placeholder="Search for a product..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button class="btn btn-primary" type="submit">Search</button>
                </form>

                <div class="div001">
                    <?php
                    // Check if a category or search term is selected
                    $category_filter = '';
                    $search_filter = '';

                    if (isset($_GET['category']) && !empty($_GET['category'])) {
                        $selected_category = $_GET['category'];
                        $category_filter = "WHERE category = :category";
                    }

                    if (isset($_GET['search']) && !empty($_GET['search'])) {
                        $search_term = '%' . $_GET['search'] . '%';
                        $search_filter = !empty($category_filter) ? " AND name LIKE :search" : "WHERE name LIKE :search";
                    }

                    $sql = "SELECT product.*, 
                            COALESCE(SUM(CASE 
                                WHEN product_detail.expiration_date > CURRENT_DATE 
                                    OR product_detail.expiration_date IS NULL 
                                    OR product_detail.expiration_date = '0000-00-00' 
                                THEN product_detail.remaining_stock 
                                ELSE 0 
                            END), 0) AS stock
                        FROM product
                        LEFT JOIN product_detail ON product.id = product_detail.product_id
                        $category_filter $search_filter
                        GROUP BY product.id";
                    
                    $stmt = $conn->prepare($sql);

                    // Bind parameters if filters are set
                    if (!empty($category_filter)) {
                        $stmt->bindParam(':category', $selected_category, PDO::PARAM_STR);
                    }

                    if (!empty($search_filter)) {
                        $stmt->bindParam(':search', $search_term, PDO::PARAM_STR);
                    }

                    $stmt->execute();
                    $result = $stmt;

                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            echo "<div class='product-card' onclick=\"confirmLogin()\">";
                            echo "<img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Item Image'/>";
                            $productName = htmlspecialchars($row['name']);
                            echo "<div class='product-title'>" . (strlen($productName) > 40 ? substr($productName, 0, 40) . '...' : $productName) . "</div>";
                            echo "<div class='product-price'>PHP " . number_format($row['price'], 2) . "</div>";
                            echo "<div class='stock'>" . ($row['stock'] > 0 ? $row['stock'] . " in stock" : "<span class='text-danger'>Out of stock</span>") . "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "<p>No products available.</p>";
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function confirmLogin() {
            alert("You need to login first to order.");
            window.location.href = 'login.php';
        }
    </script>
</body>
</html>

<?php
$conn = null;
?>
