<?php
require "logics/sqlcon.php"; // Ensure you have a valid database connection

// SQL query to get the top 10 selling products
$sql = "
    SELECT p.id, p.name, p.price, p.image
    FROM orders o
    JOIN product p ON o.product_id = p.id
    WHERE o.order_status = 'Collected'
    GROUP BY p.id
    ORDER BY COUNT(o.id) DESC
    LIMIT 10
";

$stmt = $conn->prepare($sql);
$stmt->execute();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .con-carousel{
            width: 70%;
            margin-top: 6%;
            margin-left: 17%;
        }
        .carousel img {
            width: 10px;
            height: 400px; /* Reduce height to 300px */
        }

        .product-container {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 20px 0;
            position: relative;
        }
        .product-list {
            display: flex;
            overflow-x: auto;
            gap: 20px;
            padding: 10px;
            scroll-behavior: smooth;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            background-color: #f8f9fa;
            cursor: pointer;
            transition: transform 0.2s ease;
            min-width: 200px;
            max-width: 200px; /* Set consistent width */
        }
        .product-card:hover {
            transform: scale(1.05);
        }
        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .product-price {
            font-weight: bold;
            color: #ff5722;
        }
        .top-selling-header {
            font-size: 2em; /* Larger font size */
            font-weight: bold; /* Make text bold */
            color: white; /* Text color */
            text-align: center; /* Center align the text */
            background-color: #28a745; /* Semi-transparent background for contrast */
            padding: 15px; /* Padding around the text */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
            width: 40%;
            margin-left: 31%;
        }
    </style>
</head>
<body>
    <?php include 'navbar2.php'; ?>
    <div class="con-carousel">
    <div id="homepageCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/vet2.jpg" class="d-block w-100" alt="First Slide">
            </div>
            <div class="carousel-item">
                <img src="images/dog.jpg" class="d-block w-100" alt="Second Slide">
            </div>
            <div class="carousel-item">
                <img src="images/dog.avif" class="d-block w-100" alt="Third Slide">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#homepageCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#homepageCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    </div>

    <div class="container mt-4">
        <h2 class="top-selling-header">Top Selling Products</h2>
        <div class="product-container">
            <div class="product-list">
                <?php if ($stmt->rowCount() > 0): ?>
                    <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                        <div class="product-card" onclick="window.location.href='login.php'">
                            <?php
                            // Convert BLOB to base64
                            $imageData = base64_encode($row['image']);
                            $src = 'data:image/jpeg;base64,' . $imageData; // Adjust the MIME type if necessary
                            ?>
                            <img src="<?php echo $src; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" />
                            <h5>
                                <?php 
                                $productName = htmlspecialchars($row['name']); 
                                echo strlen($productName) > 40 ? substr($productName, 0, 40) . '...' : $productName; 
                                ?>
                            </h5>
                            <p class="product-price">PHP <?php echo number_format($row['price'], 2); ?></p>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No products found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
