<?php
require "logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: login.php");
    exit();
}

// Retrieve cart items, stock, and validate expiration
$sql = "SELECT product.id, product.name, cart.quantity, product.price, 
        (SELECT COALESCE(SUM(CASE 
            WHEN remaining_stock > 0 
                 AND (expiration_date > CURRENT_DATE OR expiration_date IS NULL 
                 OR expiration_date = '0000-00-00') 
            THEN remaining_stock 
            ELSE 0 
        END), 0) 
        FROM product_detail 
        WHERE product_id = product.id) AS available_stock, 
        (cart.quantity * product.price) AS total_price
    FROM cart
    INNER JOIN product ON cart.product_id = product.id
    WHERE cart.user_id = ?";

$stmt = $conn->prepare($sql);
$stmt->execute([$id]);
$cart_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_price = 0; // Initialize overall price

// Calculate total price
if ($cart_items) {
    foreach ($cart_items as $item) {
        $total_price += $item['total_price']; // Accumulate total price
    }
}
if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    $sql = "SELECT image, image_name FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$productId]);
    $image = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($image) {
        header("Content-Type: image/jpeg"); // Adjust the content type based on your image format
        echo $image['image']; // Output the image blob
    }
}
$total_item_count = 0;
foreach ($cart_items as $item) {
    $total_item_count += $item['quantity']; // Sum up all the item quantities
}
// Close the connection
$conn = null;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cart</title>
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .styled-table {
            border-collapse: collapse;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 102.2%;
            margin-left: -12px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .t1{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 100px;
            margin-left: 29%;
            height: 47px;
            width: 40%;
        }
        .t2 {
            font-size: 1.4em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #009879;
            border-radius: 4px;
            height: 70px;
            width: 400px; /* Set maximum width */
            margin: 0 auto; /* Center the element */
        }
        .t2 b{
            margin-left: 70px;
        }
        .con1{
            background-color: white;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <h2 class="t1">Your Cart</h2>
    <div class="container con1">
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Product</th>
                    <th>Name</th>
                    <th>Quantity</th>
                    <th>Item Price</th>
                    <th>Total Price</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($cart_items)): ?>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td>
                                <img src="logics/getImage.php?id=<?php echo $item['id']; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="width: 60px; height: 60px; object-fit: cover;" />
                            </td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td>
                                    <input type="number" style="width: 60px;" 
                                        id="quantity_<?php echo $item['id']; ?>" 
                                        value="<?php echo $item['quantity']; ?>" 
                                        min="1" 
                                        max="<?php echo $item['available_stock']; ?>" 
                                        step="1" />
                                    <button type="button" id="minus_<?php echo $item['id']; ?>" onclick="adjustQuantity(<?php echo $item['id']; ?>, -1)">-</button>
                                    <button type="button" id="plus_<?php echo $item['id']; ?>" onclick="adjustQuantity(<?php echo $item['id']; ?>, 1)">+</button>
                                    <small class="text-muted">Max: <?php echo $item['available_stock']; ?></small>
                                </td>

                            <td>PHP <?php echo number_format($item['price'], 2); ?></td>
                            <td>PHP <?php echo number_format($item['total_price'], 2); ?></td>
                            <td>
                                <a href="logics/processcart.php?remove=true&item_id=<?php echo $item['id']; ?>" class="btn btn-danger btn-sm">Remove</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <!-- Overall Price Display -->
        <div class="text-start mt-3 t2">
            <b class="sz1">Overall Price:</b> PHP <span id="overall-price"><?php echo number_format($total_price, 2); ?></span>
            <br>
            <b class="sz1">Total Items in Cart:</b> <span id="total-items"><?php echo $total_item_count; ?></span>
        </div>

        <h3>Payment Method</h3>
        <button id="payToShopButton" class="btn btn-primary">Cash</button>
        <button id="gcashButton" class="btn btn-success">GCash</button>

        <!-- Hidden form to submit the payment -->
        <form id="paymentForm" action="logics/processcart.php" method="post">
            <input type="hidden" id="payment_method" name="PM" value="">
            <input type="hidden" name="submit_order" value="1">
            <button type="submit" id="submit-button" style="display:none;"></button>
        </form>
    </div>

    <!-- Modal for Item Successfully Removed -->
    <div class="modal fade" id="removeModal" tabindex="-1" aria-labelledby="removeModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="removeModalLabel">Item Successfully Removed</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    The item has been successfully removed from your cart.
                </div>
                <div class="modal-footer">
                    <a href="order.php" class="btn btn-primary">add new product</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Order Placed Successfully -->
    <div class="modal fade" id="orderModal" tabindex="-1" aria-labelledby="orderModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderModalLabel">Order Placed Successfully</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Your order has been placed successfully!
                </div>
                <div class="modal-footer">
                    <a href="myorders.php" class="btn btn-primary">View Order</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="emptyModal" tabindex="-1" aria-labelledby="emptyModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="emptyModalLabel">Empty Cart</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Your Cart is Empty!!
                </div>
                <div class="modal-footer">
                    <a href="order.php" class="btn btn-primary">Add product</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Order Summary Modal -->
    <div class="modal fade" id="orderSummaryModal" tabindex="-1" aria-labelledby="orderSummaryModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="orderSummaryModalLabel">Order Summary</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Payment Method:</strong> <span id="selected-payment-method"></span></p>
                    <p><strong>Total Price:</strong> PHP <span id="summary-total-price"></span></p>
                    <p><strong>Total Items:</strong> <span id="summary-total-items"></span></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" id="confirm-payment-button" class="btn btn-primary">Confirm and Pay</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        // Show the appropriate modal based on URL parameters
        const urlParams = new URLSearchParams(window.location.search);

        // Check for 'removed' parameter
        if (urlParams.has('removed')) {
            const removeModal = new bootstrap.Modal(document.getElementById('removeModal'));
            removeModal.show();
        }

        // Check for 'order' parameter
        if (urlParams.has('order') && urlParams.get('order') === 'placed') {
            const orderModal = new bootstrap.Modal(document.getElementById('orderModal'));
            orderModal.show();
        }
        if (urlParams.has('empty') && urlParams.get('empty') === 'yes') {
            const orderModal = new bootstrap.Modal(document.getElementById('emptyModal'));
            orderModal.show();
        }

        document.addEventListener("DOMContentLoaded", function() {
            // Call this on page load to set initial button states for each item
            const items = document.querySelectorAll('input[type="number"]');
            items.forEach(item => {
                const itemId = item.id.split('_')[1];
                const quantity = parseInt(item.value);
                const maxQuantity = parseInt(item.max);
                updateButtonState(itemId, quantity, maxQuantity);

                // Add an event listener to handle manual input changes
                item.addEventListener('change', function() {
                    handleManualQuantityChange(itemId, maxQuantity);
                });
            });
        });

        // Function to update cart via AJAX
        function updateCart(itemId, newQuantity) {
            // AJAX request to update the quantity in the cart
            $.ajax({
                url: 'logics/processcart.php',
                type: 'POST',
                dataType: 'json',
                data: {
                    update_quantity: true,
                    item_id: itemId,
                    new_quantity: newQuantity
                },
                success: function(response) {
                    if (response.status === 'error') {
                        alert(response.message);
                    } else {
                        window.location.href = 'cart.php';// Reload the page to reflect changes
                    }
                },
                error: function(xhr, status, error) {
                    console.error('AJAX error:', status, error);
                }
            });
        }

        // Function to handle manual quantity changes via input field
        function handleManualQuantityChange(itemId, maxQuantity) {
            var quantityInput = document.getElementById('quantity_' + itemId);
            var newQuantity = parseInt(quantityInput.value);

            // If the new quantity exceeds max, reset it to max
            if (newQuantity > maxQuantity) {
                alert('Quantity exceeds available stock. Setting to maximum allowed: ' + maxQuantity + '.');
                newQuantity = maxQuantity;
                quantityInput.value = maxQuantity;
            } else if (newQuantity < 1 || isNaN(newQuantity)) {
                alert('Quantity cannot be less than 1.');
                newQuantity = 1;
                quantityInput.value = 1;
            }

            // Update the cart and button states
            updateButtonState(itemId, newQuantity, maxQuantity);
            updateCart(itemId, newQuantity);
        }

        // Function to adjust quantity based on the button click
        function adjustQuantity(itemId, increment) {
            var quantityInput = document.getElementById('quantity_' + itemId);
            var currentQuantity = parseInt(quantityInput.value);
            var maxQuantity = parseInt(quantityInput.max);
            var newQuantity = currentQuantity + increment;

            if (newQuantity < 1) {
                alert('Quantity cannot be less than 1.');
                newQuantity = 1;
            }

            if (newQuantity > maxQuantity) {
                alert('Quantity exceeds available stock. The maximum you can order is ' + maxQuantity + '.');
                newQuantity = maxQuantity;
            }

            quantityInput.value = newQuantity;
            updateButtonState(itemId, newQuantity, maxQuantity);
            updateCart(itemId, newQuantity);
        }

        // Function to update button states
        function updateButtonState(itemId, quantity, maxQuantity) {
            const minusButton = document.getElementById('minus_' + itemId);
            const plusButton = document.getElementById('plus_' + itemId);

            minusButton.disabled = quantity <= 1;
            plusButton.disabled = quantity >= maxQuantity;
        }
        document.addEventListener("DOMContentLoaded", function() {
            const urlParams = new URLSearchParams(window.location.search);
            if (urlParams.has('removed')) {
                // Update the URL in the address bar without reloading the page
                history.replaceState(null, '', 'cart.php');
            }
        });
        document.getElementById('gcashButton').addEventListener('click', function() {
            showOrderSummary('GCash');
        });

        document.getElementById('payToShopButton').addEventListener('click', function() {
            showOrderSummary('Cash');
        });

        function showOrderSummary(paymentMethod) {
            // Set payment method in modal
            document.getElementById('selected-payment-method').textContent = paymentMethod;
            
            // Set total price and item count in modal
            const totalPrice = document.getElementById('overall-price').textContent;
            const totalItems = document.getElementById('total-items').textContent;
            document.getElementById('summary-total-price').textContent = totalPrice;
            document.getElementById('summary-total-items').textContent = totalItems;

            // Show the summary modal
            const orderSummaryModal = new bootstrap.Modal(document.getElementById('orderSummaryModal'));
            orderSummaryModal.show();

            // When the confirm button is clicked, submit the payment form
            document.getElementById('confirm-payment-button').onclick = function() {
                document.getElementById('payment_method').value = paymentMethod.toLowerCase();
                document.getElementById('submit-button').click(); // Submit the form to process the payment
            };
        }
</script>

</body>
</html>
