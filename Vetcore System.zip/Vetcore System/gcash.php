<?php
session_start();
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$total_price = isset($_GET['total_price']) ? $_GET['total_price'] : 0;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    $submitted_price = $_POST['amount'];

    // Check if the submitted price matches the expected price
    if ((int)$submitted_price === (int)$total_price) {
        // Set session variables for payment details
        $_SESSION['payment_method'] = 'gcash';
        $_SESSION['payment_phone'] = $phone;

        // Trigger the hidden form submission for order processing
        header("Location: cart.php?gcash_success=1");
        exit();
    } else {
        $error_message = "Price mismatch. Please enter the correct amount.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GCash Payment</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
       body {
            background-color: #f1f1f1;
            font-family: Arial, sans-serif;
        }
        .gcash-header {
            background-color: #007bff;
            color: white;
            padding: 15px;
            text-align: center;
        }
        .gcash-container {
            max-width: 400px;
            margin: 50px auto;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            padding: 30px;
        }
        .gcash-button {
            background-color: #007bff;
            border: none;
            padding: 10px;
            width: 100%;
            color: white;
            font-size: 18px;
            border-radius: 5px;
        }
        .gcash-footer a {
            color: #007bff;
            text-decoration: none;
        }
        .gcash-footer a:hover {
            text-decoration: underline;
        } /* Your styles here */
    </style>
</head>
<body>
    <div class="gcash-header">
        <h3>GCash</h3>
    </div>

    <div class="gcash-container">
        <h2>Merchant: Vetcore</h2>
        <h3>Amount Due: <span class="text-primary">PHP <?php echo $total_price; ?></span></h3>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>

        <form id="gcashForm" action="" method="POST">
            <div class="gcash-input-group mb-3">
                <label for="phone" class="form-label">Enter Gcash number</label>
                <div class="input-group">
                    <span class="input-group-text">+63</span>
                    <input type="tel" id="phone" name="phone" class="form-control" placeholder="Mobile number" required>
                </div>
            </div>

            <div class="gcash-input-group mb-3">
                <label for="amount" class="form-label">Payment Amount (PHP)</label>
                <input type="number" id="amount" name="amount" class="form-control" placeholder="Enter exact amount" required>
            </div>

            <button type="submit" class="gcash-button">Next</button>
        </form>

        <!-- Hidden form to submit order -->
        <form id="submit-order-form" action="logics/processcart.php" method="POST" style="display:none;">
            <input type="hidden" name="submit_order" value="1">
            <input type="hidden" name="PM" value="<?php echo $_SESSION['payment_method']; ?>">
            <input type="hidden" name="payment_phone" value="<?php echo $_SESSION['payment_phone']; ?>">
        </form>

        <div class="gcash-footer">
            <p>Cancel? <a href="cart.php">Click here</a></p>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
