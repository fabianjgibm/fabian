<?php
require "logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: login.php");
    exit();
}
// Fetch categories from the database
$category_sql = "SELECT DISTINCT category FROM product";
$category_result = $conn->query($category_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Shop</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .title1 {
            text-align: center;
            margin-top: 20px;
            font-size: 2rem;
            color: white;
            background-color: #28a745;
            border-radius: 8px;
        }
        .div001 {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            width: 250px;
            background-color: #f8f9fa;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        .product-card:hover {
            transform: scale(1.05);
        }
        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }
        .product-title {
            font-size: 1.1rem;
            margin-top: 10px;
            color: #333;
            font-weight: bold;
        }
        .product-price {
            margin-top: 5px;
            font-size: 1.2rem;
            color: #f76c6c;
            font-weight: bold;
        }
        .original-price {
            text-decoration: line-through;
            color: #888;
            font-size: 0.9rem;
            margin-left: 5px;
        }
        .stock {
            margin-top: 5px;
            font-size: 0.9rem;
            color: #555;
        }
        .sale-price {
            font-weight: bold;
            color: #f76c6c;
        }
        .sidebar {
            padding-right: 15px;
            margin-right: 20px;
            height: auto;
        }
        .h5categ{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 20px;
            height: 47px;
        }
        .t123{
            display: flex;
        }
        .t123 input{
            width: 500px;
            margin-right: 10px;
        }
        .t123 button{
            margin-top: 0px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar for categories -->
            <div class="col-md-3">
                <div class="sidebar">
                    <h5 class="h5categ">Categories</h5>
                    <ul class="list-group">
                        <li class="list-group-item">
                            <a href="order.php">All Products</a>
                        </li>
                        <?php
                        if ($category_result->rowCount() > 0) {
                            while ($category_row = $category_result->fetch(PDO::FETCH_ASSOC)) {
                                echo "<li class='list-group-item'>
                                    <a href='order.php?category=" . urlencode($category_row['category']) . "'>" . htmlspecialchars(ucfirst($category_row['category'])) . "</a>
                                </li>";
                            }
                        } else {
                            echo "<li class='list-group-item'>No Categories Available</li>";
                        }
                        ?>
                    </ul>
                </div>
            </div>
            <!-- Main content for products -->
            <div class="col-md-9">
                <div class="title1">
                    <h2>Shop</h2>
                </div>
                <form method="GET" class="mb-4 t123">
                    <input type="text" name="search" placeholder="Search for products..." class="form-control" />
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
                <div class="div001">
                    <?php
                    // Check if a category is selected
                    $category_filter = '';
                    $search_filter = '';

                    if (isset($_GET['category']) && !empty($_GET['category'])) {
                        $selected_category = $_GET['category'];
                        $category_filter = "WHERE category = :category";
                    }

                    if (isset($_GET['search']) && !empty(trim($_GET['search']))) { // Trim whitespace
                        $search_term = '%' . trim($_GET['search']) . '%';
                        // Correct the search_filter to remove the extra parenthesis
                        $search_filter = (empty($category_filter) ? 'WHERE' : 'AND') . " name LIKE :search"; 
                    }

                    $sql = "SELECT product.*, 
                                COALESCE(SUM(CASE 
                                    WHEN product_detail.expiration_date > CURRENT_DATE 
                                        OR product_detail.expiration_date IS NULL 
                                        OR product_detail.expiration_date = '0000-00-00' 
                                    THEN product_detail.remaining_stock 
                                    ELSE 0 
                                END), 0) AS stock
                            FROM product
                            LEFT JOIN product_detail ON product.id = product_detail.product_id
                            $category_filter $search_filter
                            GROUP BY product.id";

                    // Prepare the statement
                    $stmt = $conn->prepare($sql);

                    // Bind parameters
                    if (!empty($category_filter)) {
                        $stmt->bindParam(':category', $selected_category, PDO::PARAM_STR);
                    }
                    if (!empty($search_filter)) {
                        $stmt->bindParam(':search', $search_term, PDO::PARAM_STR);
                    }

                    $stmt->execute();
                    $result = $stmt;

                    if ($result->rowCount() > 0) {
                        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                            $original_price = $row['price'];
                            echo "<div class='product-card' onclick=\"window.location.href='product_detail.php?id=" . $row['id'] . "'\">";
                            echo "<img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Item Image'/>";
                            
                            // Limit product name to 40 characters
                            $productName = htmlspecialchars($row['name']);
                            echo "<div class='product-title'>" . (strlen($productName) > 40 ? substr($productName, 0, 40) . '...' : $productName) . "</div>";
                            
                            echo "<div class='product-price'>PHP " . number_format($original_price, 2) . "</div>";
                            echo "<div class='stock'>" . ($row['stock'] > 0 ? $row['stock'] . " in stock" : "<span class='text-danger'>Out of stock</span>") . "</div>";
                            echo "</div>";
                        }
                    } else {
                        echo "<p>No products available.</p>";
                    }                    
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cartModalLabel">Item Added to Cart</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    The item has been successfully added to your cart!
                </div>
                <div class="modal-footer">
                    <a href="cart.php" class="btn btn-primary">View Cart</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Show the modal if the 'added' parameter is in the URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('added')) {
            const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
            cartModal.show();
        }
    </script>
</body>
</html>

<?php
$conn = null;
?>
