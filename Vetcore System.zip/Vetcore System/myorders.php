<?php
session_start();
require "logics/sqlcon.php";
require "logics/audit_trail.php";

if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: login.php");
    exit();
}
// Pagination variables
// Pagination variables
$limit = 10; // Number of orders per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

$status_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : 'Pending';
$current_filter = isset($_GET['status_filter']) ? $_GET['status_filter'] : 'Pending';

// Define the SQL query based on the selected filter
$query = "SELECT order_number, payment_option, payment_status, order_status, order_date_time, SUM(total_amount) AS Overall_total_amount 
          FROM orders 
          WHERE customer_id = ?";

// Add the status filter to the query
if ($status_filter !== 'all') {
    $query .= " AND order_status = ?";
}

$query .= " GROUP BY order_number LIMIT $limit OFFSET $offset"; // Use direct variable interpolation

$stmt = $conn->prepare($query);
$params = [$_SESSION['U_id']];
if ($status_filter !== 'all') {
    $params[] = $status_filter;
}

$stmt->execute($params);

$result = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count total orders for pagination
$count_query = "SELECT COUNT(DISTINCT order_number) AS total FROM orders WHERE customer_id = ?";
if ($status_filter !== 'all') {
    $count_query .= " AND order_status = ?";
}

$count_stmt = $conn->prepare($count_query);
$count_params = [$_SESSION['U_id']];
if ($status_filter !== 'all') {
    $count_params[] = $status_filter;
}

$count_stmt->execute($count_params);
$total_orders = $count_stmt->fetchColumn();
$total_pages = ceil($total_orders / $limit);

if (isset($_POST['orderstat'])) {
    $order_number = $_POST['order_number'];
    $stat = $_POST['status'];

    if ($stat == 'Cancelled') {
        try {
            // Begin transaction
            $conn->beginTransaction();

            // Fetch items in the order along with the item history IDs from which they were subtracted
            $items_query = "SELECT o.product_id, o.quantity, pd.id AS pd_id
                            FROM orders o
                            INNER JOIN product_detail pd ON o.pd_id = pd.id
                            WHERE o.order_number = ?";
            $stmt_items = $conn->prepare($items_query);
            $stmt_items->execute([$order_number]);

            // Add back items to the item history entries from which they were subtracted
            while ($item_row = $stmt_items->fetch(PDO::FETCH_ASSOC)) {
                $item_id = $item_row['product_id'];
                $quantity = $item_row['quantity'];
                $history_id = $item_row['pd_id'];

                // Update order status to "cancelled"
                $cancel_query = "UPDATE orders SET order_status = ? WHERE order_number = ?";
                $stmt_cancel = $conn->prepare($cancel_query);
                $stmt_cancel->execute([$stat, $order_number]);

                // Add back remaining quantity to the specific item history entry
                $update_history_query = "UPDATE product_detail SET remaining_stock = remaining_stock + ? WHERE id = ?";
                $stmt_update_history = $conn->prepare($update_history_query);
                $stmt_update_history->execute([$quantity, $history_id]);
            }

            // Commit transaction
            $conn->commit();

            // Log the action
            save_audit_trail($id, "Cancelled order number: $order_number", $_SESSION['U_type']);

            // Redirect to prevent resubmission popup
            header("Location: myorders.php?added=true");
            exit();
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            // Display the error message
            echo "Error: " . $e->getMessage();
        }
    } 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>My Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .divcon1 {
            margin-top: 20px;
            padding: 20px;
            background-color: white; /* Slightly transparent white background for better readability */
            border-radius: 10px; /* Rounded corners */
        }
        .order-status {
            font-weight: bold;
            margin-bottom: 10px;
        }
        .filter-button {
            margin-right: 10px;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .t1{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 100px;
            margin-left: 29%;
            height: 47px;
            width: 40%;
        }
        .active1 {
            background-color: #28a745; /* Green background */
            color: white;
        }
    </style>    
</head>
<body>
    <?php include 'navbar.php'; ?>
    <h2 class="t1">Your Orders</h2>

    <div class="divcon1">
        <!-- Filter Buttons -->
        <form method="get" class="mb-3 text-center">
            <button type="submit" name="status_filter" value="Pending" class="btn btn-secondary filter-button <?php echo $current_filter == 'Pending' ? 'active1' : ''; ?>">Pending</button>
            <button type="submit" name="status_filter" value="To Pick Up" class="btn btn-secondary filter-button <?php echo $current_filter == 'To Pick Up' ? 'active1' : ''; ?>">To Pick Up</button>
            <button type="submit" name="status_filter" value="Cancelled" class="btn btn-secondary filter-button <?php echo $current_filter == 'Cancelled' ? 'active1' : ''; ?>">Cancelled</button>
            <button type="submit" name="status_filter" value="Collected" class="btn btn-secondary filter-button <?php echo $current_filter == 'Collected' ? 'active1' : ''; ?>">Completed</button>
        </form>

        <!-- Orders Table -->
        <table class="styled-table">
            <thead class="table-dark">
                <tr>
                    <th>Order Number</th>
                    <th>Order Status</th>
                    <th>Payment Option</th>
                    <th>Payment Status</th>
                    <th>Total Amount</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result) {
                    foreach ($result as $row) {
                        echo "<tr class='active-row'>";
                        echo "<td>" . htmlspecialchars($row['order_number']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['order_status']) . "</td>";
                        echo "<td>" . htmlspecialchars(ucfirst($row['payment_option'])) . "</td>";
                        echo "<td>" . htmlspecialchars(ucfirst($row['payment_status'])) . "</td>";
                        echo "<td>₱" . number_format($row['Overall_total_amount'], 2, '.', ',') . "</td>";
                        echo "<td><a href='order_details.php?order_number=" . htmlspecialchars($row['order_number']) . "' class='btn btn-primary'>View</a>"; 
                        if ($row['order_status'] !== 'Collected' && $row['order_status'] !== 'Cancelled') {
                            echo "<form method='post' style='display:inline;'>"; 
                            echo "<input type='hidden' name='order_number' value='" . htmlspecialchars($row['order_number']) . "' />"; 
                            echo "<input type='hidden' name='status' value='Cancelled' />"; 
                            echo "<input type='submit' name='orderstat' value='Cancel Order' class='btn btn-danger btn-sm' />"; 
                            echo "</form>"; 
                        } else {
                            echo "<form method='post' style='display:inline;'></form>"; 
                        }
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='6' class='text-center'>No active orders found for this user.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <nav aria-label="Page navigation">
        <ul class="pagination justify-content-center">
            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>&status_filter=<?php echo $status_filter; ?>" tabindex="-1">Previous</a>
            </li>
            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&status_filter=<?php echo $status_filter; ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>&status_filter=<?php echo $status_filter; ?>">Next</a>
            </li>
        </ul>
    </nav>
    <div class="modal fade" id="cartModal" tabindex="-1" aria-labelledby="cartModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cartModalLabel">Item Added to Cart</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    The Order has been successfully Cancelled!
                </div>
                <div class="modal-footer">
                    <a href="order.php" class="btn btn-primary">Order new Product?</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Show the modal if the 'added' parameter is in the URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('added')) {
            const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
            cartModal.show();
        }
    // Check if the form submission was successful
        if (window.formSubmitted) {
            // Use JavaScript to redirect after the form is processed
            window.location.href = "myorders.php?added=true";
        }

    </script>
</body>
</html>
