<?php
require 'logics/sqlcon.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['U_id'];

// Initialize variables
$search_pet_name = isset($_GET['search_pet_name']) ? $_GET['search_pet_name'] : '';
$pet_type = isset($_GET['pet_type']) ? $_GET['pet_type'] : '';

// Retrieve pets for the owner with optional search and pet type
$sql = "SELECT pet_name, pet_image, image_name, pet_id FROM pet_details WHERE owner_id = :owner_id";

if (!empty($search_pet_name)) {
    $sql .= " AND pet_name LIKE :search_pet_name";
}

if (!empty($pet_type)) {
    $sql .= " AND pet_type = :pet_type"; // Assuming there's a pet_type column in pet_details
}

$stmt = $conn->prepare($sql);
$stmt->bindValue(':owner_id', $user_id);
if (!empty($search_pet_name)) {
    $stmt->bindValue(':search_pet_name', '%' . $search_pet_name . '%');
}
if (!empty($pet_type)) {
    $stmt->bindValue(':pet_type', $pet_type);
}
$stmt->execute();
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Check if a pet ID is set to display details
$pet_detail = null;
$vaccinations = [];
$upcoming_vaccination_date = "No upcoming vaccination";

if (isset($_GET['pet_id'])) {
    $pet_id = $_GET['pet_id'];
    $sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name FROM pet_details pd JOIN users u ON pd.owner_id = u.id WHERE pd.pet_id = :pet_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':pet_id' => $pet_id]);
    $pet_detail = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get vaccination details
    $sql = "SELECT vd.vaccination_date, vd.veterinarian, vd.notes,
            GROUP_CONCAT(vg.vaccine_name SEPARATOR ', ') AS vaccine_names
            FROM vaccination_details vd 
            LEFT JOIN vaccines_given vg ON vd.vaccination_id = vg.vaccination_id 
            WHERE vd.pet_id = :pet_id
            GROUP BY vd.vaccination_date, vd.veterinarian, vd.notes
            ORDER BY vd.vaccination_date DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':pet_id' => $pet_id]);
    $vaccinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch the next vaccination schedule
    $sql_next = "SELECT schedule FROM pet_details WHERE pet_id = :pet_id";
    $stmt_next = $conn->prepare($sql_next);
    $stmt_next->execute([':pet_id' => $pet_id]);
    $next_vaccination = $stmt_next->fetch(PDO::FETCH_ASSOC);

    // Format the upcoming date (if available)
    $upcoming_vaccination_date = $next_vaccination ? date('F j, Y', strtotime($next_vaccination['schedule'])) : "No upcoming vaccination";
    $last_vaccination = $vaccinations[0] ?? null; // Fetch the most recent vaccination details

$sql_next = "SELECT schedule
             FROM pet_details
             WHERE pet_id = :pet_id";
$stmt_next = $conn->prepare($sql_next);
$stmt_next->execute([':pet_id' => $pet_id]);
$next_vaccination = $stmt_next->fetch(PDO::FETCH_ASSOC);

// Format the upcoming date (if available)
$upcoming_vaccination_date = $next_vaccination ? date('F j, Y', strtotime($next_vaccination['schedule'])) : "No upcoming vaccination";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pets List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script>
        // Function to handle input changes and update the search without refreshing
        function updateSearch() {
            const searchInput = document.getElementById('search-pet-name').value;
            const petType = document.getElementById('pet-type').value;

            // Create an XMLHttpRequest
            const xhr = new XMLHttpRequest();
            xhr.open('GET', 'search_pets.php?search_pet_name=' + encodeURIComponent(searchInput) + '&pet_type=' + encodeURIComponent(petType), true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    document.getElementById('pet-list').innerHTML = xhr.responseText;
                }
            };
            xhr.send();
        }
    </script>
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        .table th, .table td {
            padding: 12px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .table th {
            background-color: #28a745; /* Green background for the header */
            color: white; /* White text color for the header */
            font-weight: bold;
        }

        .table tbody tr:nth-child(even) {
            background-color: #f9f9f9; /* Light gray background for even rows */
        }

        .table tbody tr:hover {
            background-color: #e2f0d9; /* Light green background on hover */
        }

        .table td {
            color: #333; /* Dark text color for table cells */
        }

        .table .no-records {
            text-align: center;
            font-style: italic;
            color: #999; /* Gray color for no records message */
        }
        .text-success {
            text-align: center; /* Center the text */
        }
        .custom-card {
            margin-left: 145px; /* Adjust this value as needed */
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar for pet selection -->
            <div class="col-md-4 sidebar bg-white p-4" style="width: 300px; height: 150vh; max-height: 150vh; border-right: 2px solid #ddd; overflow-y: auto;">
                <h4 class="text-center mb-4">My Pets</h4>

                <!-- Pet Type Dropdown -->
                <select id="pet-type" class="form-control mb-3" style="border-radius: 25px; padding: 10px;" onchange="updateSearch()">
                    <option value="dog" <?php echo ($pet_type === 'dog') ? 'selected' : ''; ?>>Dog</option>
                    <option value="cat" <?php echo ($pet_type === 'cat') ? 'selected' : ''; ?>>Cat</option>
                    <!-- Add more options as needed -->
                </select>

                <input type="text" id="search-pet-name" name="search_pet_name" placeholder="Search by Pet Name" class="form-control mb-3" style="border-radius: 25px; padding: 10px;" value="<?php echo htmlspecialchars($search_pet_name); ?>" oninput="updateSearch()">

                <!-- Pet List -->
                <div id="pet-list" class="mt-4" style="max-height: 600px;">
                    <?php if (count($pets) > 0): ?>
                        <?php foreach ($pets as $pet): ?>
                            <div class="pet-card mb-3 p-3 text-center" style="border: 1px solid #ddd; border-radius: 15px; cursor: pointer;" onclick="window.location.href='pets.php?pet_id=<?php echo $pet['pet_id']; ?>';">
                                <div class="pet-image-container">
                                    <?php
                                    $pet_image_base64 = base64_encode($pet['pet_image']);
                                    $image_type = pathinfo($pet['image_name'], PATHINFO_EXTENSION);
                                    ?>
                                    <img src="data:image/<?php echo $image_type; ?>;base64,<?php echo $pet_image_base64; ?>" alt="Pet Image" class="img-fluid" style="width: 80px; height: 80px; object-fit: cover; border-radius: 50%; border: 2px solid #00a651;">
                                </div>
                                <p class="pet-name mt-2" style="font-size: 1.1rem; font-weight: bold; color: #00a651;"><?php echo htmlspecialchars($pet['pet_name']); ?></p>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-center" style="color: red;">You have no pets of this type. Please adjust your search criteria.</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Pet Details Section -->
            <div class="col-md-8">
                <?php if ($pet_detail): ?>
                    <div class="card shadow-sm my-4 custom-card">
                        <div class="card-body">
                            <h2 class="card-title text-center text-success"><?php echo htmlspecialchars($pet_detail['pet_name']); ?></h2>
                            <img src="data:image/jpeg;base64,<?php echo base64_encode($pet_detail['pet_image']); ?>" class="img-fluid rounded mx-auto d-block border border-2 border-success" style="width: 200px;">
                            <div class="mt-3">
                                <div class="d-flex justify-content-between bg-light p-2 rounded">
                                    <div><strong>Pet Type:</strong> <?php echo htmlspecialchars($pet_detail['pet_type']); ?></div>
                                    <div><strong>Breed:</strong> <?php echo htmlspecialchars($pet_detail['breed']); ?></div>
                                </div>
                                <div class="d-flex justify-content-between bg-light p-2 rounded mt-2">
                                    <div><strong>Age:</strong> <?php echo htmlspecialchars($pet_detail['age']); ?></div>
                                    <div><strong>Gender:</strong> <?php echo htmlspecialchars($pet_detail['gender']); ?></div>
                                </div>
                                <div class="d-flex justify-content-between bg-light p-2 rounded mt-2">
                                    <div><strong>Owner's Name:</strong> <?php echo htmlspecialchars($pet_detail['owner_name']); ?></div>
                                    <div><strong>Birthday:</strong> <?php echo htmlspecialchars($pet_detail['birthday']); ?></div>
                                </div>
                            </div>
                            
                            <h3 class="text-center text-success mt-5 fw-bold">
                            <?php 
                            // Check if the upcoming vaccination date has passed
                            if ($next_vaccination) {
                                $upcoming_date = new DateTime($next_vaccination['schedule']);
                                $current_date = new DateTime();

                                // Change heading based on the date
                                if ($upcoming_date < $current_date) {
                                    echo "Missed Vaccination"; // Display if the date has passed
                                } else {
                                    echo "Upcoming Vaccination"; // Display if the date is in the future
                                }
                            } else {
                                echo "No Vaccination Scheduled"; // If no upcoming vaccination is available
                            }
                            ?>
                        </h3>
                        <p class="text-center fs-4 fw-bold">
                            <?php 
                            // Show the date or an appropriate message
                            if ($next_vaccination) {
                                echo htmlspecialchars($upcoming_vaccination_date);
                            } else {
                                echo "There are no scheduled vaccinations.";
                            }
                            ?>
                        </p>
                            <div class="table-responsive mt-4">
                                <h3 class="text-success">Vaccination History</h3>
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>Veterinarian</th>
                                            <th>Vaccines</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (count($vaccinations) > 0): ?>
                                            <?php foreach ($vaccinations as $vaccination): ?>
                                                <tr>
                                                    <td><?php echo htmlspecialchars(date('F j, Y', strtotime($vaccination['vaccination_date']))); ?></td>
                                                    <td><?php echo htmlspecialchars($vaccination['vaccine_names']); ?></td>
                                                    <td><?php echo htmlspecialchars($vaccination['veterinarian']); ?></td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="4" class="no-records">No vaccination history available.</td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <?php if ($last_vaccination) {
                    // Check if the last vaccination date is within two weeks
                    $vaccination_date = new DateTime($last_vaccination['vaccination_date']);
                    $current_date = new DateTime();
                    $interval = $current_date->diff($vaccination_date);
                    
                    // Show note if it's within two weeks
                    if ($interval->days <= 14) { ?>
                        <div class="alert alert-info mt-4 text-center custom-card">
                            <strong>Last Vaccination Note:<br></strong> <?php echo htmlspecialchars($last_vaccination['notes']); ?>
                        </div>
                    <?php }
                } ?>
                <?php else: ?>
                    <div class="alert alert-info text-center mt-4">Select a pet to see details.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
