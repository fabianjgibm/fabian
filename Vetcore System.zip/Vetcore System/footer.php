<!-- footer.php -->
<footer style="background-color: #28a745; color: white; padding: 20px; text-align: center;">
    <div class="container">
        <p>Contact Us:</p>
        <p>Mobile: <strong>+63 912 345 6789</strong></p>
        <p>
            <a href="https://facebook.com/YourVetPage" style="color: white;" target="_blank">Facebook</a> | 
            <a href="https://instagram.com/YourVetPage" style="color: white;" target="_blank">Instagram</a>
        </p>
        <p>Location: 123 Veterinary Lane, Animal City</p>
        <p>&copy; <?php echo date("Y"); ?> Your Veterinary Clinic. All Rights Reserved.</p>
    </div>
</footer>
