<?php
require "sqlcon.php"; // Make sure to include the database connection

function save_audit_trail($userID, $action, $userType) {
    global $conn;
    
    // Prepare the query to insert into the audit table
    $query = "INSERT INTO auditt (userID, action, date, userType) VALUES (:userID, :action, NOW(), :userType)";
    $stmt = $conn->prepare($query);
    
    // Execute the query with the given data
    $stmt->execute([
        ':userID' => $userID,
        ':action' => $action,
        ':userType' => $userType
    ]);
}
?>
