<?php
require '../logics/sqlcon.php';

if (isset($_POST['query'])) {
    $query = $_POST['query'];
    // Searching by first name or last name with a limit of 20 results
    $sql = "SELECT id, CONCAT(fname, ' ', lname) AS owner_name 
            FROM users 
            WHERE (fname LIKE :query OR lname LIKE :query OR CONCAT(fname, ' ', lname) LIKE :query)
            AND user_type = 'customer'  -- Exclude veterinarians by filtering user_type
            LIMIT 20";  // Limit the results to 20
    $stmt = $conn->prepare($sql);
    $stmt->execute([':query' => "%$query%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($results) {
        foreach ($results as $row) {
            echo '<div class="search-result-item" data-owner-id="' . $row['id'] . '" data-owner-name="' . htmlspecialchars($row['owner_name']) . '">' . htmlspecialchars($row['owner_name']) . '</div>';
        }
    } else {
        echo '<div>No results found</div>';
    }
}
?>
