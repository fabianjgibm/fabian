<?php
require "sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get the selected filter from GET request
$order_status_filter = isset($_GET['filter']) ? $_GET['filter'] : 'Pending';

// Get the search query
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// SQL to retrieve orders based on search query
$sql = "SELECT o.order_number, o.order_status, o.payment_status, o.payment_option, u.fname, u.lname
        FROM orders o
        JOIN users u ON o.customer_id = u.id";

if ($order_status_filter) {
    $sql .= " WHERE o.order_status = :order_status";
}

if ($search_query) {
    $sql .= " AND (u.fname LIKE :search OR u.lname LIKE :search OR o.order_number LIKE :search)";
}

$sql .= " GROUP BY o.order_number";  // Group by order_number to avoid duplicates

$stmt = $conn->prepare($sql);

if ($order_status_filter) {
    $stmt->bindValue(':order_status', $order_status_filter);
}

if ($search_query) {
    $search_param = '%' . $search_query . '%';
    $stmt->bindValue(':search', $search_param);
}

$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (count($orders) > 0) {
    foreach ($orders as $order) {
        echo '<tr>';
        echo '<td>' . htmlspecialchars($order['order_number']) . '</td>';
        echo '<td>' . htmlspecialchars($order['fname'] . ' ' . $order['lname']) . '</td>';
        echo '<td>' . htmlspecialchars($order['order_status']) . '</td>';
        echo '<td>' . htmlspecialchars($order['payment_option']) . '</td>';
        echo '<td>' . htmlspecialchars($order['payment_status']) . '</td>';
        echo '<td><a href="order_details.php?order_number=' . urlencode($order['order_number']) . '" class="btn btn-info">View</a></td>';

        if ($order['order_status'] != 'Picked') {
            echo '<td>';
            echo '<form action="../logics/process_order_status.php" method="POST">';
            echo '<input type="hidden" name="order_number" value="' . htmlspecialchars($order['order_number']) . '">';
            if ($order['order_status'] == 'Pending') {
                echo '<button type="submit" name="update_status" value="Ready to Pick Up" class="btn btn-warning">Ready to Pick Up</button>';
            } elseif ($order['order_status'] == 'Ready to Pick Up') {
                echo '<button type="submit" name="update_status" value="Picked" class="btn btn-success">Mark as Picked</button>';
            }
            echo '</form>';
            echo '</td>';
        } else {
            echo '<td></td>'; // Empty cell if the status is 'Picked'
        }

        echo '</tr>';
    }
} else {
    echo '<tr><td colspan="7" class="text-center">No orders found.</td></tr>';
}
?>
