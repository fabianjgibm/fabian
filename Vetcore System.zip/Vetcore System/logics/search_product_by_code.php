<?php
require "sqlcon.php"; // Include your logic file

// Check if the query parameter is set
if (isset($_GET['q'])) {
    $searchTerm = $_GET['q'];

    // Prepare SQL statement to search products by product code, only those that are not expired, with a limit of 2 results
    $sql = "SELECT pd.id, pd.product_code, p.name 
            FROM product_detail pd 
            JOIN product p ON pd.product_id = p.id 
            WHERE pd.product_code LIKE :searchTerm 
            AND pd.expiration_date > NOW() 
            LIMIT 20"; // Limit to 2 results

    $stmt = $conn->prepare($sql);
    $stmt->execute(['searchTerm' => '%' . $searchTerm . '%']);

    // Fetch results
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Return results as JSON
    echo json_encode($results);
}

// Close connection
$conn = null;
?>
