<?php
require "../logics/sqlcon.php";
require "audit_trail.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get the order number and update status from POST request
$order_number = $_POST['order_number'];
$update_status = $_POST['update_status'];

try {
    // Start transaction
    $conn->beginTransaction();

    // Prepare the update statement
    $sql = "UPDATE orders SET order_status = :order_status WHERE order_number = :order_number";
    $stmt = $conn->prepare($sql);

    // Bind parameters and execute the update
    $stmt->execute([
        ':order_status' => $update_status,
        ':order_number' => $order_number,
    ]);

    // If the status is 'Picked', also update payment_status to 'Paid'
    if ($update_status === 'Collected') {
        $sql = "UPDATE orders SET payment_status = 'Paid' WHERE order_number = :order_number";
        $stmt = $conn->prepare($sql);
        $stmt->execute([':order_number' => $order_number]);
        
        // Commit transaction and redirect for Picked status
        $conn->commit();
        $userID = $_SESSION['U_id'];
        $userType = $_SESSION['U_type'];
        $action = "Update order status to Collected";
        save_audit_trail($userID, $action, $userType);
        $_SESSION['success'] = "Status updated successfully.";
        header("Location: ../admin/manage_order.php?filter=To Pick Up");
        exit();
    }

    // Commit transaction for other statuses
    $conn->commit();

    // Redirect based on the updated status for other statuses
    if ($update_status === 'Collected') {
        $_SESSION['success'] = "Status updated successfully.";
        header("Location: ../admin/manage_order.php?filter=To Pick Up");
        save_audit_trail($userID, $action, $userType);
    } elseif ($update_status === 'To Pick Up') {
        $userID = $_SESSION['U_id'];
        $userType = $_SESSION['U_type'];
        $action = "Update order status to To Pick Up";
        save_audit_trail($userID, $action, $userType);
        $_SESSION['success'] = "Status updated successfully.";
        header("Location: ../admin/manage_order.php?filter=Pending"); // Redirect to Pending filter
    }

    exit();
} catch (Exception $e) {
    // Rollback transaction in case of error
    $conn->rollBack();
    echo "Error updating order status: " . $e->getMessage();
}
?>
