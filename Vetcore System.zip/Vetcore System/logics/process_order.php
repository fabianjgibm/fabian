<?php
require "sqlcon.php";
session_start();

if (isset($_SESSION['U_id'], $_POST['submit_order'])) {
    $customerId = $_SESSION['U_id'];
    $paymentoption = htmlspecialchars($_POST['PM']);
    $paymentstatus = "Paid";

    // Check if payment option is GCash and update payment status accordingly
    if ($paymentoption === "gcash") {
        $paymentstatus = "paid";
    }
    $status = "Collected";

    // Retrieve cart items for the logged-in user
    $sql_cart = "SELECT * FROM cart WHERE user_id=?";
    $stmt_cart = $conn->prepare($sql_cart);
    $stmt_cart->execute([$customerId]);
    $cart_items = $stmt_cart->fetchAll(PDO::FETCH_ASSOC);

    if ($cart_items) {
        $conn->beginTransaction(); // Start transaction

        try {
            $orderNumber = uniqid('ORD'); // Unique order number for this order

            foreach ($cart_items as $row_cart) {
                $productId = $row_cart['product_id'];
                $quantity = $row_cart['quantity'];

                // Fetch item price
                $sql_item = "SELECT price FROM product WHERE id = ?";
                $stmt_item = $conn->prepare($sql_item);
                $stmt_item->execute([$productId]);
                $row_item = $stmt_item->fetch(PDO::FETCH_ASSOC);

                if ($row_item) {
                    $item_price = $row_item['price'];
                } else {
                    throw new Exception("Item price not found for product ID: $productId");
                }

                $itemTotalAmount = $quantity * $item_price; // Calculate total amount for this item

                // Fetch the product detail ID with available stock
                $item_detail_query = "SELECT id, remaining_stock 
                FROM product_detail 
                WHERE product_id = ? 
                  AND remaining_stock > 0 
                  AND (expiration_date > NOW() OR expiration_date = '0000-00-00') 
                ORDER BY expiration_date ASC";
                $stmt_detail = $conn->prepare($item_detail_query);
                $stmt_detail->execute([$productId]);

                if ($stmt_detail->rowCount() == 0) {
                    throw new Exception("No available items for product ID: $productId");
                }

                // Insert order details into orders table, with total amount for this specific item
                $sql_order = "INSERT INTO orders (customer_id, product_id, quantity, total_amount, order_number, order_status, payment_option, payment_status, pd_id) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                // Loop through product details and reduce stock as necessary
                while ($quantity > 0 && $item_detail_row = $stmt_detail->fetch(PDO::FETCH_ASSOC)) {
                    $detail_id = $item_detail_row['id'];
                    $remaining_stock = $item_detail_row['remaining_stock'];

                    if ($quantity <= $remaining_stock) {
                        // Update remaining stock for this product detail
                        $update_detail_query = "UPDATE product_detail SET remaining_stock = remaining_stock - ? WHERE id = ?";
                        $stmt_update_detail = $conn->prepare($update_detail_query);
                        $stmt_update_detail->execute([$quantity, $detail_id]);

                        // Insert into orders for the final quantity deducted
                        $stmt_order = $conn->prepare($sql_order);
                        $stmt_order->execute([$customerId, $productId, $quantity, $itemTotalAmount, $orderNumber, $status, $paymentoption, $paymentstatus, $detail_id]);

                        $quantity = 0; // All quantity is fulfilled
                    } else {
                        // Update remaining stock for this product detail
                        // If remaining stock is not enough, update it to 0 and continue to the next detail
                        $update_detail_query = "UPDATE product_detail SET remaining_stock = 0 WHERE id = ?";
                        $stmt_update_detail = $conn->prepare($update_detail_query);
                        $stmt_update_detail->execute([$detail_id]);

                        // Insert into orders for the quantity deducted in this iteration
                        $partialAmount = $remaining_stock * $item_price; // Calculate partial amount for the current stock
                        $stmt_order = $conn->prepare($sql_order);
                        $stmt_order->execute([$customerId, $productId, $remaining_stock, $partialAmount, $orderNumber, $status, $paymentoption, $paymentstatus, $detail_id]);

                        $quantity -= $remaining_stock; // Reduce quantity by the stock used in this iteration
                    }
                }
            }

            // Save the action in the audit trail: order placed
            $action = "Placed order $orderNumber with payment option $paymentoption";
            //save_audit_trail($customerId, $action, $_SESSION['U_type']);

            // Clear the cart after successful order placement
            $sql_clear_cart = "DELETE FROM cart WHERE user_id=?";
            $stmt_clear_cart = $conn->prepare($sql_clear_cart);
            $stmt_clear_cart->execute([$customerId]);

            // Save the action in the audit trail: cart cleared
            $action = "Cleared cart after placing order $orderNumber";
            //save_audit_trail($customerId, $action, $_SESSION['U_type']);

            $conn->commit(); // Commit transaction

            // Redirect to payment.php only if the payment option is GCash
            if ($paymentoption === "gcash") {
                header("Location: ../admin/onsite.php");
                exit();
            } else {
                // For other payment options, you can redirect or display a success message
                header("Location: ../admin/onsite.php"); // Change to the appropriate page
                exit();
            }

        } catch (Exception $e) {
            $conn->rollback(); // Rollback transaction if an error occurs
            $notify = 'Error: ' . $e->getMessage();
            echo "<script>
                alert('$notify');
                window.location.href = '../myorders.php';
            </script>";
            exit();
        }   
    } else {
        header("Location: ../cart.php?empty=yes"); // Redirect if cart is empty
        exit();
    }
} else {
    $notify = "Invalid request!";
    header("Location: ../cart.php");
    exit();
}
?>
