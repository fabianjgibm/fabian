<?php
require "sqlcon.php";
require "audit_trail.php";  
session_start();
if (isset($_POST['orderstat'])) {
    $order_number = $_POST['order_number'];
    $stat = $_POST['status'];

    if ($stat == 'Cancelled') {
        try {
            // Begin transaction
            $conn->beginTransaction();

            // Fetch items in the order along with the item history IDs from which they were subtracted
            $items_query = "SELECT o.product_id, o.quantity, pd.id AS pd_id
                            FROM orders o
                            INNER JOIN product_detail pd ON o.pd_id = pd.id
                            WHERE o.order_number = ?";
            $stmt_items = $conn->prepare($items_query);
            $stmt_items->execute([$order_number]);

            // Add back items to the item history entries from which they were subtracted
            while ($item_row = $stmt_items->fetch(PDO::FETCH_ASSOC)) {
                $item_id = $item_row['product_id'];
                $quantity = $item_row['quantity'];
                $history_id = $item_row['pd_id'];

                // Update order status to "cancelled"
                $cancel_query = "UPDATE orders SET order_status = ? WHERE order_number = ?";
                $stmt_cancel = $conn->prepare($cancel_query);
                $stmt_cancel->execute([$stat, $order_number]);

                // Add back remaining quantity to the specific item history entry
                $update_history_query = "UPDATE product_detail SET remaining_stock = remaining_stock + ? WHERE id = ?";
                $stmt_update_history = $conn->prepare($update_history_query);
                $stmt_update_history->execute([$quantity, $history_id]);
            }

            // Commit transaction
            $conn->commit();

            $userID = $_SESSION['U_id'];
            $userType = $_SESSION['U_type'];
            $action = "Order Cancelled";
            save_audit_trail($userID, $action, $userType);

            $notify = 'Order cancelled';
            echo "<script>
                    alert('$notify');
                    window.location.href = '../admin/manage_order.php';
                </script>";
        } catch (Exception $e) {
            // Rollback transaction on error
            $conn->rollback();
            // Display the error message
            echo "Error: " . $e->getMessage();
        }
    }
}
?>