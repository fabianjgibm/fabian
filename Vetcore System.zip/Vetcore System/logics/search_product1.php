<?php
require 'sqlcon.php'; // Ensure the correct path to sqlcon.php

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['query'])) {
    $searchTerm = '%' . $_POST['query'] . '%';
    
    // Set a limit for the number of results
    $limit = 10; // Adjust the limit as needed

    try {
        // SQL query to search for products based on the query term
        $sql = "SELECT p.id, p.name, p.price, p.image, p.stock_limit, IFNULL(SUM(pd.remaining_stock), 0) AS total_stock
                FROM product p
                LEFT JOIN product_detail pd ON p.id = pd.product_id
                AND (pd.expiration_date IS NULL OR pd.expiration_date > NOW())
                WHERE p.name LIKE :searchTerm
                GROUP BY p.id, p.name, p.price, p.image
                ORDER BY p.id ASC
                LIMIT :limit"; // Add LIMIT clause
        
        $stmt = $conn->prepare($sql);
        // Bind parameters
        $stmt->bindParam(':searchTerm', $searchTerm, PDO::PARAM_STR);
        $stmt->bindParam(':limit', $limit, PDO::PARAM_INT); // Bind limit as integer
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($results) {
            foreach ($results as $row) {
                $fullName = htmlspecialchars($row["name"]);
                $shortName = (strlen($fullName) > 40) ? substr($fullName, 0, 40) . '...' : $fullName;
                echo "<tr>";
                echo "<td><img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Product Image' class='item-image'/></td>";
                echo "<td class='product-name' data-bs-toggle='tooltip' data-bs-placement='top' title='" . $fullName . "'>" . $shortName . "</td>";
                echo "<td>₱" . htmlspecialchars($row["price"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["total_stock"]) . "</td>";
                echo "<td>" . htmlspecialchars($row["stock_limit"]) . "</td>";
                echo "<td><a href='edit_item_price.php?id=" . $row["id"] . "' class='btn btn-sm btn-primary'>Edit Product</a>
                <a href='add_stock.php?id=" . $row["id"] . "' class='btn btn-sm btn-primary'>Add Stock</a></td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No products found</td></tr>";
        }
    } catch (Exception $e) {
        // Handle and log any potential errors
        error_log($e->getMessage());
        echo "<tr><td colspan='4'>Error occurred while fetching products</td></tr>";
    }
}
?>
