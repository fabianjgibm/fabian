<?php
require "sqlcon.php"; // Include your logic file

// Check if the query parameter is set
if (isset($_GET['q'])) {
    $searchTerm = $_GET['q'];

    // Prepare SQL statement to search products by name
    $sql = "SELECT id, name FROM product WHERE name LIKE :searchTerm";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['searchTerm' => '%' . $searchTerm . '%']);
    
    // Fetch results
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Return results as JSON
    echo json_encode($results);
}

// Close connection
$conn = null;
?>
