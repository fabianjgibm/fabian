<?php
require "sqlcon.php";
session_start();

$email = htmlspecialchars($_POST['email']);
$firstname = htmlspecialchars($_POST['Fname']);
$lastname = htmlspecialchars($_POST['Lname']);
$Mnumber = htmlspecialchars($_POST['Mnum']);
$password = htmlspecialchars($_POST['pass']); // Sanitize password too

// Hash the password
$hashpass = password_hash($password, PASSWORD_DEFAULT);

try {
    // Check if email or phone number already exists
    $sqlCheck = "
        SELECT COUNT(*) 
        FROM users 
        WHERE email = :email OR phone_number = :phone_number
    ";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->execute([
        ':email' => $email,
        ':phone_number' => $Mnumber,
    ]);

    $count = $stmtCheck->fetchColumn();

    // Check if email or phone number exists
    if ($count > 0) {
        $_SESSION['failed2'] = "Email Or Mobile Number is Already Registered";
        header("Location: ../register.php"); // Redirect back to the register page
        exit();
    }

    // Step 1: Retrieve existing full names
    $sqlFullNameCheck = "
        SELECT CONCAT(fname, ' ', lname) AS full_name 
        FROM users
    ";
    $stmtFullNameCheck = $conn->prepare($sqlFullNameCheck);
    $stmtFullNameCheck->execute();

    // Fetch all existing full names into an array
    $existingFullNames = $stmtFullNameCheck->fetchAll(PDO::FETCH_COLUMN);

    // Step 2: Create the new full name variable
    $newFullName = trim($firstname . ' ' . $lastname);

    // Step 3: Check if the new full name matches any existing full name
    if (in_array($newFullName, $existingFullNames)) {
        // Full name already exists
        $_SESSION['failed1'] = "First Or Last Name is Already Registered";
        header("Location: ../register.php"); // Redirect back to the register page
        exit();
    }

    // SQL query with prepared statement for inserting the new user
    $sql = "INSERT INTO users (user_type, password, email, fname, lname, phone_number) 
            VALUES (:user_type, :password, :email, :fname, :lname, :phone_number)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':user_type' => 'customer',
        ':password' => $hashpass,
        ':email' => $email,
        ':fname' => $firstname,
        ':lname' => $lastname,
        ':phone_number' => $Mnumber,
    ]);

    $_SESSION['success'] = "Account created successfully! You can now log in.";
    header("Location: ../register.php"); // Redirect back to the register page
    exit();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null;
?>
