<?php
require "sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

// Get the pet_id from POST request
if (isset($_POST['pet_id'])) {
    $pet_id = $_POST['pet_id'];

    // Check if there's an existing vaccination schedule for this pet
    $sql = "SELECT COUNT(*) FROM vaccination_details WHERE pet_id = :pet_id"; // Assuming you have a 'vaccination_details' table
    $stmt = $conn->prepare($sql);
    $stmt->execute([':pet_id' => $pet_id]);
    $count = $stmt->fetchColumn();

    // Return response based on the count
    if ($count > 0) {
        echo 'exists'; // Schedule exists
    } else {
        echo 'not_exists'; // No schedule found
    }
} else {
    echo 'not_exists'; // Pet ID not set
}
?>
