<?php
require "sqlcon.php";
require "audit_trail.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}
$id = $_SESSION['U_id'];
$userType = $_SESSION['U_type']; 
$id = $_SESSION['U_id'];
// Check if an item needs to be removed
if (isset($_GET['remove']) && isset($_GET['item_id'])) {
    $removeItemId = $_GET['item_id'];
    
    // Remove item from the cart
    $sql = "DELETE FROM cart WHERE user_id=? AND product_id=?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id, $removeItemId]);

    // Save the action in the audit trail
    $action = "Removed item with ID $removeItemId from the cart";
    save_audit_trail($id, $action, $userType);
    
    header("Location: ../cart.php?removed=true");
    exit();
}
// Check if quantity needs to be updated
if (isset($_POST['update_quantity']) && isset($_POST['item_id']) && isset($_POST['new_quantity'])) {
    $updateItemId = $_POST['item_id'];
    $newQuantity = $_POST['new_quantity'];

    $stockQuery = "SELECT COALESCE(SUM(CASE WHEN product_detail.expiration_date > CURRENT_DATE 
    OR product_detail.expiration_date IS NULL THEN product_detail.remaining_stock ELSE 0 END), 0) AS stock
                   FROM product
                   LEFT JOIN product_detail ON product.id = product_detail.product_id
                   WHERE product.id = :product_id
                   GROUP BY product.id";

    $stmt = $conn->prepare($stockQuery);
    $stmt->bindParam(":product_id", $updateItemId);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($newQuantity > 0) {
        $sql = "UPDATE cart SET quantity=? WHERE user_id=? AND product_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$newQuantity, $id, $updateItemId]);
    } else {
        // Optionally handle case where quantity is 0 (could remove the item)
        $sql = "DELETE FROM cart WHERE user_id=? AND product_id=?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id, $updateItemId]);
    }

    // Respond to AJAX request
    echo json_encode(['status' => 'success', 'message' => 'Quantity updated.']);
    exit();
}


// Process order
if (isset($_SESSION['U_id'], $_POST['submit_order'])) {
    $customerId = $_SESSION['U_id'];
    $paymentoption = htmlspecialchars($_POST['PM']);
    $paymentstatus = "unpaid";

    // Check if payment option is gcash and update payment status accordingly
    if ($paymentoption === "gcash") {
        $paymentstatus = "paid";
    }
    $status = "Pending";

    // Retrieve cart items for the logged-in user
    $sql_cart = "SELECT * FROM cart WHERE user_id=?";
    $stmt_cart = $conn->prepare($sql_cart);
    $stmt_cart->execute([$customerId]);
    $cart_items = $stmt_cart->fetchAll(PDO::FETCH_ASSOC);

    if ($cart_items) {
        $conn->beginTransaction(); // Start transaction

        try {
            $orderNumber = uniqid('ORD'); // Unique order number for this order

            foreach ($cart_items as $row_cart) {
                $productId = $row_cart['product_id'];
                $quantity = $row_cart['quantity'];

                // Fetch item price
                $sql_item = "SELECT price FROM product WHERE id = ?";
                $stmt_item = $conn->prepare($sql_item);
                $stmt_item->execute([$productId]);
                $row_item = $stmt_item->fetch(PDO::FETCH_ASSOC);

                if ($row_item) {
                    $item_price = $row_item['price'];
                } else {
                    throw new Exception("Item price not found for product ID: $productId");
                }

                $itemTotalAmount = $quantity * $item_price; // Calculate total amount for this item

                // Fetch the product detail ID with available stock
                $item_detail_query = "SELECT id, remaining_stock 
                FROM product_detail 
                WHERE product_id = ? 
                  AND remaining_stock > 0 
                  AND (expiration_date > NOW() OR expiration_date = '0000-00-00') 
                ORDER BY expiration_date ASC";
                $stmt_detail = $conn->prepare($item_detail_query);
                $stmt_detail->execute([$productId]);

                if ($stmt_detail->rowCount() == 0) {
                    throw new Exception("No available items for product ID: $productId");
                }

                // Insert order details into orders table, with total amount for this specific item
                $sql_order = "INSERT INTO orders (customer_id, product_id, quantity, total_amount, order_number, order_status, payment_option, payment_status, pd_id) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
                
                // Loop through product details and reduce stock as necessary
                while ($quantity > 0 && $item_detail_row = $stmt_detail->fetch(PDO::FETCH_ASSOC)) {
                    $detail_id = $item_detail_row['id'];
                    $remaining_stock = $item_detail_row['remaining_stock'];

                    if ($quantity <= $remaining_stock) {
                        // Update remaining stock for this product detail
                        $update_detail_query = "UPDATE product_detail SET remaining_stock = remaining_stock - ? WHERE id = ?";
                        $stmt_update_detail = $conn->prepare($update_detail_query);
                        $stmt_update_detail->execute([$quantity, $detail_id]);

                        // Insert into orders for the final quantity deducted
                        $stmt_order = $conn->prepare($sql_order);
                        $stmt_order->execute([$customerId, $productId, $quantity, $itemTotalAmount, $orderNumber, $status, $paymentoption, $paymentstatus, $detail_id]);

                        $quantity = 0; // All quantity is fulfilled
                    } else {
                        // Update remaining stock for this product detail
                        // If remaining stock is not enough, update it to 0 and continue to the next detail
                        $update_detail_query = "UPDATE product_detail SET remaining_stock = 0 WHERE id = ?";
                        $stmt_update_detail = $conn->prepare($update_detail_query);
                        $stmt_update_detail->execute([$detail_id]);

                        // Insert into orders for the quantity deducted in this iteration
                        $partialAmount = $remaining_stock * $item_price; // Calculate partial amount for the current stock
                        $stmt_order = $conn->prepare($sql_order);
                        $stmt_order->execute([$customerId, $productId, $remaining_stock, $partialAmount, $orderNumber, $status, $paymentoption, $paymentstatus, $detail_id]);

                        $quantity -= $remaining_stock; // Reduce quantity by the stock used in this iteration
                    }
                }
            }

            // Save the action in the audit trail: order placed
            $action = "Placed order $orderNumber with payment option $paymentoption";
            save_audit_trail($customerId, $action, $userType);

            // Clear the cart after successful order placement
            $sql_clear_cart = "DELETE FROM cart WHERE user_id=?";
            $stmt_clear_cart = $conn->prepare($sql_clear_cart);
            $stmt_clear_cart->execute([$customerId]);

            // Save the action in the audit trail: cart cleared
            $action = "Cleared cart after placing order $orderNumber";
            save_audit_trail($customerId, $action, $userType);

            $conn->commit(); // Commit transaction

            if ($paymentoption === "gcash") {
                $gcashPaymentUrl = "http://localhost/payment/app/Http/Controllers/payment.php?amount=" . urlencode($itemTotalAmount);
                $orderNumber = uniqid('ORD'); // Assuming this is generated for the order
                
                echo "<script>
                        var gcashWindow = window.open('$gcashPaymentUrl', '_blank');
                        if (gcashWindow) {
                            gcashWindow.focus();
                        } else {
                            alert('Please allow popups for this website.');
                        }
                        
                        // Simulate waiting for a payment confirmation for testing purposes
                        setTimeout(function() {
                            // Since the payment is already marked as paid, we just wait and then redirect
                            window.location.href = '../cart.php?order=placed&status=paid'; // Redirect to success page after waiting
                        }, 10000); // Simulate a 5-second delay before redirecting
                      </script>";
                exit();
            }
            else {
                // For other payment options, you can redirect or display a success message
                header("Location: ../cart.php?order=placed"); // Change to the appropriate page
                exit();
            }

        } catch (Exception $e) {
            $conn->rollback(); // Rollback transaction if an error occurs
            $notify = 'Error: ' . $e->getMessage();
            echo "<script>
                alert('$notify');
                window.location.href = '../myorders.php';
            </script>";
            exit();
        }   
    } else {
        header("Location: ../cart.php?empty=yes"); // Redirect if cart is empty
        exit();
    }
} else {
    $notify = "Invalid request!";
    header("Location: ../cart.php");
    exit();
}

$conn = null; // Close the connection
?>
