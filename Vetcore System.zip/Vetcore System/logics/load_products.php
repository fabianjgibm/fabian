<?php
require "sqlcon.php";

// Define how many results you want per page
$limit = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Fetch total records excluding expiration date of '0000-00-00'
$sqlTotal = "SELECT COUNT(*) FROM product_detail pd 
             INNER JOIN product p ON pd.product_id = p.id 
             WHERE pd.expiration_date > NOW() AND pd.expiration_date != '0000-00-00'";
$totalResult = $conn->query($sqlTotal);
$totalRecords = $totalResult->fetchColumn();
$totalPages = ceil($totalRecords / $limit);

// Fetch the current products excluding expiration date of '0000-00-00'
$sqlCurrentItems = "SELECT pd.*, p.name 
                    FROM product_detail pd 
                    INNER JOIN product p ON pd.product_id = p.id 
                    WHERE pd.expiration_date > NOW() AND pd.expiration_date != '0000-00-00' 
                    LIMIT :limit OFFSET :start";
$stmt = $conn->prepare($sqlCurrentItems);
$stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmt->bindParam(':start', $start, PDO::PARAM_INT);
$stmt->execute();
$currentItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Build HTML for products
$productRows = '';
if (!empty($currentItems)) {
    foreach ($currentItems as $row) {
        $productName = htmlspecialchars($row['name']);
        $shortName = (strlen($productName) > 40) ? substr($productName, 0, 40) . '...' : $productName;
        $productRows .= "<tr>";
        $productRows .= "<td>" . htmlspecialchars($row['product_code']) . "</td>";
        $productRows .= "<td><span data-bs-toggle='tooltip' title='" . $productName . "'>" . $shortName . "</span></td>";
        $productRows .= "<td>" . htmlspecialchars($row['remaining_stock']) . "</td>";
        $productRows .= "<td>" . htmlspecialchars($row['stock']) . "</td>";
        $productRows .= "<td>" . htmlspecialchars($row['expiration_date']) . "</td>";
        $productRows .= "<td>" . htmlspecialchars($row['added_date']) . "</td>";
        $productRows .= "<td><a href='edit_stock.php?product_code=" . htmlspecialchars($row['product_code']) . "' class='btn btn-sm btn-primary'>Edit Stock</a></td>";
        $productRows .= "</tr>";
    }
} else {
    $productRows .= "<tr><td colspan='7'>No current products</td></tr>";
}

// Build HTML for pagination
$paginationLinks = '';
$paginationLinks .= '<li class="page-item ' . ($page <= 1 ? 'disabled' : '') . '">
                        <a class="page-link" href="javascript:void(0);" onclick="loadPage(' . ($page - 1) . ', event)">Previous</a>
                     </li>';
for ($i = 1; $i <= $totalPages; $i++) {
    $paginationLinks .= '<li class="page-item ' . ($i === $page ? 'active' : '') . '">
                            <a class="page-link" href="javascript:void(0);" onclick="loadPage(' . $i . ', event)">' . $i . '</a>
                        </li>';
}
$paginationLinks .= '<li class="page-item ' . ($page >= $totalPages ? 'disabled' : '') . '">
                        <a class="page-link" href="javascript:void(0);" onclick="loadPage(' . ($page + 1) . ', event)">Next</a>
                     </li>';

// Return JSON response
echo json_encode([
    'products' => $productRows,
    'pagination' => $paginationLinks,
]);
?>
