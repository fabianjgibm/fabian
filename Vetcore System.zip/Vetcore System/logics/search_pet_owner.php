<?php
require 'sqlcon.php'; // Database connection

if (isset($_POST['query'])) {
    $searchQuery = $_POST['query'];

    // SQL query to search for pets and their owners by name
    $sql = "SELECT p.pet_id, p.pet_name, u.fname, u.lname 
            FROM pet_details p
            INNER JOIN users u ON p.owner_id = u.id
            WHERE p.pet_name LIKE :query OR u.fname LIKE :query OR u.lname LIKE :query";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([':query' => "%$searchQuery%"]);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($results) {
        foreach ($results as $row) {
            // Output each result with clickable div
            echo '<div class="search-result-item" data-pet-id="'.$row['pet_id'].'" data-pet-name="'.$row['pet_name'].'" data-owner-name="'.$row['fname'].' '.$row['lname'].'">';
            echo $row['pet_name'] . " Owner: " . $row['fname'] . " " . $row['lname'] . "";
            echo '</div>';
        }
    } else {
        echo '<p>No results found</p>';
    }
}
?>
