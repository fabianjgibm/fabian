<?php
require "../logics/sqlcon.php";

$search = isset($_POST['search']) ? $_POST['search'] : '';

// Retrieve all pet details matching the search
$sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name 
        FROM pet_details pd 
        JOIN users u ON pd.owner_id = u.id 
        WHERE pd.pet_name LIKE :search OR u.fname LIKE :search OR u.lname LIKE :search";

$stmt = $conn->prepare($sql);
$stmt->execute([':search' => '%' . $search . '%']);
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($pets) {
    foreach ($pets as $pet) {
        echo '<div class="col-md-4">
                <div class="card mb-4">
                    <div class="card-body text-center">
                        <h5 class="card-title">' . htmlspecialchars($pet['pet_name']) . '</h5>
                        <img src="data:image/jpeg;base64,' . base64_encode($pet['pet_image']) . '" 
                             alt="' . htmlspecialchars($pet['pet_name']) . '" 
                             class="img-fluid rounded-circle" 
                             style="width: 150px; height: 150px; object-fit: cover;" />
                        <p class="mt-2">Owner: ' . htmlspecialchars($pet['owner_name']) . '</p>
                        <a href="pet_details.php?pet_id=' . htmlspecialchars($pet['pet_id']) . '" class="btn btn-info">View</a>
                    </div>
                </div>
              </div>';
    }
} else {
    echo '<div class="col-12">
            <p class="text-center">No pets found.</p>
          </div>';
}
?>
