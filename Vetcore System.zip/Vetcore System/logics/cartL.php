<?php
require "sqlcon.php";
require "audit_trail.php"; // Include the audit trail script
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    // Redirect to login page or handle as appropriate
    header("Location: Farmlogin.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addToCart'])) {
    $user_id = $_SESSION['U_id'];
    $product_id = $_POST['id'];
    $quantity = $_POST['quantity'];

    // Check the available stock for the selected product
    $stockQuery = "SELECT COALESCE(SUM(CASE 
        WHEN product_detail.expiration_date > CURRENT_DATE 
             OR product_detail.expiration_date IS NULL 
             OR product_detail.expiration_date = '0000-00-00' 
        THEN product_detail.remaining_stock 
        ELSE 0 
    END), 0) AS stock
    FROM product
    LEFT JOIN product_detail ON product.id = product_detail.product_id
    WHERE product.id = :product_id
    GROUP BY product.id";

    $stmt = $conn->prepare($stockQuery);
    $stmt->bindParam(":product_id", $product_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $available_stock = $row ? $row['stock'] : 0;

    // Check if the product is already in the cart
    $check_sql = "SELECT * FROM cart WHERE user_id = :user_id AND product_id = :product_id";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->execute([':user_id' => $user_id, ':product_id' => $product_id]);
    $check_result = $check_stmt->fetch(PDO::FETCH_ASSOC);

    // Get current cart quantity
    $current_quantity = $check_result ? $check_result['quantity'] : 0;

    // Calculate the total quantity after addition
    $new_quantity = $current_quantity + $quantity;

    // If the total quantity exceeds the available stock, display an error message and exit
    if ($new_quantity > $available_stock) {
        $notify = "Quantity exceeds available stock. The maximum you can order is $available_stock.";
        echo "<script>
            alert('$notify');
            window.location.href = '../order.php';
        </script>";
        exit();
    }

    if ($check_result) {
        // Product already in cart, update the quantity
        $update_sql = "UPDATE cart SET quantity = quantity + :quantity WHERE user_id = :user_id AND product_id = :product_id";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->execute([':quantity' => $quantity, ':user_id' => $user_id, ':product_id' => $product_id]);

        // Save the update action to the audit trail
        save_audit_trail($user_id, "Updated product (ID: $product_id) quantity in cart", $_SESSION['U_type']);
    } else {
        // Product not in cart, insert new record
        $insert_sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->execute([':user_id' => $user_id, ':product_id' => $product_id, ':quantity' => $quantity]);

        // Save the insert action to the audit trail
        save_audit_trail($user_id, "Added product (ID: $product_id) to cart", $_SESSION['U_type']);
    }

    // No need to close PDO statements, it is handled by PDO itself
    $conn = null; // Close the connection

    header("Location: ../order.php?added=true");
    exit();
}
?>
