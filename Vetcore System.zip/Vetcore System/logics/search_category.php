<?php
require "sqlcon.php"; // Include your SQL connection file

// Check if the query parameter is set
if (isset($_GET['q'])) {
    $searchTerm = $_GET['q'];

    // Prepare SQL statement to search categories
    $sql = "SELECT DISTINCT category FROM product WHERE category LIKE :searchTerm";
    $stmt = $conn->prepare($sql);
    $stmt->execute(['searchTerm' => '%' . $searchTerm . '%']);

    // Fetch results
    $results = $stmt->fetchAll(PDO::FETCH_COLUMN);

    // Return results as JSON
    echo json_encode($results);
}

// Close connection
$conn = null;
?>
