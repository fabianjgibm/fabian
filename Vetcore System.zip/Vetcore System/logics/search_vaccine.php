<?php
require 'sqlcon.php';

if (isset($_POST['query'])) {
    $query = $_POST['query'];

    // Prepare and execute the SQL statement to search for vaccines
    $sql = "SELECT id, vaccine_name FROM vaccines WHERE vaccine_name LIKE :query";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':query' => '%' . $query . '%']);
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check if any vaccines were found
    if ($results) {
        foreach ($results as $row) {
            echo '<div class="vaccine-search-result-item" data-vaccine-id="' . $row['id'] . '" data-vaccine-name="' . $row['vaccine_name'] . '">';
            echo $row['vaccine_name'];
            echo '</div>';
        }
    } else {
        echo '<div>No vaccines found</div>';
    }
}
?>
