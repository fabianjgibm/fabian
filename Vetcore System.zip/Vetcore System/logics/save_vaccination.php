<?php
require 'sqlcon.php';
require "audit_trail.php";  
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pet_id = $_POST['pet_id'];
    $veterinarian_id = $_POST['veterinarian_id'];
    $notes = isset($_POST['notes']) ? $_POST['notes'] : '';
    $vaccine_names = isset($_POST['vaccine_names']) ? $_POST['vaccine_names'] : [];
    $next_vaccination_date = isset($_POST['next_vaccination_date']) ? $_POST['next_vaccination_date'] : null;

    try {
        $conn->beginTransaction();

        // Fetch veterinarian name using veterinarian_id
        $sql = "SELECT CONCAT(fname, ' ', lname) AS veterinarian_name FROM users WHERE id = :veterinarian_id AND user_type = 'veterinarian'";
        $stmt = $conn->prepare($sql);
        $stmt->execute([':veterinarian_id' => $veterinarian_id]);
        $veterinarian = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($veterinarian) {
            $veterinarian_name = $veterinarian['veterinarian_name'];

            // Insert into vaccination_details table
            $sql = "INSERT INTO vaccination_details (pet_id, vaccination_date, veterinarian, notes)
                    VALUES (:pet_id, NOW(), :veterinarian, :notes)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':pet_id' => $pet_id,
                ':veterinarian' => $veterinarian_name, // Save the veterinarian's name
                ':notes' => $notes
            ]);

            // Get the last inserted vaccination record ID
            $vaccination_id = $conn->lastInsertId();

            // Insert each vaccine into the vaccines_given table by name
            foreach ($vaccine_names as $vaccine_id) {
                if (!empty($vaccine_id)) {
                    // Fetch the vaccine name from the vaccines table
                    $sql = "SELECT vaccine_name FROM vaccines WHERE id = :vaccine_id";
                    $stmt = $conn->prepare($sql);
                    $stmt->execute([':vaccine_id' => $vaccine_id]);
                    $vaccine = $stmt->fetch(PDO::FETCH_ASSOC);
                    
                    if ($vaccine) {
                        $vaccine_name = $vaccine['vaccine_name'];
                        
                        // Insert the vaccine name into vaccines_given
                        $sql = "INSERT INTO vaccines_given (vaccination_id, vaccine_name) 
                                VALUES (:vaccination_id, :vaccine_name)";
                        $stmt = $conn->prepare($sql);
                        $stmt->execute([
                            ':vaccination_id' => $vaccination_id,
                            ':vaccine_name' => $vaccine_name
                        ]);
                    }
                }
            }

            // Update pet's vaccination schedule if a new one is provided
            if ($next_vaccination_date) {
                $sql = "UPDATE pet_details SET schedule = :schedule WHERE pet_id = :pet_id";
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    ':schedule' => $next_vaccination_date,
                    ':pet_id' => $pet_id
                ]);
            }

            $conn->commit();

            $userID = $_SESSION['U_id'];
            $userType = $_SESSION['U_type'];
            $action = "Pet Vaccination Record Update";
            save_audit_trail($userID, $action, $userType);

            $_SESSION['success'] = "Pet Vaccination Updated";
            header("Location: ../admin/view_pet.php");// Redirect back to the register page
            exit();
        } else {
            echo "Veterinarian not found.";
        }
    } catch (Exception $e) {
        $conn->rollBack();
        echo "Error: " . $e->getMessage();
    }
}
?>
