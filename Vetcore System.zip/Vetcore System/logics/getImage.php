<?php
require "sqlcon.php";

if (isset($_GET['id'])) {
    $productId = $_GET['id'];

    $sql = "SELECT image, image_name FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$productId]);
    $image = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($image) {
        header("Content-Type: image/jpeg"); // Adjust the content type based on your image format
        echo $image['image']; // Output the image blob
    }
}
?>
