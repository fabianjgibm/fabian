<?php
require "sqlcon.php";

$query = isset($_GET['query']) ? $_GET['query'] : '';

// Prepare the SQL statement to search by product name or product code
$sql = "SELECT pd.product_code, p.name, pd.expiration_date, pd.remaining_stock
        FROM product_detail pd 
        INNER JOIN product p ON pd.product_id = p.id 
        WHERE pd.expiration_date BETWEEN :currentDate AND :endOfWeek
        AND (p.name LIKE :query OR pd.product_code LIKE :query)";

$currentDate = date('Y-m-d');
$endOfWeek = date('Y-m-d', strtotime('next Monday'));
$searchTerm = '%' . $query . '%'; // For partial matching

$stmt = $conn->prepare($sql);
$stmt->bindParam(':currentDate', $currentDate);
$stmt->bindParam(':endOfWeek', $endOfWeek);
$stmt->bindParam(':query', $searchTerm);
$stmt->execute();

$expiringItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return the filtered results as table rows
if (!empty($expiringItems)) {
    foreach ($expiringItems as $expiringItem) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($expiringItem['product_code']) . "</td>";
        echo "<td>" . htmlspecialchars($expiringItem['name']) . "</td>";
        echo "<td>" . htmlspecialchars($expiringItem['expiration_date']) . "</td>";
        echo "<td>" . htmlspecialchars($expiringItem['remaining_stock']) . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No expiring items found matching your search.</td></tr>";
}
?>
