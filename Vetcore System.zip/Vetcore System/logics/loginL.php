<?php
require "sqlcon.php";
require "audit_trail.php";
session_start();

$un = $_POST['userN'];
$pw = $_POST['Pass'];

$query = "SELECT * FROM users WHERE email=:email";
$stmt = $conn->prepare($query);
$stmt->execute([':email' => $un]);

if ($stmt && $stmt->rowCount() == 1) {
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $login_attempts = $row['login_attempts'];
    $last_login_attempt = $row['last_login_attempt'];
    $lockout_time = $row['lockout_time'];

    // Check if the user is currently locked out
    if ($lockout_time && strtotime($lockout_time) > time()) {
        // User is still locked out
        $remaining_time = strtotime($lockout_time) - time();
        $_SESSION['success'] = "You are temporarily locked out. Try again in " . ceil($remaining_time / 60) . " minutes.";
        header("Location: ../login.php");
        exit();
    }

    $hashed_password = $row['password'];

    if (password_verify($pw, $hashed_password)) {
        // Successful login
        $_SESSION['U_id'] = $row['id'];
        $_SESSION['U_type'] = $row['user_type'];
        
        // Reset login attempts and lockout time
        $stmt = $conn->prepare("UPDATE users SET login_attempts = 0, lockout_time = NULL WHERE email = :email");
        $stmt->execute([':email' => $un]);

        switch ($row['user_type']) {
            case 'admin':
                $notify = 'Welcome Admin, you are now logged in.';
                
                // Save to audit trail
                save_audit_trail($row['id'], "Admin logged in", $row['user_type']);
                
                echo "<script>
                    alert('$notify');
                    window.location.href = '../admin/dashboard.php';
                </script>";
                break;
            case 'staff':
                $notify = 'Welcome Staff, you are now logged in.';
                
                // Save to audit trail
                save_audit_trail($row['id'], "Staff logged in", $row['user_type']);
                
                echo "<script>
                    alert('$notify');
                    window.location.href = '../admin/dashboard.php';
                </script>";
                break;
            case 'veterinarian':
                $notify = 'Welcome Veterinarian, you are now logged in.';
                
                // Save to audit trail
                save_audit_trail($row['id'], "Veterinarian logged in", $row['user_type']);
                
                echo "<script>
                    alert('$notify');
                    window.location.href = '../admin/dashboard.php';
                </script>";
                break;
            case 'customer':
                // Check the authentication status
                $_SESSION['email'] = $row['email'];
                
                if ($row['authentication'] === 'enabled') {
                    // Save to audit trail
                    save_audit_trail($row['id'], "Customer authentication initiated", $row['user_type']);
                    
                    header("Location: ../authcode.php");
                } else {
                    // Save to audit trail
                    save_audit_trail($row['id'], "Customer logged in", $row['user_type']);
                    
                    header("Location: ../home.php");
                }
                exit();
                break;
            default:
                echo "Unknown user type";
                break;
        }
        exit();
    } else {
        // Failed login attempt
        $login_attempts++;

        // Update last login attempt time
        $stmt = $conn->prepare("UPDATE users SET login_attempts = :login_attempts, last_login_attempt = NOW() WHERE email = :email");
        $stmt->execute([':login_attempts' => $login_attempts, ':email' => $un]);

        // Calculate lockout time based on attempts
        if ($login_attempts >= 3) {
            // Check how many times the user has been locked out
            $stmt = $conn->prepare("SELECT lockout_time FROM users WHERE email = :email");
            $stmt->execute([':email' => $un]);
            $user_data = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Calculate the lockout duration based on previous failed attempts
            // Increment the lockout duration by 5 minutes for each set of 3 failed attempts
            $lockout_duration = 5 * ceil($login_attempts / 3); // First lockout: 5 min, second lockout: 10 min, etc.
            
            // Set the lockout time
            $lockout_time = date('Y-m-d H:i:s', strtotime("+{$lockout_duration} minutes"));
        
            // Update the lockout_time and reset login_attempts to 0
            $stmt = $conn->prepare("UPDATE users SET lockout_time = :lockout_time, login_attempts = 0 WHERE email = :email");
            $stmt->execute([':lockout_time' => $lockout_time, ':email' => $un]);
        
            $_SESSION['success'] = "Too many failed login attempts. You are locked out for {$lockout_duration} minutes.";
            header("Location: ../login.php");
            exit();
        }

        $_SESSION['success'] = "Invalid Credentials! Attempt $login_attempts of 3.";
        header("Location: ../login.php");
        exit();
    }
} else {
    $_SESSION['success'] = "Invalid Credentials!!";
    header("Location: ../login.php");
    exit();
}
?>
