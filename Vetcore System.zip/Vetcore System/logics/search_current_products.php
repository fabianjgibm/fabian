<?php
require "sqlcon.php";

// Get the search query from the URL
$searchTerm = isset($_GET['query']) ? $_GET['query'] : '';

// SQL query to filter by product code or product name, excluding invalid expiration dates
$sql = "SELECT pd.*, p.name 
        FROM product_detail pd 
        INNER JOIN product p ON pd.product_id = p.id 
        WHERE (pd.product_code LIKE :search OR p.name LIKE :search) 
        AND (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW())";

$stmt = $conn->prepare($sql);
$searchTermWithWildcards = '%' . $searchTerm . '%';
$stmt->bindParam(':search', $searchTermWithWildcards);
$stmt->execute();
$currentItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// If there are matching results, display them in table rows
if (!empty($currentItems)) {
    foreach ($currentItems as $row) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['product_code']) . "</td>";
        
        // Limit the product name to 40 characters
        $fullName = htmlspecialchars($row['name']);
        $shortName = (strlen($fullName) > 40) ? substr($fullName, 0, 40) . '...' : $fullName;

        // Display the product name with a tooltip for the full name
        echo "<td class='product-name' data-bs-toggle='tooltip' data-bs-placement='top' title='" . $fullName . "'>" . $shortName . "</td>";
        
        echo "<td>" . htmlspecialchars($row['remaining_stock']) . "</td>";
        echo "<td>" . htmlspecialchars($row['stock']) . "</td>";
        echo "<td>" . htmlspecialchars($row['expiration_date']) . "</td>";
        echo "<td>" . htmlspecialchars($row['added_date']) . "</td>";
        echo "<td><a href='edit_stock.php?product_code=" . htmlspecialchars($row['product_code']) . "' class='btn btn-sm btn-primary'>Edit Stock</a></td>";
        echo "</tr>";
    }
} else {
    // If no matching products are found
    echo "<tr><td colspan='7'>No products found</td></tr>"; // Adjusted colspan to match the number of columns
}
?>
