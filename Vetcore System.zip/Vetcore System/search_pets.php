<?php
require 'logics/sqlcon.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    exit('User not logged in');
}

$user_id = $_SESSION['U_id'];
$search_pet_name = isset($_GET['search_pet_name']) ? $_GET['search_pet_name'] : '';
$pet_type = isset($_GET['pet_type']) ? $_GET['pet_type'] : '';

// Prepare SQL to fetch pets based on search term and pet type
$sql = "SELECT pet_name, pet_image, image_name, pet_id FROM pet_details WHERE owner_id = :owner_id";

if (!empty($search_pet_name)) {
    $sql .= " AND pet_name LIKE :search_pet_name";
}

if (!empty($pet_type)) {
    $sql .= " AND pet_type = :pet_type"; // Assuming there's a pet_type column in pet_details
}

$stmt = $conn->prepare($sql);
$stmt->bindValue(':owner_id', $user_id);
if (!empty($search_pet_name)) {
    $stmt->bindValue(':search_pet_name', '%' . $search_pet_name . '%');
}
if (!empty($pet_type)) {
    $stmt->bindValue(':pet_type', $pet_type);
}
$stmt->execute();
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Generate the pet list HTML
if (count($pets) > 0) {
    foreach ($pets as $pet) {
        $pet_image_base64 = base64_encode($pet['pet_image']);
        $image_type = pathinfo($pet['image_name'], PATHINFO_EXTENSION);
        echo '<div class="pet-card mb-3 p-3 text-center" style="border: 1px solid #ddd; border-radius: 15px; cursor: pointer;" onclick="window.location.href=\'pets.php?pet_id=' . $pet['pet_id'] . '\';">
                <div class="pet-image-container">
                    <img src="data:image/' . $image_type . ';base64,' . $pet_image_base64 . '" alt="Pet Image" class="img-fluid" style="width: 80px; height: 80px; object-fit: cover; border-radius: 50%; border: 2px solid #00a651;">
                </div>
                <p class="pet-name mt-2" style="font-size: 1.1rem; font-weight: bold; color: #00a651;">' . htmlspecialchars($pet['pet_name']) . '</p>
            </div>';
    }
} else {
    echo '<p class="text-center" style="color: red;">You have no pets of this type.</p>';
}
?>
