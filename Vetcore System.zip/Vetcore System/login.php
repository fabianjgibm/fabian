<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Log in</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
        }
        .loginNregister {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff; /* White background for form */
            padding: 30px;
            border: 1px solid #e0e0e0;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1); /* Light shadow */
        }
        .loginNregister h2 {
            margin-bottom: 20px;
            font-weight: bold;
            text-align: center;
            color: #343a40; /* Dark gray text */
        }
        .loginNregister label {
            font-weight: 500;
        }
        .loginNregister input[type="text"], 
        .loginNregister input[type="password"] {
            width: 100%;
            padding: 10px;
            margin: 10px 0 20px;
            border: 1px solid #ced4da;
            border-radius: 4px;
        }
        .loginNregister button {
            width: 100%;
            padding: 10px;
            background-color: #fd7e14; /* Bootstrap warning color */
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .loginNregister button:hover {
            background-color: #e67600; /* Darker orange on hover */
        }
        .forgot-password, .loginNregister2 {
            text-align: center;
            margin-top: 20px;
        }
        .forgot-password a, .loginNregister2 a {
            color: #fd7e14; /* Matching link color */
            text-decoration: none;
            font-weight: bold;
        }
        .forgot-password a:hover, .loginNregister2 a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <?php include 'navbar2.php'; ?>
    <div class="loginNregister" id="login">
        <form method="POST" action="logics/loginL.php">
            <h2>Login</h2>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-danger d-flex justify-content-between align-items-center" role="alert">
                    <span>
                        <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']); // Clear the message after displaying
                        ?>
                    </span>
                </div>
            <?php endif; ?>

            <label for="userN">Email</label>
            <input type="text" name="userN" id="userN" placeholder="Enter your email" required>
            <label for="Pass">Password</label>
            <input type="password" name="Pass" id="Pass" placeholder="Enter your password" required>
            <button type="submit">Login</button>
            <div class="forgot-password">
                <p>Forgot Password? <a href="forgotpass.php">Click here</a></p>
            </div>
            <div class="loginNregister2">
                <label class="create-label">Create Account?</label>
                <br>
                <a href="register.php">Register</a>
            </div>
        </form>
    </div>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>
