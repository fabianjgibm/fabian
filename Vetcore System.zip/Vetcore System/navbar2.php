<?php   
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <style>
        .navbar {
            background-color: #28a745; /* Keep navbar background color */
        }
        .navbar-brand {
            color: #fff; /* Logo text color */
        }
        .navbar-nav {
            display: flex;
            align-items: center;
        }
        .navbar-nav .nav-item {
            margin-right: 20px; /* Spacing between nav items */
            position: relative; /* Allow for underline effect */
        }
        .navbar-nav .nav-link {
            color: #fff; /* Link text color */
            padding: 10px; /* Reduce padding for a cleaner look */
            display: flex; /* Flex for icon and text alignment */
            align-items: center; /* Center align items */
            transition: background-color 0.3s ease, color 0.3s ease; /* Smooth transition */
            border-radius: 10px;
        }
        .navbar-nav .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1); /* Light background on hover */
            color: #d4d4d4; /* Change link color on hover */
        }
        .navbar-nav .nav-item.active .nav-link {
            color: #fff; /* Ensure active link text color is white */
            background-color: rgba(255, 255, 255, 0.2); /* Slightly darker background for active item */
        }
        /* Active state on li (instead of a) with underline */
        .navbar-nav .nav-item.active {
            border-bottom: 3px solid #fff; /* Add thick underline on active item */
        }
        /* Add some transition effects for smooth hover and active state */
        .navbar-nav .nav-item,
        .navbar-nav .nav-link {
            transition: color 0.3s ease, border-bottom 0.3s ease;
        }
        .navbar-brand img {
            border-radius: 50%; /* Make the logo image round */
            width: 50px; /* Set the width of the logo */
            height: 50px; /* Set the height of the logo */
        }
        .cart-icon, .notification-icon {
            position: relative;
        }
        .badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545; /* Bootstrap danger color */
            color: white;
            border-radius: 50%;
            padding: 5px 8px;
            font-size: 0.8rem;
        }
        .icon {
            width: 32px; /* Change this value to adjust the size */
            height: 32px; /* Change this value to adjust the size */
            margin-right: 8px; /* Space between icon and text */
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="home2.php">
                <img src="images/vetcore logo.jpg" alt="Logo" class="d-inline-block align-top"> 
                <strong style="font-size: 2rem; color: #fff;">Vetcore</strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item <?php echo ($current_page == 'home2.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="home2.php" title="Home">
                            <img src="images/doghome.png" alt="Home" class="icon">
                            <?php echo ($current_page == 'home2.php') ? 'Home' : ''; // Show name only on Home page ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'order2.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="order2.php" title="Shop">
                            <img src="images/shop.png" alt="Shop" class="icon">
                            <?php echo ($current_page == 'order2.php') ? 'Shop' : ''; // Show name only on Shop page ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'register.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="register.php" title="Sign Up">
                            <img src="images/sign-up.png" alt="Log Out" class="icon">
                            <?php echo ($current_page == 'register.php') ? 'Sign Up' : ''; ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'login.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="login.php" title="Log In">
                            <img src="images/enter.png" alt="Log Out" class="icon">
                            <?php echo ($current_page == 'login.php') ? 'Log In' : ''; ?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Bootstrap JS Bundle with Popper -->
</body>
</html>
