<?php
require "logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: login.php");
    exit();
}

// Fetch missed and upcoming vaccinations for the owner's pets
// Fetch missed, today, and upcoming vaccinations for the owner's pets
$sql = "
    SELECT pd.pet_name, pd.pet_image, pd.schedule, 
           CASE 
               WHEN pd.schedule = CURDATE() THEN 'today'
               WHEN pd.schedule < CURDATE() THEN 'missed'
               WHEN pd.schedule BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY) THEN 'upcoming' 
           END AS status
    FROM pet_details AS pd 
    WHERE pd.schedule IS NOT NULL 
    AND pd.owner_id = :owner_id
    ORDER BY pd.schedule ASC";
$stmt = $conn->prepare($sql);
$stmt->execute([':owner_id' => $id]);
$vaccinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

$missed = array_filter($vaccinations, function($v) {
    return $v['status'] === 'missed';
});
$today = array_filter($vaccinations, function($v) {
    return $v['status'] === 'today';
});
$upcoming = array_filter($vaccinations, function($v) {
    return $v['status'] === 'upcoming';
});

// SQL query to get the top 10 selling products
$sql = "
    SELECT p.id, p.name, p.price, p.image, 
        COALESCE((
            SELECT SUM(CASE 
                WHEN pd.expiration_date > CURRENT_DATE 
                     OR pd.expiration_date = '0000-00-00' 
                THEN pd.remaining_stock 
                ELSE 0 
            END)
            FROM product_detail pd
            WHERE pd.product_id = p.id
        ), 0) AS stock
    FROM orders o
    JOIN product p ON o.product_id = p.id
    WHERE o.order_status = 'Collected'
    GROUP BY p.id
    ORDER BY COUNT(o.id) DESC
    LIMIT 10
";


$stmt = $conn->prepare($sql);
$stmt->execute();
$top_selling_products = $stmt->fetchAll(PDO::FETCH_ASSOC); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Top Selling Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }

        .con-carousel{
            width: 70%;
            margin-top: 6%;
            margin-left: 17%;
        }
        .carousel img {
            width: 10px;
            height: 400px; /* Reduce height to 300px */
        }

        .product-container {
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 20px 0;
            position: relative;
        }

        .product-list {
            display: flex;
            overflow-x: auto;
            gap: 20px;
            padding: 10px;
            scroll-behavior: smooth;
        }

        .product-card {
            border: 1px solid #ddd;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            background-color: #f8f9fa;
            cursor: pointer;
            transition: transform 0.2s ease;
            min-width: 200px;
            max-width: 200px;
        }

        .product-card:hover {
            transform: scale(1.05);
        }

        .product-card img {
            max-width: 100%;
            height: auto;
            border-radius: 5px;
        }

        .product-price {
            font-weight: bold;
            color: #ff5722;
        }

        .stock {
            font-size: 0.9rem;
            color: #28a745;
        }

        .out-of-stock {
            color: red;
        }

        .scroll-btn {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 50%;
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        .scroll-btn.left {
            left: 0;
        }

        .scroll-btn.right {
            right: 0;
        }
        .top-selling-header {
            font-size: 2em; /* Larger font size */
            font-weight: bold; /* Make text bold */
            color: white; /* Text color */
            text-align: center; /* Center align the text */
            background-color: #28a745; /* Semi-transparent background for contrast */
            padding: 15px; /* Padding around the text */
            border-radius: 8px; /* Rounded corners */
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); /* Subtle shadow for depth */
            width: 40%;
            margin-left: 31%;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>

    <div class="con-carousel">
    <div id="homepageCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="images/vet2.jpg" class="d-block w-100" alt="First Slide">
            </div>
            <div class="carousel-item">
                <img src="images/vet1.jpg" class="d-block w-100" alt="Second Slide">
            </div>
            <div class="carousel-item">
                <img src="images/vet3.png" class="d-block w-100" alt="Third Slide">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#homepageCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#homepageCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    </div>
<!-- Pop-up Modal -->
<?php if ($vaccinations && (count($missed) > 0 || count($today) > 0 || count($upcoming) > 0)): ?>
    <div class="modal fade" id="vaccinationReminder" tabindex="-1" aria-labelledby="reminderLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="reminderLabel">Vaccination Schedules</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <?php 
                    // Separate vaccinations by their status
                    $missed = array_filter($vaccinations, function($v) {
                        return $v['status'] === 'missed';
                    });
                    $today = array_filter($vaccinations, function($v) {
                        return $v['status'] === 'today';
                    });
                    $upcoming = array_filter($vaccinations, function($v) {
                        return $v['status'] === 'upcoming';
                    });
                    ?>

                    <!-- Today's Vaccinations Section -->
                    <?php if ($today): ?>
                        <h6 class="text-warning">Today's Vaccinations</h6>
                        <?php foreach ($today as $vaccination): ?>
                            <div class="d-flex mb-3 bg-warning p-2 rounded" style="border: 2px solid #ffc107;">
                                <?php
                                // Convert BLOB to base64 for displaying pet image
                                $imageData = base64_encode($vaccination['pet_image']);
                                $src = 'data:image/jpeg;base64,' . $imageData;
                                ?>
                                <img src="<?php echo $src; ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-fluid me-3" style="width: 80px; height: 80px; border-radius: 50%;">
                                <div>
                                    <h6><?php echo htmlspecialchars($vaccination['pet_name']); ?></h6>
                                    <p class="text-dark"><?php echo date('F j, Y', strtotime($vaccination['schedule'])); ?> (Today)</p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <!-- Missed Vaccinations Section -->
                    <?php if ($missed): ?>
                        <h6 class="text-danger">Missed Vaccinations</h6>
                        <?php foreach ($missed as $vaccination): ?>
                            <div class="d-flex mb-3">
                                <?php
                                $imageData = base64_encode($vaccination['pet_image']);
                                $src = 'data:image/jpeg;base64,' . $imageData;
                                ?>
                                <img src="<?php echo $src; ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-fluid me-3" style="width: 80px; height: 80px; border-radius: 50%;">
                                <div>
                                    <h6><?php echo htmlspecialchars($vaccination['pet_name']); ?></h6>
                                    <p class="text-danger"><?php echo date('F j, Y', strtotime($vaccination['schedule'])); ?> (Missed)</p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>

                    <!-- Upcoming Vaccinations Section -->
                    <?php if ($upcoming): ?>
                        <h6 class="text-success">Upcoming Vaccinations</h6>
                        <?php foreach ($upcoming as $vaccination): ?>
                            <div class="d-flex mb-3">
                                <?php
                                $imageData = base64_encode($vaccination['pet_image']);
                                $src = 'data:image/jpeg;base64,' . $imageData;
                                ?>
                                <img src="<?php echo $src; ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-fluid me-3" style="width: 80px; height: 80px; border-radius: 50%;">
                                <div>
                                    <h6><?php echo htmlspecialchars($vaccination['pet_name']); ?></h6>
                                    <p class="text-success"><?php echo date('F j, Y', strtotime($vaccination['schedule'])); ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <a href="notification.php" class="btn btn-primary">View</a>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
    <div class="container mt-4">
        <h2 class="top-selling-header">Top Selling Products</h2>
        <div class="product-container">
            <button class="scroll-btn left" onclick="scrollLeft()">&lt;</button>
            <div class="product-list">
                <?php if (count($top_selling_products) > 0): ?>
                    <?php foreach ($top_selling_products as $row): ?>
                        <div class="product-card" onclick="window.location.href='product_detail.php?id=<?php echo $row['id']; ?>'">
                            <?php
                            // Convert BLOB to base64
                            $imageData = base64_encode($row['image']);
                            $src = 'data:image/jpeg;base64,' . $imageData;
                            ?>
                            <img src="<?php echo $src; ?>" alt="<?php echo htmlspecialchars($row['name']); ?>" />
                            <h5>
                                <?php 
                                $productName = htmlspecialchars($row['name']); 
                                echo strlen($productName) > 40 ? substr($productName, 0, 40) . '...' : $productName; 
                                ?>
                            </h5>

                            <div class="product-price">PHP <?php echo number_format($row['price'], 2); ?></div>
                            <div class="stock">
                                <?php if ($row['stock'] > 0): ?>
                                    <?php echo $row['stock']; ?> in stock
                                <?php else: ?>
                                    <span class="out-of-stock">Out of stock</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No products found.</p>
                <?php endif; ?>
            </div>
            <button class="scroll-btn right" onclick="scrollRight()">&gt;</button>
        </div>
    </div>
    <?php include 'footer.php'; ?>

    <script>
           document.addEventListener('DOMContentLoaded', function () {
        <?php if ($vaccinations): ?>
            var vaccinationReminder = new bootstrap.Modal(document.getElementById('vaccinationReminder'));
            vaccinationReminder.show();
        <?php endif; ?>
    });
        // Scroll the product list to the left
        function scrollLeft() {
            const productList = document.querySelector('.product-list');
            productList.scrollBy({ left: -200, behavior: 'smooth' });
        }

        // Scroll the product list to the right
        function scrollRight() {
            const productList = document.querySelector('.product-list');
            productList.scrollBy({ left: 200, behavior: 'smooth' });
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

