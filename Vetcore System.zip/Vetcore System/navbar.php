<?php   
require "logics/sqlcon.php"; // Include your database connection
$cart_count = 0;
$notification_count = 0; // Initialize notification count

if (isset($_SESSION['U_id'])) {
    $user_id = $_SESSION['U_id'];

    // Cart count
    $sql = "SELECT SUM(quantity) AS total_items FROM cart WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$user_id]);
    $cart_count = $stmt->fetchColumn() ?: 0; // Default to 0 if no items

    // Notification count - updated to include missed schedules
    $sql = "SELECT COUNT(*) AS total_notifications 
            FROM pet_details 
            WHERE (schedule = CURDATE() OR schedule < CURDATE()) AND owner_id = :owner_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':owner_id' => $user_id]);
    $notification_count = $stmt->fetchColumn() ?: 0; // Default to 0 if no notifications
}

// Get the current page name
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <style>
        body {
            margin-top: 70px; /* Add top margin to avoid content being hidden behind the navbar */
        }
        .navbar {
            background-color: #28a745; /* Keep navbar background color */
            position: fixed; /* Fix the navbar to the top */
            top: 0; /* Align to the top */
            left: 0; /* Align to the left */
            right: 0; /* Align to the right */
            z-index: 1000; /* Make sure the navbar is above other content */
        }
        .navbar-brand {
            color: #fff; /* Logo text color */
        }
        .navbar-nav {
            display: flex;
            align-items: center;
        }
        .navbar-nav .nav-item {
            margin-right: 20px; /* Spacing between nav items */
            position: relative; /* Allow for underline effect */
        }
        .navbar-nav .nav-item:hover .nav-link {
            color: #d4d4d4; /* Change link color on hover */
        }
        .navbar-nav .nav-link {
            color: #fff; /* Link text color */
            padding: 10px; /* Reduce padding for a cleaner look */
            display: flex; /* Flex for icon and text alignment */
            align-items: center; /* Center align items */
            border-radius: 5px; /* Add border radius to nav links */
            transition: background-color 0.3s; /* Transition for background color */
        }
        .navbar-nav .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1); /* Background on hover */
        }
        .navbar-nav .nav-link img {
            margin-right: 8px; /* Space between icon and text */
        }
        /* Active state on li (instead of a) with underline */
        .navbar-nav .nav-item.active {
            border-bottom: 3px solid #fff; /* Add thick underline on active item */
        }
        .navbar-nav .nav-item.active .nav-link {
            color: #fff; /* Ensure active link text color is white */
            background-color: rgba(255, 255, 255, 0.2);
        }
        /* Add some transition effects for smooth hover and active state */
        .navbar-nav .nav-item,
        .navbar-nav .nav-link {
            transition: color 0.3s ease, border-bottom 0.3s ease;
        }
        .navbar-brand img {
            border-radius: 50%; /* Make the logo image round */
            width: 50px; /* Set the width of the logo */
            height: 50px; /* Set the height of the logo */
        }
        .cart-icon, .notification-icon {
            position: relative;
        }
        .badge {
            position: absolute;
            top: -10px;
            right: -10px;
            background-color: #dc3545; /* Bootstrap danger color */
            color: white;
            border-radius: 50%; /* Make badge round */
            padding: 5px 8px;
            font-size: 0.8rem;
        }
        .icon {
            width: 32px; /* Change this value to adjust the size */
            height: 32px; /* Change this value to adjust the size */
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand" href="home.php">
                <img src="images/vetcore logo.jpg" alt="Logo" class="d-inline-block align-top"> 
                <strong style="font-size: 2rem; color: #fff;">Vetcore</strong>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item <?php echo ($current_page == 'home.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="home.php" title="Home">
                            <img src="images/doghome.png" alt="Home" class="icon">
                            <?php echo ($current_page == 'home.php') ? 'Home' : ''; // Show name only on Home page ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'order.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="order.php" title="Shop">
                            <img src="images/shop.png" alt="Shop" class="icon">
                            <?php echo ($current_page == 'order.php') ? 'Shop' : ''; // Show name only on Shop page ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'myorders.php' || $current_page == 'order_details.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="myorders.php" title="My Orders">
                            <img src="images/myorders.png" alt="My Orders" class="icon">
                            <?php echo ($current_page == 'myorders.php') ? 'My Orders' : ''; ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'owner_profile.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="owner_profile.php" title="My Profile">
                            <img src="images/my-profile.png" alt="My Profile" class="icon">
                            <?php echo ($current_page == 'owner_profile.php') ? 'My Profile' : ''; ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'pets.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="pets.php" title="My Pets">
                            <img src="images/pawprint.png" alt="My Profile" class="icon">
                            <?php echo ($current_page == 'pets.php') ? 'My Pets' : ''; ?>
                        </a>
                    </li>
                    <li class="nav-item cart-icon <?php echo ($current_page == 'cart.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="cart.php" title="Cart">
                            <img src="images/cart.png" alt="Cart" class="icon">
                            <?php echo ($current_page == 'cart.php') ? 'Cart' : ''; ?>
                            <?php if ($cart_count > 0): ?>
                                <span class="badge"><?php echo $cart_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item notification-icon <?php echo ($current_page == 'notification.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="notification.php" title="Notifications">
                            <img src="images/notice.png" alt="Notifications" class="icon">
                            <?php echo ($current_page == 'notification.php') ? '' : ''; ?>
                            <?php if ($notification_count > 0): ?>
                                <span class="badge"><?php echo $notification_count; ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <li class="nav-item <?php echo ($current_page == 'logout.php') ? 'active' : ''; ?>">
                        <a class="nav-link" href="logout.php" title="Log Out">
                            <img src="images/logout.png" alt="Log Out" class="icon">
                            <?php echo ($current_page == 'logout.php') ? 'Log Out' : ''; ?>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Add your content here -->
</body>
</html>
