<?php
require 'logics/sqlcon.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['U_id'];

// Retrieve owner information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $user_id]);
$owner = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$owner) {
    echo "Owner not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Toggle the status between "enabled" and "disabled"
    $new_2fa_status = $owner['authentication'] === 'enabled' ? 'disabled' : 'enabled';

    // Update the 2FA status
    $sql = "UPDATE users SET authentication = :new_status WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':new_status' => $new_2fa_status, ':id' => $user_id]);

    // Redirect back to profile page
    $_SESSION['success'] = '2FA ' . ($new_2fa_status === 'enabled' ? 'activated' : 'deactivated') . ' successfully.';
    header("Location: owner_profile.php");
    exit();
}

// Retrieve pets for the owner
$sql = "SELECT pet_name, pet_image, image_name, pet_id FROM pet_details WHERE owner_id = :owner_id";
$stmt = $conn->prepare($sql);
$stmt->execute([':owner_id' => $user_id]);
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Retrieve order history (Assuming there is an 'orders' table)
$sql = "SELECT 
            COUNT(DISTINCT CASE WHEN order_status = 'Collected' THEN order_number END) AS picked_count,
            COUNT(DISTINCT CASE WHEN order_status = 'Pending' THEN order_number END) AS pending_count,
            COUNT(DISTINCT CASE WHEN order_status = 'To Pick Up' THEN order_number END) AS ready_count
        FROM orders 
        WHERE customer_id = :user_id";
$stmt = $conn->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$order_counts = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="images/vetcore logo.jpg" sizes="16x16">
    <title>Owner Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .con { 
            display: flex;
            justify-content: space-between;
            padding: 10px;
        }

        .con1 {
            width: 30%;                   
            height: auto;                 
            background-color: rgba(255, 255, 255, 0.9); 
            border-radius: 10px;  
            padding: 20px;
            margin-left: 99px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .con2 {
            width: 50%;                   
            height: 315px;                  
            margin-top: 70px;
            margin-right: 100px; 
            background-color: rgba(255, 255, 255, 0.9); 
            border-radius: 10px;  
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .con3 {
            width: 90%;                  
            height: auto;                 
            background-color: rgba(255, 255, 255, 0.9); 
            border-radius: 10px;  
            padding: 20px; 
            margin-left: 68px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .img1 {
            width: 100px;
            height: 100px;
            border-radius: 50%; /* Circular image */
            border: 2px solid #28a745; /* Green border */
        }

        .img2 {
            width: 150px;
            height: 150px;
            background-image: url('images/pawp1.png');
            background-size: cover;    
            background-position: center; 
            background-repeat: no-repeat; 
            display: flex;               
            justify-content: center;      
            align-items: center;  
            border-radius: 10px; /* Rounded corners */
            margin-top: -10px; /* Space between cards */
        }

        .img2 p {
            text-align: center;
            margin-top: 50px;
            font-weight: bold; /* Bold text */
            font-size: 1.5rem; /* Larger text size */
        }

        .flex-container {
            display: flex;                  
            justify-content: space-around;  
            align-items: center;            
        }

        button {
            background-color: #28a745; /* Bootstrap green */
            color: white; 
            border: none; 
            padding: 10px 15px; 
            border-radius: 5px; 
            cursor: pointer; 
            transition: background-color 0.3s; /* Smooth transition */
        }

        button:hover {
            background-color: #218838; /* Darker green on hover */
        }

        h1, h2 {
            color: #28a745; /* Title color */
        }

        p {
            margin: 5px 0; /* Small margin for paragraphs */
        }
        .sz{
            background-color: #28a745;
            border-radius: 10px;
            width: 149px;
            height: auto;
        }
        .sz h5  {
            text-align: center;
            font-weight: bold; /* Bold text */
            font-size: 1.5rem;
            color: white;
            margin-top: 10px;
        }
        .s1{
            text-align: center;
            font-weight: bold; /* Bold text */
        }
        .butt1{
            margin-left: 41%;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php include 'navbar.php'; ?>
    <div class="con">
        <div class="con1 text-center">
            <h1 class="text-success mb-4">Profile</h1>
            <img class="img1 rounded-circle mb-3" src="images/my-profile.png" alt="Profile Image" style="width: 150px; height: 150px; object-fit: cover;">
            <div class="card shadow border-0 p-4">
                <h5 class="card-title">Name: <?php echo htmlspecialchars($owner['fname']) . " " . htmlspecialchars($owner['lname']); ?></h5>
                <p class="card-text">Mobile Number: <?php echo htmlspecialchars($owner['phone_number']); ?></p>
                <p class="card-text">
                    Authentication: <?php echo $owner['authentication'] === 'enabled' ? 'Active' : 'Disabled'; ?>
                </p>
                <form action="" method="POST">
                    <button type="submit" class="btn btn-success">
                        <?php echo $owner['authentication'] === 'enabled' ? 'Deactivate 2FA' : 'Activate 2FA'; ?>
                    </button>
                </form>
            </div>
        </div>

        <!-- Order History Section -->
        <div class="con2">
            <h2 class="s1">Order History</h2>
            <div class="flex-container">
                <div class="sz">
                    <h5>Completed</h5>
                    <div class="img2">
                        <p><?php echo $order_counts['picked_count']; ?></p>
                    </div>
                </div>
                <div class="sz">
                    <h5>Pending</h5>
                    <div class="img2">
                        <p><?php echo $order_counts['pending_count']; ?></p>
                    </div>
                </div>
                <div class="sz">
                    <h5>To Pick Up</h5>
                    <div class="img2">
                        <p><?php echo $order_counts['ready_count']; ?></p>
                    </div>
                </div>
            </div>
                <a href="myorders.php" class="btn btn-primary butt1">View Orders</a>
        </div>
    </div>

    <!-- Pets Section -->
    <div class="con3">
        <h2 class="text-center text-success mb-4">Your Pets</h2>
        <div class="row">
            <?php foreach ($pets as $pet): ?>
                <div class="col-md-4 mb-4">
                    <div class="card shadow border-0">
                        <div class="text-center">
                            <img class="img1 rounded-circle" src="data:image/jpeg;base64,<?php echo base64_encode($pet['pet_image']); ?>" alt="<?php echo htmlspecialchars($pet['pet_name']); ?>" style="width: 150px; height: 150px; object-fit: cover;">
                        </div>
                        <div class="card-body text-center">
                            <h5 class="card-title"><?php echo htmlspecialchars($pet['pet_name']); ?></h5>
                            <a href="pets.php?pet_id=<?php echo $pet['pet_id']; ?>" class="btn btn-success">View Details</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>


    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
