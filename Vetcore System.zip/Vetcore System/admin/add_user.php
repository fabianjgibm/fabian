<?php
require "../logics/sqlcon.php";
session_start();
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add New User</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        /* Form Card Styling */
        .form-card {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Header Styling */
        .form-card-header {
            background-color: #00a651;
            color: white;
            padding: 20px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            text-align: center;
        }

        /* Form Group Margins */
        .form-group {
            margin-bottom: 20px;
        }

        /* Input Field Styling */
        .form-control {
            height: calc(2.5em + 0.75rem + 2px);
            border-radius: 0.375rem;
        }

        /* Submit Button */
        .submit-btn {
            width: 100%;
            padding: 12px;
        }

        /* Adjust content position */
        .content {
            margin-left: 220px; /* Adjust according to the navbar width */
            padding: 20px;
        }
        .tar2 {
            margin-left: 44%;
            margin-top: 2%;
        }
    </style>
</head>
<body>

    <?php include 'admin_navbar.php'; ?>

    <div class="content">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-danger mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>
                <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
                ?>
            </span>
        </div>
    <?php endif; ?>
        <div class="form-card">
            <div class="form-card-header">
                <h2>Add New User</h2>
            </div>
            <div class="card-body p-4">
                <form method="POST" action="add_user1.php">
                    <div class="form-group">
                        <label for="fname">First Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" pattern="[A-Za-z]+" required placeholder="Enter First Name">
                    </div>

                    <div class="form-group">
                        <label for="lname">Last Name</label>
                        <input type="text" class="form-control" id="lname" name="lname" pattern="[A-Za-z]+" required placeholder="Enter Last Name">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required placeholder="Enter Email">
                    </div>

                    <div class="form-group">
                        <label for="phone_number">Phone Number</label>
                        <input type="text" class="form-control" id="phone_number" name="phone_number" 
                        pattern="09\d{9}" title="Please enter an 11-digit phone number starting with '09'" required placeholder="Enter Phone Number">
                    </div>

                    <div class="form-group">
                        <label for="user_type">User Type</label>
                        <select class="form-control" id="user_type" name="user_type" required>
                            <option value="veterinarian">Veterinarian</option>
                            <option value="staff">Staff</option>
                            <option value="customer">Customer</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" class="form-control" id="password" name="password" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required placeholder="Enter Password">
                    </div>

                    <button type="submit" class="btn btn-primary submit-btn">Add User</button>
                </form>
                <a href="view_user.php" class="tar2 btn btn-success">Cancel</a>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
