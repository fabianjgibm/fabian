<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Get today's date
$today = date('Y-m-d');

// Query to count orders by status and group by order_number for today
$orderQuery = "
    SELECT order_status, COUNT(DISTINCT order_number) as order_count
    FROM orders
    WHERE DATE(order_date_time) = :today
    GROUP BY order_status
";
$orderStmt = $conn->prepare($orderQuery);
$orderStmt->execute([':today' => $today]);
$orderResults = $orderStmt->fetchAll(PDO::FETCH_ASSOC);

// Initialize order counts
$pendingCount = 0;
$toPickUpCount = 0;
$collectedCount = 0;
$cancelledCount = 0;

foreach ($orderResults as $order) {
    switch ($order['order_status']) {
        case 'Pending':
            $pendingCount = $order['order_count'];
            break;
        case 'To Pick Up':
            $toPickUpCount = $order['order_count'];
            break;
        case 'Collected':
            $collectedCount = $order['order_count'];
            break;
        case 'Cancelled':
            $cancelledCount = $order['order_count'];
            break;
    }
}

// Query to count pets with vaccinations scheduled for today
$vaccinationQuery = "
    SELECT COUNT(*) as vaccination_count
    FROM pet_details
    WHERE DATE(schedule) = :today
";
$vaccinationStmt = $conn->prepare($vaccinationQuery);
$vaccinationStmt->execute([':today' => $today]);
$vaccinationResult = $vaccinationStmt->fetch(PDO::FETCH_ASSOC);
$vaccinationCount = $vaccinationResult['vaccination_count'] ?? 0;

$upcomingVaccinationQuery = "
    SELECT COUNT(*) as upcoming_vaccination_count
    FROM pet_details
    WHERE DATE(schedule) BETWEEN :startOfWeek AND :endOfWeek
";
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$endOfWeek = date('Y-m-d', strtotime('sunday this week'));

$upcomingVaccinationStmt = $conn->prepare($upcomingVaccinationQuery);
$upcomingVaccinationStmt->execute([':startOfWeek' => $startOfWeek, ':endOfWeek' => $endOfWeek]);
$upcomingVaccinationResult = $upcomingVaccinationStmt->fetch(PDO::FETCH_ASSOC);
$upcomingVaccinationCount = $upcomingVaccinationResult['upcoming_vaccination_count'] ?? 0;

// Query for missed vaccinations
$missedVaccinationQuery = "
    SELECT COUNT(*) as missed_vaccination_count
    FROM pet_details
    WHERE DATE(schedule) < :today
";
$missedVaccinationStmt = $conn->prepare($missedVaccinationQuery);
$missedVaccinationStmt->execute([':today' => $today]);
$missedVaccinationResult = $missedVaccinationStmt->fetch(PDO::FETCH_ASSOC);
$missedVaccinationCount = $missedVaccinationResult['missed_vaccination_count'] ?? 0;

// Query for low stock products
// Query for running low stock products including those with 0 stock
$lowStockQuery = "
    SELECT p.id, p.name, p.stock_limit, 
           COALESCE(SUM(CASE 
               WHEN pd.expiration_date > :today OR pd.expiration_date = '0000-00-00' 
               THEN pd.remaining_stock 
               ELSE 0 
           END), 0) AS total_remaining_stock
    FROM product p
    LEFT JOIN product_detail pd ON p.id = pd.product_id
    GROUP BY p.id
    HAVING total_remaining_stock <= (p.stock_limit * 0.20) OR total_remaining_stock = 0
    ORDER BY total_remaining_stock ASC
";

// Prepare and execute the statement
$today = date('Y-m-d'); // Get today's date
$lowStockStmt = $conn->prepare($lowStockQuery);
$lowStockStmt->execute([':today' => $today]);
$lowStockResults = $lowStockStmt->fetchAll(PDO::FETCH_ASSOC);

$startOfMonth = date('Y-m-01');
// Get the last day of the current month
$endOfMonth = date('Y-m-t');

// Query to get the most bought products for this month
$mostBoughtQuery = "
    SELECT p.id, p.name, SUM(o.quantity) as total_sold
    FROM orders o
    JOIN product p ON o.product_id = p.id
    WHERE o.order_status = 'Collected'  -- Consider only collected orders
    AND DATE(o.order_date_time) BETWEEN :startOfMonth AND :endOfMonth
    GROUP BY p.id
    ORDER BY total_sold DESC
";

// Prepare and execute the statement
$mostBoughtStmt = $conn->prepare($mostBoughtQuery);
$mostBoughtStmt->execute([
    ':startOfMonth' => $startOfMonth,
    ':endOfMonth' => $endOfMonth
]);
$mostBoughtResults = $mostBoughtStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Dashboard</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }

        .content {
            margin-left: 200px;
            padding-top: 100px;
            padding-bottom: 20px;
        }

        /* Paw card styling */
        .paw-card {
            background-color: white; /* Set to transparent to avoid background conflict */
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3); /* Shadow for depth */
            position: relative; /* Allows positioning of the label */
            text-align: center; /* Center content within card */
        }

        .paw-label {
            font-size: 24px; /* Increased font size for the label */
            font-weight: bolder; /* Make the label bolder */
            color: white; /* Dark color for better contrast */
            margin-bottom: 0px; /* Space below label */
            background-color: #00a651; /* Green background */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            border-radius: 10px; /* Rounded corners */
        }

        .paw-content {
            display: flex; /* Use flexbox for alignment */
            justify-content: center; /* Center the smaller paw */
            align-items: center; /* Center vertically */
        }

        .paw-smaller {
            width: 140px; /* Adjust width for paw background */
            height: 140px; /* Adjust height for paw background */
            background-image: url('../images/pawp1.png'); /* Background image for paw */
            background-size: contain; /* Make the image fit within the box */
            background-position: center;
            background-repeat: no-repeat;
            border-radius: 10px; /* Rounded corners */
            display: flex; /* Flexbox for centering the count */
            justify-content: center; /* Center the count horizontally */
            align-items: center; /* Center the count vertically */
        }

        .paw-count {
            font-size: 36px; /* Adjusted size for count */
            font-weight: bold; /* Bold count */
            color: #00a651; /* Use the same green color as the sidebar */
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5); /* Shadow for better contrast */
            margin-top: 30px;
        }


        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .report-header h2 {
            margin: 0;
        }
        .report-header {
            background-color: #00a651; /* Green background */
            margin-top: -69px; /* Adjust as needed */
            color: white; /* White text */
            text-align: center; /* Center the text */
            width: 500px; /* Fixed width */
            margin-left: auto; /* Center horizontally */
            margin-right: auto; /* Center horizontally */
            padding: 15px 0; /* Add padding for spacing */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Subtle shadow for depth */
        }
        .hding{
            width: 230px;
            background-color: #00a651; /* Green background */
            border-radius: 5px;
            color: white;
            display: flex; /* Flexbox */
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally if needed */
        }
        .hding3{
            width: 450px;
            background-color: #00a651; /* Green background */
            border-radius: 5px;
            color: white;
            display: flex; /* Flexbox */
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally if needed */
        }

        .hding2{
            width: 600px;
            background-color: #00a651; /* Green background */
            border-radius: 5px;
            color: white;
            display: flex; /* Flexbox */
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally if needed */
        }
        .t1{
            background-color: white;
            border-radius: 5px;
            margin-left: 4px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <!-- Include the admin navbar -->
    <?php include 'admin_navbar.php'; ?>

<div class="container content">
    <!-- Report Header -->
    <div class="d-flex justify-content-center align-items-center report-header">
        <h2>Today's Report</h2>
    </div>
    <div class="row g-4 t1">        
        <div class="d-flex justify-content-center align-items-center">
            <h2 class="hding">Orders</h2>
        </div>
        <div class="col-md-3">
            <div class="card paw-card shadow">
                <div class="paw-label">Pending</div> <!-- Label above the paw -->
                    <div class="paw-content">
                        <div class="paw-smaller">
                            <div class="paw-count"><?= $pendingCount ?></div>
                        </div>
                    </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card paw-card shadow">
                <div class="paw-label">To Pick Up</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $toPickUpCount ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card paw-card shadow">
                <div class="paw-label">Collected</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $collectedCount ?></div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="card paw-card shadow">
                <div class="paw-label">Cancelled</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $cancelledCount ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 t1">
        <div class="d-flex justify-content-center align-items-center">
            <h2 class="hding">Vaccinations</h2>
        </div>
        
        <div class="col-md-4">
            <div class="card paw-card shadow">
                <div class="paw-label">Vaccinations Today</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $vaccinationCount ?></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Upcoming Vaccinations This Week Card -->
        <div class="col-md-4">
            <div class="card paw-card shadow">
                <div class="paw-label">Upcoming This Week</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $upcomingVaccinationCount ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Missed Vaccinations Card -->
        <div class="col-md-4">
            <div class="card paw-card shadow">
                <div class="paw-label">Missed Vaccinations</div>
                <div class="paw-content">
                    <div class="paw-smaller">
                        <div class="paw-count"><?= $missedVaccinationCount ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 t1">
    <div class="d-flex justify-content-center align-items-center">
        <h2 class="hding3">Running Low Stock Products</h2>
    </div>

    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Stock Limit</th>
                        <th>Total Stock</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($lowStockResults)): ?>
                        <?php foreach ($lowStockResults as $product): ?>
                            <tr>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td><?= htmlspecialchars($product['stock_limit']) ?></td>
                                <td><?= htmlspecialchars($product['total_remaining_stock']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="3" class="text-center">No running low stock products available.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="row g-4 t1">
    <div class="d-flex justify-content-center align-items-center">
        <h2 class="hding2">Most Bought Products This Month</h2>
    </div>

    <div class="col-md-12">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Total Sold</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($mostBoughtResults)): ?>
                        <?php foreach ($mostBoughtResults as $product): ?>
                            <tr>
                                <td><?= htmlspecialchars($product['name']) ?></td>
                                <td><?= htmlspecialchars($product['total_sold']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="2" class="text-center">No products sold this month.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


</div>

</div>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
