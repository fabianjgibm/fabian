<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php";  
session_start();
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}
// Initialize product variable
$product = null;
// Fetch product details if product_code is set in the URL
if (isset($_GET['product_code'])) {
    $product_code = $_GET['product_code'];

    // Get product details and remaining stock by product_code
    $sqlGetProduct = "SELECT p.name, p.image, p.stock_limit, pd.product_code, pd.remaining_stock 
                      FROM product p 
                      JOIN product_detail pd ON p.id = pd.product_id 
                      WHERE pd.product_code = ? 
                      AND (pd.expiration_date IS NULL OR pd.expiration_date > NOW()) 
                      LIMIT 1";
    $stmt = $conn->prepare($sqlGetProduct);
    $stmt->execute([$product_code]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Handle stock update
if (isset($_POST['update_stock'])) {
    $product_code = $_POST['product_code']; // Use product_code instead of id
    $operation = $_POST['operation'];
    $new_stock = $_POST['new_stock'];

    // Validate stock
    if ($new_stock < 0) {
        echo "<script>alert('Stock cannot be negative.');</script>";
    } else {
        // Get current stock and stock limit by product_code
        $sqlGetStock = "SELECT remaining_stock, stock, (SELECT stock_limit FROM product WHERE id = pd.product_id) AS stock_limit, product_id 
                        FROM product_detail pd 
                        WHERE pd.product_code = ?";
        $stmt = $conn->prepare($sqlGetStock);
        $stmt->execute([$product_code]);
        $current_stock = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($current_stock) {
            $product_id = $current_stock['product_id'];
            $current_remaining_stock = $current_stock['remaining_stock'];
            $current_total_stock = $current_stock['stock'];
            $stock_limit = $current_stock['stock_limit'];

            // Calculate updated stock
            if ($operation === 'add') {
                $updated_remaining_stock = $current_remaining_stock + $new_stock;
                $updated_total_stock = $current_total_stock + $new_stock;

                // Check if updated stock exceeds stock limit
                if ($updated_remaining_stock > $stock_limit) {
                    $_SESSION['success'] = "You cannot add more stock, it exceeds the stock limit.";
                    header("Location: edit_stock.php?product_code=$product_code"); // Redirect back to the page
                    exit();
                } else {
                    // Update both the remaining_stock and stock columns by product_code
                    $sqlUpdateStock = "UPDATE product_detail SET remaining_stock = ?, stock = ? WHERE product_code = ?";
                    $stmt = $conn->prepare($sqlUpdateStock);
                    $stmt->execute([$updated_remaining_stock, $updated_total_stock, $product_code]);

                    // Log the addition in the audit trail
                    $userID = $_SESSION['U_id'];
                    $userType = $_SESSION['U_type'];
                    $action = "Added $new_stock units to product (Code: $product_code). Previous remaining stock: $current_remaining_stock, New remaining stock: $updated_remaining_stock.";
                    save_audit_trail($userID, $action, $userType);

                    $_SESSION['success'] = "Stock updated successfully.";
                    header("Location: product_list.php"); // Redirect back to manage products
                    exit();
                }
            } else {
                // Subtract operation
                $updated_remaining_stock = $current_remaining_stock - $new_stock;
                $updated_total_stock = $current_total_stock - $new_stock;

                // Validate for negative stock
                if ($updated_remaining_stock < 0 || $updated_total_stock < 0) {
                    echo "<script>alert('Stock cannot be negative.');</script>";
                } else {
                    // Update both the remaining_stock and stock columns by product_code
                    $sqlUpdateStock = "UPDATE product_detail SET remaining_stock = ?, stock = ? WHERE product_code = ?";
                    $stmt = $conn->prepare($sqlUpdateStock);
                    $stmt->execute([$updated_remaining_stock, $updated_total_stock, $product_code]);

                    // Log the subtraction in the audit trail
                    $userID = $_SESSION['U_id'];
                    $userType = $_SESSION['U_type'];
                    $action = "Subtracted $new_stock units from product (Code: $product_code). Previous remaining stock: $current_remaining_stock, New remaining stock: $updated_remaining_stock.";
                    save_audit_trail($userID, $action, $userType);

                    $_SESSION['success'] = "Stock updated successfully.";
                    header("Location: product_list.php"); // Redirect back to manage products
                    exit();
                }
            }
        } else {
            echo "<script>alert('Product not found.');</script>";
        }
    }
}
$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Edit Stock</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .search-item {
            padding: 10px;
            cursor: pointer;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .search-item:hover {
            background-color: #e2e2e2;
        }
        #product_list {
            max-height: 200px;
            overflow-y: auto;
        }
        .content {
            margin-left: 300px; /* Matches the width of the sidebar */
            width: 70%;
        }
        .product-image {
            max-width: 100px; /* Set a max width for the image */
            max-height: 100px; /* Set a max height for the image */
        }
        .div1 {
            margin-top: 20px;
            margin-left: 265px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="d-flex justify-content-between align-items-center mb-4 div1">
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success mb-0 d-flex align-items-center" role="alert" style="width: auto;">
                    <span>
                        <?php 
                        echo $_SESSION['success']; 
                        unset($_SESSION['success']); // Clear the message after displaying
                        ?>
                    </span>
                </div>
            <?php endif; ?>
        </div>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card shadow-lg">
                        <div class="card-header bg-success text-white">
                            <h3 class="text-center">Edit Stock</h3>
                        </div>
                        <div class="card-body">
                            <?php if ($product): ?>
                                <div class="text-center mb-3">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($product['image']); ?>" alt="Product Image" class="product-image">
                                    <h4><?php echo htmlspecialchars($product['name']); ?></h4>
                                    <p>Product Code: <?php echo htmlspecialchars($product['product_code']); ?></p>
                                    <p>Remaining Stock: <?php echo htmlspecialchars($product['remaining_stock']); ?></p> <!-- Display remaining stock -->
                                    <p>Stock Limit: <?php echo htmlspecialchars($product['stock_limit']); ?></p> <!-- Display stock limit -->
                                </div>
                            <?php else: ?>
                                <p class="text-danger text-center">Product not found.</p>
                            <?php endif; ?>
                            <div id="editStockForm" class="form-section">
                                <form method="post" action="edit_stock.php?product_code=<?php echo htmlspecialchars($product_code); ?>">
                                    <div class="mb-3">
                                        <label for="new_stock" class="form-label">New Stock:</label>
                                        <input type="number" id="new_stock" name="new_stock" class="form-control" min="1" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Operation:</label>
                                        <div class="form-check">
                                            <input type="radio" id="add" name="operation" value="add" class="form-check-input" required>
                                            <label for="add" class="form-check-label">Add</label>
                                        </div>
                                        <div class="form-check">
                                            <input type="radio" id="subtract" name="operation" value="subtract" class="form-check-input" required>
                                            <label for="subtract" class="form-check-label">Subtract</label>
                                        </div>
                                    </div>
                                    <input type="hidden" name="product_code" value="<?php echo htmlspecialchars($product_code); ?>">
                                    <div class="text-center">
                                        <input type="submit" name="update_stock" class="btn btn-primary" value="Update Stock">
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="product_list.php" class="btn btn-secondary">Cancel</a>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
