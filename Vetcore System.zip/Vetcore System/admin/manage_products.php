<?php
require "../logics/sqlcon.php";
session_start();

if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Pagination variables
$limit = 30; // Number of products per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate the offset for the SQL query

// Handle search query and category filter
$searchQuery = isset($_POST['search']) ? trim($_POST['search']) : '';
$categoryFilter = isset($_POST['category']) ? trim($_POST['category']) : '';
$searchCondition = '';
$categoryCondition = '';

if ($searchQuery) {
    $searchCondition = "WHERE p.name LIKE :search ";
}

if ($categoryFilter) {
    $categoryCondition = $searchCondition ? "AND p.category = :category " : "WHERE p.category = :category ";
}

// Fetch total number of products for pagination
$totalSql = "SELECT COUNT(*) FROM product p $searchCondition $categoryCondition";
$totalStmt = $conn->prepare($totalSql);
if ($searchQuery) {
    $totalStmt->bindValue(':search', '%' . $searchQuery . '%');
}
if ($categoryFilter) {
    $totalStmt->bindValue(':category', $categoryFilter);
}
$totalStmt->execute();
$totalProducts = $totalStmt->fetchColumn();
$totalPages = ceil($totalProducts / $limit); // Calculate total pages

// Fetch products with pagination and filtering
$sql = "SELECT p.id, p.name, p.price, p.image, p.stock_limit, 
               IFNULL(SUM(pd.remaining_stock), 0) AS total_stock
        FROM product p
        LEFT JOIN product_detail pd ON p.id = pd.product_id
        AND (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW()) 
        $searchCondition $categoryCondition
        GROUP BY p.id, p.name, p.price, p.image
        ORDER BY p.id ASC
        LIMIT :limit OFFSET :offset"; // Add LIMIT and OFFSET

$productStmt = $conn->prepare($sql);
if ($searchQuery) {
    $productStmt->bindValue(':search', '%' . $searchQuery . '%');
}
if ($categoryFilter) {
    $productStmt->bindValue(':category', $categoryFilter);
}
$productStmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$productStmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$productStmt->execute();
$productResult = $productStmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch distinct categories for the filter
$categorySql = "SELECT DISTINCT category FROM product";
$categoryStmt = $conn->query($categorySql);
$categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>Manage Products</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 200px; /* Matches the width of the sidebar */
            padding: 20px;
            width: 85%;
        }

        /* Image styling */
        .item-image {
            width: 50px; /* Adjust as needed */
            height: auto;
            border-radius: 8px;
        }

        /* Product name styling */
        .product-name {
            max-width: 200px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        /* Tooltip styling */
        .tooltip-inner {
            max-width: 250px;
            white-space: normal;
        }
        .asd form {
             /* Light grey background */
            border-radius: 5px; /* Rounded corners */
            width: 600px; /* Fixed width for the form */
            height: 40px;
        }

        .asd form .form-label {
            font-weight: bold; /* Make label text bold */
            margin-right: 10px;
            margin-top: 15px;
            background-color: #00a651;
            color: white;
            width: 150px;
            height: 40px;
            display: flex; /* Flexbox */
            align-items: center; /* Center content vertically */
            justify-content: center; /* Center content horizontally if needed */
            border-radius: 5px;
        }


        .asd form .btn-primary {
            background-color: #007bff; /* Bootstrap primary color */
            border-color: #007bff; /* Button border color */
            margin-left: 0px;
            margin-top: 6px;
            width: 100px;
        }
        .asd form input {
            width: 300px;
        }
        .asd form .btn-primary:hover {
            background-color: #0056b3; /* Darker shade on hover */
            border-color: #0056b3; /* Border color on hover */
        }
        .inputa1{
            margin-top:10px;
            width: 30%;
            margin-right:10px;
        }
        .hding1{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 2% 0% 0% 34%;
        }
        .hding2{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 0% 0% 0% 34%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .asd1{
            margin-bottom: 100px;
        }
        .div1{
            display: flex;
        }
        .af1{
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>
                <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
                ?>
            </span>
        </div>
    <?php endif; ?>
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="hding1">Product Details</h2>
        </div>
        <div class="asd d-flex align-items-center">
            <form method="POST" class="d-flex align-items-center me-2">
                <input type="text" name="search" class="form-control inputa1" placeholder="Search Product Name" value="<?php echo htmlspecialchars($searchQuery); ?>" style="width: 300px;">
                <select name="category" class="form-select ms-2 af1" style="width: 200px;">
                    <option value="">View all</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo htmlspecialchars($category); ?>" <?php if ($category === $categoryFilter) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($category); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="submit" class="btn btn-primary ms-2 af1" value="Search">
            </form>
            <a href="add_item.php" class="btn btn-primary af1" role="button">Add New Product</a>
        </div>
        <div class="asd2">
            <table class="styled-table" id="productTable">
                <thead class="table-dark">
                    <tr>
                        <th>Product Image</th>
                        <th>Product Name</th>
                        <th>Product Price</th>
                        <th>Stock</th>
                        <th>Stock Limit</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($productResult) {
                        foreach ($productResult as $row) {
                            $fullName = htmlspecialchars($row["name"]);
                            $shortName = (strlen($fullName) > 40) ? substr($fullName, 0, 40) . '...' : $fullName;
                            echo "<tr>";
                            echo "<td><img src='data:image/jpeg;base64," . base64_encode($row['image']) . "' alt='Product Image' class='item-image'/></td>";
                            echo "<td class='product-name' data-bs-toggle='tooltip' data-bs-placement='top' title='" . $fullName . "'>" . $shortName . "</td>";
                            echo "<td>₱" . htmlspecialchars($row["price"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["total_stock"]) . "</td>";
                            echo "<td>" . htmlspecialchars($row["stock_limit"]) . "</td>";
                            echo "<td>
                                <a href='edit_item_price.php?id=" . $row["id"] . "' class='btn btn-sm btn-primary'>Edit Product</a>
                                <a href='add_stock.php?id=" . $row["id"] . "' class='btn btn-sm btn-primary'>Add Stock</a>
                            </td>"; // Edit button
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No products found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <nav aria-label="Page navigation">
            <ul class="pagination">
                <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($searchQuery); ?>&category=<?php echo urlencode($categoryFilter); ?>" tabindex="-1">Previous</a>
                </li>
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                    <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                        <a class="page-link" href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchQuery); ?>&category=<?php echo urlencode($categoryFilter); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                    <a class="page-link" href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($searchQuery); ?>&category=<?php echo urlencode($categoryFilter); ?>">Next</a>
                </li>
            </ul>
        </nav>
</body>
</html>



