<?php
require "../logics/sqlcon.php"; // Include your logic file
require "../logics/audit_trail.php";  
session_start();

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Get product ID from query parameters
$product_id = isset($_GET['id']) ? $_GET['id'] : null;

if ($product_id) {
    // Fetch product details
    $sql = "SELECT name, price, stock_limit, image FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$product) {
        echo "<script>alert('Product not found.'); window.location.href = 'manage_stock.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('No product selected.'); window.location.href = 'manage_stock.php';</script>";
    exit;
}

// Handle form submission for updating the price and stock limit
if (isset($_POST['update_details'])) {
    $new_price = $_POST['new_price'];
    $new_stock_limit = $_POST['new_stock_limit'];

    // Validate price and stock limit
    if ($new_price < 0 || $new_stock_limit < 0) {
        echo "<script>alert('Price and stock limit cannot be negative.');</script>";
    } else {
        // Update the product price and stock limit
        $sqlUpdate = "UPDATE product SET price = ?, stock_limit = ? WHERE id = ?";
        $stmt = $conn->prepare($sqlUpdate);
        $stmt->execute([$new_price, $new_stock_limit, $product_id]);

        $userID = $_SESSION['U_id']; // ID of the user who is updating the product
            $userType = $_SESSION['U_type']; // Type of the user (e.g., admin)
            $action = "Updated product (ID: $product_id): Price";
            save_audit_trail($userID, $action, $userType);
        
        $_SESSION['success'] = "Product Edits Applied";
        header("Location: manage_products.php");// Redirect back to the register page
        exit();
    }
}

// Close connection at the end
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Edit Item Price and Stock Limit</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
    </style>
</head>
<body>
<?php include 'admin_navbar.php'; ?>
<div class="content">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow-lg">
                    <div class="card-header bg-success text-white">
                        <h3 class="text-center">Edit Item Price and Stock Limit</h3>
                    </div>
                    <div class="card-body">
                        <form method="post" action="">
                            <div class="mb-3 text-center">
                                <!-- Display product image -->
                                <img src="data:image/jpeg;base64,<?php echo base64_encode($product['image']); ?>" alt="Product Image" class="img-thumbnail" style="width: 150px; height: 150px;">
                            </div>
                            <div class="mb-3">
                                <!-- Display product name -->
                                <label for="selected_product_name" class="form-label">Product Name:</label>
                                <input type="text" id="selected_product_name" class="form-control" value="<?php echo htmlspecialchars($product['name']); ?>" disabled>
                            </div>
                            <div class="mb-3">
                                <!-- Input for new price -->
                                <label for="new_price" class="form-label">New Price:</label>
                                <input type="number" id="new_price" name="new_price" class="form-control" value="<?php echo htmlspecialchars($product['price']); ?>" required>
                            </div>
                            <div class="mb-3">
                                <!-- Input for stock limit -->
                                <label for="new_stock_limit" class="form-label">New Stock Limit:</label>
                                <input type="number" id="new_stock_limit" name="new_stock_limit" class="form-control" value="<?php echo htmlspecialchars($product['stock_limit']); ?>" required>
                            </div>
                            <div class="text-center">
                                <input type="submit" name="update_details" class="btn btn-primary" value="Update Details">
                            </div>
                            <div class="text-center mt-3">
                                <a href="manage_products.php" class="btn btn-secondary">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
