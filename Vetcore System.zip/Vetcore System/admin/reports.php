<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Initialize an array for the sales amounts for each month
$monthlySalesAmounts = array_fill(1, 12, 0.0); // Array to hold sales amounts for each month (1-12)

// Get the current year
$currentYear = date('Y');

// Query to sum total amounts of paid orders by month for the current year
$sql = "SELECT MONTH(order_date_time) AS month, SUM(total_amount) AS total 
        FROM orders 
        WHERE YEAR(order_date_time) = :year AND payment_status = 'Paid' 
        GROUP BY month";

$stmt = $conn->prepare($sql);
$stmt->execute([':year' => $currentYear]);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fill the monthly sales amounts array
foreach ($results as $result) {
    $monthlySalesAmounts[(int)$result['month']] = (float)$result['total'];
}

// Initialize an array for the sales amounts for each day of the week
$weeklySalesAmounts = array_fill(0, 7, 0.0); // Array to hold sales amounts for each day of the week (0-Sunday, 6-Saturday)

// Get the current week range
$startOfWeek = date('Y-m-d', strtotime('monday this week'));
$endOfWeek = date('Y-m-d', strtotime('sunday this week'));

// Query to sum total amounts of paid orders for the current week
$sql = "SELECT DAYOFWEEK(order_date_time) AS day, SUM(total_amount) AS total 
        FROM orders 
        WHERE order_date_time BETWEEN :startOfWeek AND :endOfWeek AND payment_status = 'Paid' 
        GROUP BY day";

$stmt = $conn->prepare($sql);
$stmt->execute([':startOfWeek' => $startOfWeek, ':endOfWeek' => $endOfWeek]);
$weeklyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fill the weekly sales amounts array
foreach ($weeklyResults as $result) {
    $dayIndex = (int)$result['day'] - 1; // Adjust for PHP's DAYOFWEEK function (1-Sunday to 7-Saturday)
    $weeklySalesAmounts[$dayIndex] = (float)$result['total'];
}

?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 200px;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        .content1 {
            width: 820px;
            height: 400px;
            background-color: white;
            margin-bottom: 30px;
            margin-left: 160px; /* Spacing between charts */
        }
        .hding1{
            width: 400px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 2% 0% 2% 34%;
        }
    </style>
</head>
<body>
    <!-- Include the admin navbar -->
    <?php include 'admin_navbar.php'; ?>

    <div class="content">
        <h2 class="hding1">Monthly Sales for <?php echo $currentYear; ?></h2>
        <div class="content1">
            <canvas id="ordersChart" width="400" height="200"></canvas>
        </div>

        <h2 class="hding1">This Week's Sales</h2>
        <div class="content1">
            <canvas id="weeklySalesChart" width="400" height="200"></canvas>
        </div>
    </div>

    <script>
        const monthlySalesAmounts = <?php echo json_encode($monthlySalesAmounts); ?>;

        const ctx = document.getElementById('ordersChart').getContext('2d');
        const ordersChart = new Chart(ctx, {
            type: 'bar',
            data: {
                datasets: [{
                    label: 'Monthly Revenue from Paid Sales',
                    data: monthlySalesAmounts,
                    backgroundColor: 'rgba(40, 167, 69, 0.5)', // Bootstrap green
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Total Revenue (in currency)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Months'
                        }
                    }
                }
            }
        });

        // Weekly Sales Chart
        const weeklySalesAmounts = <?php echo json_encode($weeklySalesAmounts); ?>;

        const ctx2 = document.getElementById('weeklySalesChart').getContext('2d');
        const weeklySalesChart = new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: [
                    'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
                ],
                datasets: [{
                    label: 'Weekly Revenue from Paid Sales',
                    data: weeklySalesAmounts,
                    backgroundColor: 'rgba(40, 167, 69, 0.5)', // Bootstrap green
                    borderColor: 'rgba(40, 167, 69, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Total Revenue (in currency)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Days of the Week'
                        }
                    }
                }
            }
        });
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
