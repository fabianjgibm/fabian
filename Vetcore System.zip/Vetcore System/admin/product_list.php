<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}
$limit = 30;

// Get the current page number from the query string, if none set it defaults to 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Get the search query from the query string, if none set it defaults to an empty string
$searchQuery = isset($_GET['query']) ? $_GET['query'] : '';

// Calculate the starting record (offset)
$start = ($page - 1) * $limit;

// Fetch the total number of records excluding expired products
$sqlTotal = "SELECT COUNT(*) FROM product_detail pd 
             INNER JOIN product p ON pd.product_id = p.id 
             WHERE (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW())
             AND (p.name LIKE :search OR pd.product_code LIKE :search)";

$stmtTotal = $conn->prepare($sqlTotal);
$stmtTotal->execute([':search' => "%$searchQuery%"]);
$totalRecords = $stmtTotal->fetchColumn();

// Calculate total number of pages
$totalPages = ceil($totalRecords / $limit);

// Fetch the products for the current page, including those with '0000-00-00' expiration dates
$sqlCurrentItems = "SELECT pd.*, p.name 
                    FROM product_detail pd 
                    INNER JOIN product p ON pd.product_id = p.id 
                    WHERE (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW())
                    AND (p.name LIKE :search OR pd.product_code LIKE :search)
                    LIMIT :limit OFFSET :start";
$stmtCurrentItems = $conn->prepare($sqlCurrentItems);
$stmtCurrentItems->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
$stmtCurrentItems->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmtCurrentItems->bindParam(':start', $start, PDO::PARAM_INT);
$stmtCurrentItems->execute();
$currentItems = $stmtCurrentItems->fetchAll(PDO::FETCH_ASSOC);

$sqlCategories = "SELECT DISTINCT category FROM product";
$stmtCategories = $conn->prepare($sqlCategories);
$stmtCategories->execute();
$categories = $stmtCategories->fetchAll(PDO::FETCH_ASSOC);

// Get the selected category from the query string, if any
$categoryFilter = isset($_GET['category']) ? $_GET['category'] : '';

// Update the total records query to include category filter
$sqlTotal = "SELECT COUNT(*) FROM product_detail pd 
             INNER JOIN product p ON pd.product_id = p.id 
             WHERE (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW())
             AND (p.name LIKE :search OR pd.product_code LIKE :search)";

if (!empty($categoryFilter)) {
    $sqlTotal .= " AND p.category = :category";
}

$stmtTotal = $conn->prepare($sqlTotal);
$stmtTotal->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
if (!empty($categoryFilter)) {
    $stmtTotal->bindValue(':category', $categoryFilter, PDO::PARAM_STR);
}
$stmtTotal->execute();
$totalRecords = $stmtTotal->fetchColumn();

// Fetch products for the current page, applying the category filter if set
$sqlCurrentItems = "SELECT pd.*, p.name, p.category 
                    FROM product_detail pd 
                    INNER JOIN product p ON pd.product_id = p.id 
                    WHERE (pd.expiration_date IS NULL OR pd.expiration_date = '0000-00-00' OR pd.expiration_date > NOW())
                    AND (p.name LIKE :search OR pd.product_code LIKE :search)";

if (!empty($categoryFilter)) {
    $sqlCurrentItems .= " AND p.category = :category";
}

$sqlCurrentItems .= " LIMIT :limit OFFSET :start";
$stmtCurrentItems = $conn->prepare($sqlCurrentItems);
$stmtCurrentItems->bindValue(':search', "%$searchQuery%", PDO::PARAM_STR);
if (!empty($categoryFilter)) {
    $stmtCurrentItems->bindValue(':category', $categoryFilter, PDO::PARAM_STR);
}
$stmtCurrentItems->bindParam(':limit', $limit, PDO::PARAM_INT);
$stmtCurrentItems->bindParam(':start', $start, PDO::PARAM_INT);
$stmtCurrentItems->execute();
$currentItems = $stmtCurrentItems->fetchAll(PDO::FETCH_ASSOC);

// Fetch expiring and expired products (no changes)
$sqlExpiring = "
    SELECT pd.product_code, pd.remaining_stock, pd.expiration_date, p.name
    FROM product_detail pd
    JOIN product p ON pd.product_id = p.id
    WHERE pd.expiration_date > NOW() 
    AND pd.expiration_date <= DATE_ADD(NOW(), INTERVAL 7 DAY)
    AND pd.expiration_date != '0000-00-00'";
$expiringStmt = $conn->query($sqlExpiring);
$expiringProducts = $expiringStmt->fetchAll(PDO::FETCH_ASSOC);
$sqlExpired = "
    SELECT pd.id, pd.product_code, pd.remaining_stock, pd.expiration_date, p.name, pd.storage
    FROM product_detail pd
    JOIN product p ON pd.product_id = p.id
    WHERE pd.expiration_date < NOW()
    AND pd.expiration_date != '0000-00-00'
    AND pd.storage != 'Removed'";
$expiredStmt = $conn->query($sqlExpired);
$expiredProducts = $expiredStmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>View Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 200px; /* Matches the width of the sidebar */
            padding: 20px;
            width: 85%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .hding1{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 2% 0% 3% 34%;
        }
        .div1{
            display: flex;
        }
        .div1 form{
            display: flex;
        }
        .div1 form input{
            width: 300px;
            height: 40px;
            margin: 7px 10px 10px 10px;
        }
        .div1 form button{
            height: 40px;
        }
        .div1 a{
            height: 40px;
            margin: 7px 10px 10px 10px;
        }
        .div1 form select{
            height: 40px;
            width: 200px;
            margin: 7px 10px 10px 10px;
        }
        .modal-header {
        border-bottom: 2px solid #28a745;
    }

    .modal-footer {
        border-top: 1px solid #ddd;
    }

    .table th {
        background-color: #28a745;
        color: white;
    }

    .table td {
        vertical-align: middle;
    }

    .table-hover tbody tr:hover {
        background-color: rgba(0, 166, 81, 0.1); /* light green hover effect */
    }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>

    <div class="content">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>
                <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
                ?>
            </span>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['message'])): ?>
        <div class="alert alert-warning d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <?php
            echo $_SESSION['message'];
            unset($_SESSION['message']);
            ?>
        </div>
    <?php elseif (!empty($expiredProducts)): ?>
        <div class="alert alert-danger mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>You need to remove the expired items from the inventory.</span>
            <a href="expired_items.php" class="btn btn-danger ms-3">View Expired Items</a>
        </div>
    <?php endif; ?>
    <h2 class="hding1" id="currentStocksHeader">Current Stock</h2>

    <!-- Search Input for filtering by product name or code -->
    <div class="div1">
        <form action="" method="GET">
            <input type="text" id="searchCurrentInput" name="query" class="form-control inputa1" placeholder="Search by Product Code or Name" value="<?php echo htmlspecialchars($searchQuery); ?>">
            <select name="category" class="form-control inputa1 mt-2">
                <option value="">All Categories</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo htmlspecialchars($category['category']); ?>" <?php if ($categoryFilter == $category['category']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($category['category']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary mt-2">Search</button>
        </form>
        <a href="expired_items.php" class="btn btn-secondary af1">View Expired Stocks</a>
    </div>
    
    <!-- Table to display products -->
    <div class="table-responsive">
        <table class="styled-table" id="currentProductTable">
            <thead>
                <tr>
                    <th>Product Code</th>
                    <th>Product Name</th>
                    <th>Remaining Stock</th>
                    <th>Stock</th>
                    <th>Expiration Date</th>
                    <th>Added Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="currentProductTbody">
                <?php
                if (!empty($currentItems)) {
                    foreach ($currentItems as $row) {
                        $productName = htmlspecialchars($row['name']);
                        $shortName = (strlen($productName) > 40) ? substr($productName, 0, 40) . '...' : $productName;
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row['product_code']) . "</td>";
                        echo "<td><span data-bs-toggle='tooltip' title='" . $productName . "'>" . $shortName . "</span></td>";
                        echo "<td>" . htmlspecialchars($row['remaining_stock']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['stock']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['expiration_date']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['added_date']) . "</td>";
                        echo "<td><a href='edit_stock.php?product_code=" . htmlspecialchars($row['product_code']) . "' class='btn btn-sm btn-primary'>Edit Stock</a></td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No current products</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page - 1; ?>&query=<?php echo urlencode($searchQuery); ?>" tabindex="-1">Previous</a>
            </li>
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                    <a class="page-link" href="?page=<?php echo $i; ?>&query=<?php echo urlencode($searchQuery); ?>"><?php echo $i; ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
                <a class="page-link" href="?page=<?php echo $page + 1; ?>&query=<?php echo urlencode($searchQuery); ?>">Next</a>
            </li>
        </ul>
    </nav>
    </div>
    <div class="modal fade" id="expiringModal" tabindex="-1" role="dialog" aria-labelledby="expiringModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title" id="expiringModalLabel">Expiring Products</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <!-- Modal Body -->
            <div class="modal-body">
                <div class="table-responsive">
                    <table class="table table-striped table-hover text-center"> <!-- text-center for horizontal alignment -->
                        <thead class="thead-dark">
                            <tr>
                                <th>Product Code</th>
                                <th>Remaining Stock</th>
                                <th>Expiration Date</th>
                                <th>Product Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($expiringProducts): ?>
                                <?php foreach ($expiringProducts as $expiring): ?>
                                    <tr class="<?php echo $expiring['expiration_date'] == '0000-00-00' ? 'table-warning' : ''; ?>">
                                        <td class="align-middle"><?php echo htmlspecialchars($expiring['product_code']); ?></td> <!-- align-middle for vertical alignment -->
                                        <td class="align-middle"><?php echo htmlspecialchars($expiring['remaining_stock']); ?></td>
                                        <td class="align-middle">
                                            <?php echo $expiring['expiration_date'] != '0000-00-00' ? htmlspecialchars($expiring['expiration_date']) : 'N/A'; ?>
                                        </td>
                                        <td class="align-middle"><?php echo htmlspecialchars($expiring['name']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="text-center align-middle">No expiring products</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
            <!-- Modal Footer -->
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
        <!-- Call the modal to open on page load if there are expiring products -->
        <script>
            <?php if (!empty($expiringProducts)): ?>
                document.addEventListener('DOMContentLoaded', function () {
                    var expiringModal = new bootstrap.Modal(document.getElementById('expiringModal'));
                    expiringModal.show();
                });
            <?php endif; ?>
        </script>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
