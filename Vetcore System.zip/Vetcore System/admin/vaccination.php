<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Fetch all veterinarians for the dropdown
$sql_vets = "SELECT id, CONCAT(fname, ' ', lname) AS name FROM users WHERE user_type = 'veterinarian'";
$stmt_vets = $conn->prepare($sql_vets);
$stmt_vets->execute();
$veterinarians = $stmt_vets->fetchAll(PDO::FETCH_ASSOC);

// Check if pet_id is set in the URL
if (isset($_GET['pet_id'])) {
    $pet_id = $_GET['pet_id'];
    
    // Get pet details
    $sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name 
            FROM pet_details pd JOIN users u ON pd.owner_id = u.id 
            WHERE pd.pet_id = :pet_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':pet_id' => $pet_id]);
    $pet = $stmt->fetch(PDO::FETCH_ASSOC);

    $pet_type = $pet['pet_type'];

    $sql_vaccines = "SELECT id, vaccine_name FROM vaccines WHERE vc_type = :pet_type"; // Adjust this if vc_type has different values for dogs/cats
    $stmt_vaccines = $conn->prepare($sql_vaccines);
    $stmt_vaccines->execute([':pet_type' => $pet_type]);
    $vaccines = $stmt_vaccines->fetchAll(PDO::FETCH_ASSOC);
} else {
    header("Location: view_pet.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add Vaccination</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .search-result-item {
            cursor: pointer;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .search-result-item:hover {
            background-color: #e2e2e2;
        }
        #search_results {
            max-height: 200px;
            overflow-y: auto;
        }
        .vaccine-input-group {
            display: flex; /* Use flexbox for alignment */
            align-items: center; /* Center vertically */
        }

        .vaccine-input-group .form-control {
            flex: 1; /* Take available space */
        }
        .content {
            margin-left: 300px; /* Matches the width of the sidebar */
            width: 70%;
        }
    </style>
</head>
<body>
<div class="content">
        <?php include 'admin_navbar.php'; ?>
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card shadow-lg">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Add Vaccination Details</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="../logics/save_vaccination.php" onsubmit="return confirmScheduleOverwrite()">
                                <input type="hidden" id="pet_id" name="pet_id" value="<?php echo $pet_id; ?>"> <!-- Hidden input to store selected pet ID -->

                                <!-- Pet Image -->
                                <div class="text-center mb-3">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($pet['pet_image']); ?>" class="pet-image" alt="<?php echo htmlspecialchars($pet['pet_name']); ?>" style="width: 150px; height: auto; border-radius: 10px; border: 2px solid #00a651;">
                                </div>

                                <!-- Pet Name -->
                                <div class="text-center mb-3">
                                    <h4><?php echo htmlspecialchars($pet['pet_name']); ?></h4>
                                </div>

                                <!-- Owner's Name -->
                                <div class="text-center mb-3">
                                    <h5>Owner: <?php echo htmlspecialchars($pet['owner_name']); ?></h5>
                                </div>

                                <!-- Veterinarian -->
                                <div class="mb-3">
                                    <label for="veterinarian_id" class="form-label">Select Veterinarian</label>
                                    <select class="form-control" id="veterinarian_id" name="veterinarian_id" required>
                                        <option value="">Select a veterinarian</option>
                                        <?php foreach ($veterinarians as $veterinarian) { ?>
                                            <option value="<?php echo htmlspecialchars($veterinarian['id']); ?>">
                                                <?php echo htmlspecialchars($veterinarian['name']); ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                                <!-- Notes -->
                                <div class="mb-3">
                                    <label for="notes" class="form-label">Notes</label>
                                    <textarea name="notes" class="form-control" rows="3" placeholder="Enter notes"></textarea>
                                </div>
                                <!-- Vaccine List -->
                                <div class="mb-3">
                                    <label for="vaccine_names" class="form-label">Select Vaccines</label>
                                    <div id="vaccine_list">
                                        <div class="vaccine-input-group mb-2">
                                            <select class="form-control" name="vaccine_names[]">
                                                <option value="">Select a vaccine</option>
                                                <?php foreach ($vaccines as $vaccine) { ?>
                                                    <option value="<?php echo htmlspecialchars($vaccine['id']); ?>">
                                                        <?php echo htmlspecialchars($vaccine['vaccine_name']); ?>
                                                    </option>
                                                <?php } ?>
                                            </select>
                                            <button type="button" class="btn btn-success btn-sm ms-2" onclick="addVaccineDropdown()">Add</button>
                                        </div>
                                    </div>
                                </div>
                                <!-- Next Vaccination Date -->
                                <div class="mb-3">
                                    <label for="next_vaccination_date" class="form-label">Next Vaccination Date</label>
                                    <input type="date" class="form-control" name="next_vaccination_date">
                                </div>

                                <button type="submit" class="btn btn-primary w-100">Submit</button>
                                <div class="text-center mt-3">
                                    <a href="view_pet.php" class="btn btn-secondary">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <script>
        // Function to add vaccine input field
        function addVaccineDropdown() {
            var newFieldGroup = document.createElement('div');
            newFieldGroup.className = 'vaccine-input-group mb-2';

            var newSelect = document.createElement('select');
            newSelect.setAttribute('class', 'form-control');
            newSelect.setAttribute('name', 'vaccine_names[]');
            newSelect.setAttribute('required', 'required');

            var option = document.createElement('option');
            option.value = '';
            option.text = 'Select a vaccine';
            newSelect.appendChild(option);

            <?php foreach ($vaccines as $vaccine) { ?>
                var option = document.createElement('option');
                option.value = '<?php echo htmlspecialchars($vaccine['id']); ?>';
                option.text = '<?php echo htmlspecialchars($vaccine['vaccine_name']); ?>';
                newSelect.appendChild(option);
            <?php } ?>

            newFieldGroup.appendChild(newSelect);

            var addButton = document.createElement('button');
            addButton.setAttribute('type', 'button');
            addButton.setAttribute('class', 'btn btn-danger btn-sm ms-2');
            addButton.textContent = 'Remove';
            addButton.onclick = function() {
                newFieldGroup.remove();
            };

            newFieldGroup.appendChild(addButton);
            document.getElementById('vaccine_list').appendChild(newFieldGroup);
        }
        $(document).ready(function() {
    // On form submit
    $('form').on('submit', function(e) {
        e.preventDefault(); // Prevent default form submission

        var petId = $('#pet_id').val(); // Get the pet ID

        // Check for existing vaccination schedule
        $.ajax({
            url: '../logics/check_schedule.php',
            method: 'POST',
            data: { pet_id: petId },
            success: function(response) {
                if (response === 'exists') {
                    // Show confirmation dialog
                    if (confirm('There is already a vaccination schedule. Would you like to overwrite it?')) {
                        // If user confirms, submit the form
                        $('form')[0].submit(); // Submit the form
                    }
                } else {
                    // No existing schedule, submit the form
                    $('form')[0].submit(); // Submit the form
                }
            }
        });
    });
});

    </script>
</body>
</html>
