<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    // Redirect to login page or handle as appropriate
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    // Handle case where user is not found
    header("Location: ../login.php");
    exit();
}

// Search functionality
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
    $sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name 
            FROM pet_details pd 
            JOIN users u ON pd.owner_id = u.id
            WHERE pd.pet_name LIKE :search OR CONCAT(u.fname, ' ', u.lname) LIKE :search";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':search' => '%' . $search . '%']);
} else {
    // Retrieve all pet details if no search is performed
    $sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name 
            FROM pet_details pd 
            JOIN users u ON pd.owner_id = u.id";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
}
$pets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>View Pets</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
            color: #333;
        }
        .sidebar {
            width: 200px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 0;
        }

        .sidebar img {
            max-width: 100px;
            border-radius: 50%;
        }

        .sidebar h4 {
            margin-top: 10px;
            font-size: 1.5rem;
        }

        .nav-link:hover {
            background-color: #007e3a;
        }

        .content {
            margin-left: 200px;
            width: calc(100% - 200px);
        }

        .pet-card {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 20px;
            text-align: center;
        }

        .pet-card img {
            max-width: 150px;
            height: auto;
            border-radius: 5px;
        }
        .hding1{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: -2% 0% 2% 34%;
        }
        .asd{
            display: flex;
            margin-bottom: 10px;
        }
        .asd1{
            margin-right: 5px;
            width: 200;
        }
        .asd1 input{
            margin-right: 5px;
            width: 300px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
                <span>
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']); // Clear the message after displaying
                    ?>
                </span>
            </div>
        <?php endif; ?>
        </div>
        <div class="container mt-5">
            <div class="container mt-5 text-center">
                <h2 class="hding1">Pets</h2>
            </div>
            <div class="asd">
                <div class="asd1">
                    <form method="GET" action="">
                        <input type="text" name="search" class="form-control" placeholder="Search for pets or owners... tap enter" value="<?php echo htmlspecialchars($search); ?>">
                    </form>
                </div>
                <div class="asd2">
                    <a href="add_pet.php" class="btn btn-success">Add Pet</a>
                    <a href="vaccination_schedules.php" class="btn btn-primary">View Vaccination Schedules</a>
                    <a href="vaccine_list.php" class="btn btn-primary">View Vaccine list</a>
                </div>
            </div>
            <div id="pet-container" class="row">
                <?php if ($pets): ?>
                    <?php foreach ($pets as $pet): ?>
                        <div class="col-md-4">
                            <div class="card mb-4">
                                <div class="card-body text-center">
                                    <h5 class="card-title"><?php echo htmlspecialchars($pet['pet_name']); ?></h5>
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($pet['pet_image']); ?>" 
                                        alt="<?php echo htmlspecialchars($pet['pet_name']); ?>" 
                                        class="img-fluid rounded-circle" 
                                        style="width: 150px; height: 150px; object-fit: cover;" />
                                    <p class="mt-2">Owner: <?php echo htmlspecialchars($pet['owner_name']); ?></p>
                                    <a href="pet_details.php?pet_id=<?php echo htmlspecialchars($pet['pet_id']); ?>" class="btn btn-info">View</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="col-12">
                        <p class="text-center">No pets found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
