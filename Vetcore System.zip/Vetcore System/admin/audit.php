<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Pagination setup
$limit = 10; // Number of records per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page
$offset = ($page - 1) * $limit; // Calculate offset

// Fetch total records
$totalSql = "SELECT COUNT(*) as total FROM auditt WHERE userType != 'admin'";
$totalStmt = $conn->prepare($totalSql);
$totalStmt->execute();
$totalRecords = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPages = ceil($totalRecords / $limit); // Total pages

// Fetch audit trail excluding records where userType is 'admin' with pagination
$auditSql = "SELECT * FROM auditt WHERE userType != 'admin' ORDER BY date DESC LIMIT :limit OFFSET :offset";
$auditStmt = $conn->prepare($auditSql);
$auditStmt->bindParam(':limit', $limit, PDO::PARAM_INT);
$auditStmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$auditStmt->execute();
$auditRecords = $auditStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>View Audit Trail</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .sidebar {
            width: 200px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 0;
        }

        .sidebar img {
            max-width: 100px;
            border-radius: 50%;
        }

        .sidebar h4 {
            margin-top: 10px;
            font-size: 1.5rem;
        }

        .nav-link:hover {
            background-color: #007e3a;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
            width: calc(100% - 200px);
        }
        .hding1 {
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 1% 0% 0% 34%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <h1 class="hding1">Audit Trail</h1>
        <a href="view_user.php" class="btn btn-secondary mb-3">Back to User View</a>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Action</th>
                    <th>Date</th>
                    <th>User Type</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($auditRecords as $record): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($record['id']); ?></td>
                        <td><?php echo htmlspecialchars($record['userID']); ?></td>
                        <td><?php echo htmlspecialchars($record['action']); ?></td>
                        <td><?php echo htmlspecialchars($record['date']); ?></td>
                        <td><?php echo htmlspecialchars($record['userType']); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Pagination Controls -->
<nav aria-label="Page navigation" class="text-center">
    <ul class="pagination justify-content-center">
        <li class="page-item <?php if ($page <= 1) echo 'disabled'; ?>">
            <a class="page-link" href="?page=<?php echo $page - 1; ?>">Previous</a>
        </li>

        <?php 
        // Display pagination numbers
        $startPage = max(1, $page - 2); // Start from 2 pages before current
        $endPage = min($totalPages, $startPage + 4); // Show up to 5 pages total

        // Adjust start page if there are fewer than 5 pages
        if ($endPage - $startPage < 4) {
            $startPage = max(1, $endPage - 4); // Ensure at least 5 pages are shown
        }

        // Add ellipsis before start page if needed
        if ($startPage > 1) {
            echo '<li class="page-item"><span class="page-link">...</span></li>';
        }

        // Generate page links
        for ($i = $startPage; $i <= $endPage; $i++): ?>
            <li class="page-item <?php if ($i === $page) echo 'active'; ?>">
                <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>

        <li class="page-item <?php if ($page >= $totalPages) echo 'disabled'; ?>">
            <a class="page-link" href="?page=<?php echo $page + 1; ?>">Next</a>
        </li>
    </ul>
</nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
