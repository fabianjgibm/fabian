<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Fetch products from the database
$productSql = "SELECT * FROM product"; // Adjust this to your actual table name
$productStmt = $conn->prepare($productSql);
$productStmt->execute();
$products = $productStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['addToCart'])) {
    $user_id = $_SESSION['U_id'];
    $product_id = $_POST['product_id'];
    $quantity = $_POST['quantity'];

    // Check the available stock for the selected product
    $stockQuery = "SELECT COALESCE(SUM(CASE 
        WHEN product_detail.expiration_date > CURRENT_DATE 
             OR product_detail.expiration_date IS NULL 
             OR product_detail.expiration_date = '0000-00-00' 
        THEN product_detail.remaining_stock 
        ELSE 0 
    END), 0) AS stock
    FROM product
    LEFT JOIN product_detail ON product.id = product_detail.product_id
    WHERE product.id = :product_id
    GROUP BY product.id";

    $stmt = $conn->prepare($stockQuery);
    $stmt->bindParam(":product_id", $product_id);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $available_stock = $row ? $row['stock'] : 0;

    // Check if the product is already in the cart
    $check_sql = "SELECT * FROM cart WHERE user_id = :user_id AND product_id = :product_id";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->execute([':user_id' => $user_id, ':product_id' => $product_id]);
    $check_result = $check_stmt->fetch(PDO::FETCH_ASSOC);

    // Get current cart quantity
    $current_quantity = $check_result ? $check_result['quantity'] : 0;

    // Calculate the total quantity after addition
    $new_quantity = $current_quantity + $quantity;

    // If the total quantity exceeds the available stock, display an error message and exit
    if ($new_quantity > $available_stock) {
        $notify = "Quantity exceeds available stock. The maximum you can order is $available_stock.";
        echo "<script>
            alert('$notify');
            window.location.href = 'onsite.php';
        </script>";
        exit();
    }

    if ($check_result) {
        // Product already in cart, update the quantity
        $update_sql = "UPDATE cart SET quantity = quantity + :quantity WHERE user_id = :user_id AND product_id = :product_id";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->execute([':quantity' => $quantity, ':user_id' => $user_id, ':product_id' => $product_id]);

        // Save the update action to the audit trail
        //save_audit_trail($user_id, "Updated product (ID: $product_id) quantity in cart", $_SESSION['U_type']);
    } else {
        // Product not in cart, insert new record
        $insert_sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (:user_id, :product_id, :quantity)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->execute([':user_id' => $user_id, ':product_id' => $product_id, ':quantity' => $quantity]);

        // Save the insert action to the audit trail
        //save_audit_trail($user_id, "Added product (ID: $product_id) to cart", $_SESSION['U_type']);
    }

    $conn = null; // Close the connection

    header("Location: onsite.php");
    exit();
}
$cartSql = "SELECT cart.id, cart.product_id, cart.quantity, product.name, product.price 
            FROM cart
            JOIN product ON cart.product_id = product.id
            WHERE cart.user_id = :user_id";
$cartStmt = $conn->prepare($cartSql);
$cartStmt->execute([':user_id' => $_SESSION['U_id']]);
$cartItems = $cartStmt->fetchAll(PDO::FETCH_ASSOC);

$totalAmount = 0;
$totalQuantity = 0;

foreach ($cartItems as $cartItem) {
    $totalAmount += $cartItem['price'] * $cartItem['quantity'];
    $totalQuantity += $cartItem['quantity'];
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_from_cart'])) {
    $cart_id = $_POST['cart_id'];

    // Delete the cart item from the database
    $deleteSql = "DELETE FROM cart WHERE id = :cart_id AND user_id = :user_id";
    $deleteStmt = $conn->prepare($deleteSql);
    $deleteStmt->execute([':cart_id' => $cart_id, ':user_id' => $_SESSION['U_id']]);

    // Redirect back to the cart page to update the cart display
    header("Location: onsite.php");
    exit();
}
$searchTerm = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['search'])) {
    $searchTerm = $_POST['search'];
}

// Fetch products from the database
$productSql = "SELECT * FROM product WHERE name LIKE :searchTerm"; // Adjust this to your actual table name
$productStmt = $conn->prepare($productSql);
$productStmt->execute([':searchTerm' => '%' . $searchTerm . '%']);
$products = $productStmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_order'])) {
    // Delete all items from the cart for the current user
    $deleteAllSql = "DELETE FROM cart WHERE user_id = :user_id";
    $deleteAllStmt = $conn->prepare($deleteAllSql);
    $deleteAllStmt->execute([':user_id' => $_SESSION['U_id']]);

    // Redirect back to the cart page to update the cart display
    header("Location: onsite.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); 
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-attachment: fixed; 
            color: #333;
        }

        .content {
            margin-left: 200px;
            padding-top: 20px;
            padding-bottom: 20px;
        }
        
        .cart {
            width: 365px;
            height: 645px;
            margin-left: 10px;
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            overflow-y: auto;
        }

        .cart h3 {
            text-align: center;
            font-weight: bold;
        }

        .list-group-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            font-size: 14px;
        }

        .badge {
            font-size: 14px;
            background-color: #007bff;
        }

        .t1 {
            display: flex;
        }

        .products {
            width: 750px;
            background-color: white;
            margin-left: 10px;
            border-radius: 10px;
            height: 645px;
            overflow-y: auto;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Include the admin navbar -->
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="t1">
        <div class="cart">
            <h3>Cart</h3>
                <ul id="cart-items" class="list-group">
                    <?php if (count($cartItems) > 0): ?>
                        <?php foreach ($cartItems as $cartItem): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span title="<?= htmlspecialchars($cartItem['name']) ?>">
                                    <?= htmlspecialchars(strlen($cartItem['name']) > 20 ? substr($cartItem['name'], 0, 20) . '...' : $cartItem['name']) ?>
                                </span>
                                (x<?= htmlspecialchars($cartItem['quantity']) ?>)
                                <span class="badge bg-primary rounded-pill">
                                    ₱<?= number_format($cartItem['price'] * $cartItem['quantity'], 2) ?>
                                </span>
                                
                                <!-- Remove Button -->
                                <form method="POST" action="onsite.php" style="margin-left: 10px;">
                                    <input type="hidden" name="cart_id" value="<?= $cartItem['id'] ?>">
                                    <button type="submit" name="remove_from_cart" class="btn btn-danger btn-sm">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </li>
                        <?php endforeach; ?>
                        <li class="list-group-item">
                            <strong>Total Quantity:</strong> <?= $totalQuantity ?>
                        </li>
                        <li class="list-group-item">
                            <strong>Total Amount:</strong> ₱<?= number_format($totalAmount, 2) ?>
                        </li>
                    <?php else: ?>
                        <li class="list-group-item">Your cart is empty</li>
                    <?php endif; ?>
                </ul>
            <?php if (count($cartItems) > 0): ?>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#paymentModal">
                    Process
                </button>
            <?php endif; ?>
            <?php if (count($cartItems) > 0): ?>
                <button type="button" class="btn btn-danger" onclick="confirmCancelOrder()">Cancel</button>
            <?php endif; ?>
            <form id="cancelOrderForm" method="POST" action="onsite.php" style="display: none;">
                <input type="hidden" name="cancel_order" value="1">
            </form>
        </div>

            <div class="products">
                <h3>Product List</h3>
                <form method="POST" action="" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search for a product..." aria-label="Search for a product">
                        <button type="submit" class="btn btn-outline-secondary">Search</button>
                        <a href="manage_order.php" class="tar2 btn btn-success">Cancel</a>
                    </div>
                </form>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Name</th>
                            <th>Price</th>
                            
                            <th>Action</th> <!-- New Action Header -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($products as $product): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($product['image'])): ?>
                                        <img src="data:image/jpeg;base64,<?= base64_encode($product['image']) ?>" 
                                            alt="<?= htmlspecialchars($product['name']) ?>" 
                                            style="width: 50px; height: auto;" />
                                    <?php else: ?>
                                        <p>No Image Available</p>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span title="<?= htmlspecialchars($product['name']) ?>">
                                        <?= htmlspecialchars(strlen($product['name']) > 30 ? substr($product['name'], 0, 30) . '...' : $product['name']) ?>
                                    </span>
                                </td>
                                <td><?= htmlspecialchars($product['price']) ?></td>
                                <td>
                                    <form method="POST" action="">
                                        <input type="hidden" name="product_id" value="<?= htmlspecialchars($product['id']) ?>">
                                        <input type="number" name="quantity" value="1" min="1" style="width: 60px;" required> <!-- Quantity input -->
                                        <button type="submit" name="addToCart" class="btn btn-primary">Select</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="paymentModalLabel">Select Payment Method</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="POST" action="../logics/process_order.php" onsubmit="return validatePayment()">
                    <div class="mb-3">
                        <label for="paymentMethod" class="form-label">Payment Method</label>
                        <select class="form-select" id="paymentMethod" name="PM" required>
                            <option value="" disabled selected>Select payment option</option>
                            <option value="cash">Cash</option>
                            <option value="gcash">GCash</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="totalAmount" class="form-label">Total Amount</label>
                        <input type="text" class="form-control" id="totalAmount" value="₱<?= number_format($totalAmount, 2) ?>" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="amountPaid" class="form-label">Amount Paid</label>
                        <input type="number" class="form-control" id="amountPaid" name="amountPaid" required oninput="calculateChange()">
                    </div>
                    <div class="mb-3">
                        <label for="change" class="form-label">Change</label>
                        <input type="text" class="form-control" id="change" value="₱0.00" readonly>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="submit_order" class="btn btn-primary">Submit Order</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function calculateChange() {
        const totalAmount = parseFloat(document.getElementById('totalAmount').value.replace('₱', '').replace(',', ''));
        const amountPaid = parseFloat(document.getElementById('amountPaid').value) || 0;
        const change = amountPaid - totalAmount;
        document.getElementById('change').value = '₱' + (change >= 0 ? change.toFixed(2) : '0.00');
    }
    function validatePayment() {
    const totalAmount = parseFloat(document.getElementById('totalAmount').value.replace('₱', '').replace(',', ''));
    const amountPaid = parseFloat(document.getElementById('amountPaid').value) || 0;

    if (amountPaid < totalAmount) {
        alert("Insufficient amount paid. Please enter a valid amount.");
        return false; // Prevent form submission
    }
    return true; // Allow form submission
    } 
    function confirmCancelOrder() {
    if (confirm("Are you sure you want to cancel the order and remove all items from the cart?")) {
        document.getElementById('cancelOrderForm').submit();
    }
    }
 
</script>

</body>
</html>
