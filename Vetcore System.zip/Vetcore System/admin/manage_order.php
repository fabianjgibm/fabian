<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Get the selected filter from GET request (default to showing "Pending" orders)
$order_status_filter = isset($_GET['filter']) ? $_GET['filter'] : 'Pending';
$search_query = isset($_GET['search']) ? $_GET['search'] : '';

// Get the selected date for cancelled orders
$cancelled_date = isset($_GET['cancelled_date']) ? $_GET['cancelled_date'] : date('Y-m-d');

// Pagination variables
$limit = 20; // Number of orders to display per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page number
$offset = ($page - 1) * $limit; // Calculate the offset

// Base SQL query
$sql = "SELECT o.order_number, o.order_status, o.payment_status, o.payment_option, u.fname, u.lname
        FROM orders o
        JOIN users u ON o.customer_id = u.id
        WHERE o.order_status = :order_status";

// Add searching logic
if ($search_query) {
    $sql .= " AND (u.fname LIKE :search OR u.lname LIKE :search OR o.order_number LIKE :search)";
}

// Add date filtering for cancelled orders based on order_date_time
if ($order_status_filter == 'Cancelled') {
    $sql .= " AND DATE(o.order_date_time) = :cancelled_date"; // Adjust to use the correct date column
}

$sql .= " GROUP BY o.order_number";  
$sql .= " LIMIT :limit OFFSET :offset"; 

$stmt = $conn->prepare($sql);
$stmt->bindValue(':order_status', $order_status_filter);
if ($search_query) {
    $stmt->bindValue(':search', '%' . $search_query . '%'); // Use LIKE for searching
}
if ($order_status_filter == 'Cancelled') {
    $stmt->bindValue(':cancelled_date', $cancelled_date);
}
$stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get total number of orders for pagination
$total_orders_sql = "SELECT COUNT(DISTINCT o.order_number) AS total_orders 
                     FROM orders o 
                     JOIN users u ON o.customer_id = u.id 
                     WHERE o.order_status = :order_status";

if ($search_query) {
    $total_orders_sql .= " AND (u.fname LIKE :search OR u.lname LIKE :search OR o.order_number LIKE :search)";
}

// Add date filtering for total count if necessary
if ($order_status_filter == 'Cancelled') {
    $total_orders_sql .= " AND DATE(o.order_date_time) = :cancelled_date"; // Adjust to use the correct date column
}

$total_stmt = $conn->prepare($total_orders_sql);
$total_stmt->bindValue(':order_status', $order_status_filter);
if ($search_query) {
    $total_stmt->bindValue(':search', '%' . $search_query . '%'); // Use LIKE for searching
}
if ($order_status_filter == 'Cancelled') {
    $total_stmt->bindValue(':cancelled_date', $cancelled_date);
}
$total_stmt->execute();
$total_orders = $total_stmt->fetch(PDO::FETCH_ASSOC)['total_orders'];
$total_pages = ceil($total_orders / $limit); // Calculate total pages

$show_update_status = false; // Default value

// Check if there are any orders that are not "Collected" or "Cancelled"
foreach ($orders as $order) {
    if ($order['order_status'] != 'Collected' && $order['order_status'] != 'Cancelled') {
        $show_update_status = true; // Set the flag to true if any order is not "Picked"
        break; // No need to check further if we find an updatable order
    }
}
$total_sales_sql = "SELECT SUM(total_amount) AS total_sales 
                    FROM orders 
                    WHERE DATE(order_date_time) = CURDATE() 
                    AND payment_status = 'Paid'";

$total_sales_stmt = $conn->prepare($total_sales_sql);
$total_sales_stmt->execute();
$total_sales = $total_sales_stmt->fetch(PDO::FETCH_ASSOC)['total_sales'] ?? 0;
?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">

    <title>Manage Orders</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .sidebar {
            width: 200px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 0;
        }

        .sidebar img {
            max-width: 100px;
            border-radius: 50%;
        }

        .sidebar h4 {
            margin-top: 10px;
            font-size: 1.5rem;
        }

        .nav-link:hover {
            background-color: #007e3a;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
            width: calc(100% - 200px);
        }
        .btn-secondary.active {
            background-color: #0056b3; /* Darker shade */
            border-color: #0056b3; /* Match border color */
            color: white; /* Change text color */
            font-weight: bold; /* Make text bold */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2); /* Add a subtle shadow */
        }
        .btn-group .btn {
            transition: all 0.3s ease; /* Smooth transition for hover/active state */
        }
        .hding1{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: -4% 0% 5% 34%;
        }
        .hding2{
            width: 200px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: -2% 0% 1% 38%;
        }
        .hding3{
            width: 200px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 0% 0% 1% 0%;
        }
        .in1{
            width: 350px;
        }
        .in2{
            width: 140px;
        }
        .buttn{
            margin: 0% 0% 0% 29.5%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .t1{
            display: flex;
        }
        .t2{
            background-color: white;
            border-radius: 10px;
            height: 40px;
            display: flex; /* Enable flexbox layout */
            align-items: center; /* Vertically center the content */
            justify-content: center; /* Horizontally center the content */
            text-align: center; /* Center text alignment */
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>
                <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
                ?>
            </span>
        </div>
    <?php endif; ?>
        <div class="container mt-5">
            <h1 class="hding1">Orders</h1>

            <!-- Filter Buttons -->
            <div class="mb-4">
                <h4 class="hding2">Select Status</h4>
                <div class="btn-group buttn" role="group" aria-label="Order Status Filters">
                    <a href="manage_order.php?filter=Pending" class="btn btn-secondary <?php echo $order_status_filter == 'Pending' ? 'active' : ''; ?>">Pending</a>
                    <a href="manage_order.php?filter=To Pick Up" class="btn btn-secondary <?php echo $order_status_filter == 'To Pick Up' ? 'active' : ''; ?>">To Pick Up</a>
                    <a href="manage_order.php?filter=Cancelled" class="btn btn-secondary <?php echo $order_status_filter == 'Cancelled' ? 'active' : ''; ?>">Cancelled</a>
                    <a href="completed_order.php" class="btn btn-secondary <?php echo $order_status_filter == 'Collected' ? 'active' : ''; ?>">
                        <i class="fas fa-check-circle"></i> Completed
                    </a>
                </div>
                <h4 class="hding3">Search Orders</h4>
                <div class="t1 d-flex justify-content-between align-items-center">
                    <form action="manage_order.php" method="GET" class="d-flex">
                        <input type="text" name="search" id="search" class="form-control in1 me-2" placeholder="Search by Customer Name or Order Number">
                        <input type="hidden" name="filter" value="<?php echo htmlspecialchars($order_status_filter); ?>">
                        
                        <!-- Date Filter for Cancelled Orders -->
                        <?php if ($order_status_filter == 'Cancelled'): ?>
                            <input type="date" name="cancelled_date" class="form-control me-2 in2" value="<?php echo isset($_GET['cancelled_date']) ? htmlspecialchars($_GET['cancelled_date']) : date('Y-m-d'); ?>" />
                        <?php endif; ?>
                        
                        <button type="submit" class="btn btn-primary">Search</button>
                    </form>
                    <a href="onsite.php" class="tar2 btn btn-success">New Order</a>
                    <h4 class="mb-0 ms-3 t2">Total Sales Today: 
                        <span class="text-success"><?php echo number_format($total_sales, 2); ?> PHP</span>
                    </h4>
                </div>

            <!-- Orders Table -->
            <table class="styled-table" style="background-color: #f8f9fa;">
                <thead>
                    <tr>
                        <th>Order Number</th>
                        <th>Customer Name</th>
                        <th>Order Status</th>
                        <th>Payment Option</th>
                        <th>Payment Status</th>
                        <th>Details</th>
                        <?php if ($show_update_status): ?>
                            <th>Update Status</th>
                        <?php endif; ?>
                        <?php if ($show_update_status): ?>
                            <th>Cancel?</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody id="orderTableBody">
                    <?php if (count($orders) > 0): ?>
                        <?php foreach ($orders as $order): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                <td><?php echo htmlspecialchars($order['fname'] . ' ' . $order['lname']); ?></td>
                                <td><?php echo htmlspecialchars($order['order_status']); ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($order['payment_option'])); ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($order['payment_status'])); ?></td>
                                <td>
                                <a href="order_details.php?order_number=<?php echo urlencode($order['order_number']); ?>&filter=<?php echo urlencode($order_status_filter); ?>" class="btn btn-info">View</a>
                                </td>
                                <?php if ($order['order_status'] != '' && $order['order_status'] != 'Cancelled'): ?>
                                    <td>
                                        <form action="../logics/process_order_status.php" method="POST" onsubmit="return confirmUpdate();">
                                            <input type="hidden" name="order_number" value="<?php echo htmlspecialchars($order['order_number']); ?>">
                                            <?php if ($order['order_status'] == 'Pending'): ?>
                                                <button type="submit" name="update_status" value="To Pick Up" class="btn btn-warning">To Pick Up</button>
                                            <?php elseif ($order['order_status'] == 'To Pick Up'): ?>
                                                <button type="submit" name="update_status" value="Collected" class="btn btn-success">Collected</button>
                                            <?php endif; ?>
                                        </form>
                                    </td>
                                    <td>
                                        <form action="../logics/process_order_cancel.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="order_number" value="<?php echo htmlspecialchars($order['order_number']); ?>">
                                            <input type="hidden" name="status" value="Cancelled">
                                            <button type="submit" name="orderstat" class="btn btn-danger">Cancel</button>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">No orders found for the selected filter.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination -->
            <nav aria-label="Page navigation">
                <ul class="pagination justify-content-center">
                    <?php if ($page > 1): ?>
                        <li class="page-item">
                            <a class="page-link" href="?filter=<?php echo urlencode($order_status_filter); ?>&page=<?php echo $page - 1; ?>">Previous</a>
                        </li>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                            <a class="page-link" href="?filter=<?php echo urlencode($order_status_filter); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <li class="page-item">
                            <a class="page-link" href="?filter=<?php echo urlencode($order_status_filter); ?>&page=<?php echo $page + 1; ?>">Next</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script>
            function confirmUpdate() {
                return confirm("Are you sure you want to update the order status?");
            }
        </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>