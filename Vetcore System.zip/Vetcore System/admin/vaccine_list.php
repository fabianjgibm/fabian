<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php";  
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Handle form submission for adding vaccine
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $vaccine_name = $_POST['vaccine_name'];
    $vc_type = $_POST['vc_type'];

    $sql = "INSERT INTO vaccines (vaccine_name, vc_type) VALUES (:vaccine_name, :vc_type)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':vaccine_name' => $vaccine_name, ':vc_type' => $vc_type]);

    // Redirect to avoid resubmission
    $userID = $_SESSION['U_id'];
    $userType = $_SESSION['U_type'];
    $action = "Pet Vaccination Record Update";
    save_audit_trail($userID, $action, $userType);
    $_SESSION['success'] = "Pet Vaccine Added";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}

// Handle vaccine deletion
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];

    $sql = "DELETE FROM vaccines WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $delete_id]);

    // Redirect to avoid resubmission
    $_SESSION['success'] = "Pet Vaccine Deleted";
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>Vaccines</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 250px;
            margin-right: 50px;
            padding-top: 10px;
            padding-bottom: 20px;
        }
        .content form {
            padding: 20px;
            background-color: white;
            width: 400px;
            border-radius: 10px;
            margin-left: 30%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }
        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }
        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .hding1 {
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 2% 0% 2% 34%;
        }
        .tar2{
            margin-top: 0px;
            margin-left: 46%;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
    <a href="pet_details.php" class="tar2 btn btn-primary">Back</a>
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
                <span>
                    <?php 
                    echo $_SESSION['success']; 
                    unset($_SESSION['success']); // Clear the message after displaying
                    ?>
                </span>
            </div>
        <?php endif; ?>
        <h2 class="hding1">Add Vaccine</h2>
        <form action="" method="post">
            <div class="mb-3">
                <label for="vaccine_name" class="form-label">Vaccine Name</label>
                <input type="text" class="form-control" id="vaccine_name" name="vaccine_name" required>
            </div>
            <div class="mb-3">
                <label for="vc_type" class="form-label">Pet Type</label>
                <select class="form-select" id="vc_type" name="vc_type" required>
                    <option value="" disabled selected>Select</option>
                    <option value="dog">Dog</option>
                    <option value="cat">Cat</option>
                </select>
            </div>
            <input type="hidden" name="action" value="add">
            <button type="submit" class="btn btn-primary">Add Vaccine</button>
        </form>

        <h2 class="hding1">Vaccines List</h2>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Vaccine Name</th>
                    <th>Pet Type</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch and display all vaccines
                $sql = "SELECT * FROM vaccines";
                $stmt = $conn->prepare($sql);
                $stmt->execute();
                $vaccines = $stmt->fetchAll(PDO::FETCH_ASSOC);

                foreach ($vaccines as $vaccine) {
                    echo "<tr>
                            <td>{$vaccine['vaccine_name']}</td>
                            <td>{$vaccine['vc_type']}</td>
                            <td>
                                <a href='?delete_id={$vaccine['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this vaccine?\")'>Delete</a>
                            </td>
                        </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
