<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php";    
session_start();

// Sanitize and retrieve form data
$email = htmlspecialchars($_POST['email']);
$firstname = htmlspecialchars($_POST['fname']);
$lastname = htmlspecialchars($_POST['lname']);
$Mnumber = htmlspecialchars($_POST['phone_number']);
$password = htmlspecialchars($_POST['password']); // Sanitize password too

// Hash the password
$hashpass = password_hash($password, PASSWORD_DEFAULT);

try {
    // Step 1: Check if email or phone number already exists
    $sqlCheck = "
        SELECT COUNT(*) 
        FROM users 
        WHERE email = :email OR phone_number = :phone_number
    ";
    $stmtCheck = $conn->prepare($sqlCheck);
    $stmtCheck->execute([
        ':email' => $email,
        ':phone_number' => $Mnumber,
    ]);

    $count = $stmtCheck->fetchColumn();

    // Check if email or phone number exists
    if ($count > 0) {
        $_SESSION['success'] = "Email or Mobile Number is Already Registered";
        header("Location: add_user.php"); // Redirect back to the add user page
        exit();
    }

    // Step 2: Retrieve existing full names
    $sqlFullNameCheck = "
        SELECT CONCAT(fname, ' ', lname) AS full_name 
        FROM users
    ";
    $stmtFullNameCheck = $conn->prepare($sqlFullNameCheck);
    $stmtFullNameCheck->execute();

    // Fetch all existing full names into an array
    $existingFullNames = $stmtFullNameCheck->fetchAll(PDO::FETCH_COLUMN);

    // Create the new full name variable
    $newFullName = trim($firstname . ' ' . $lastname);

    // Step 3: Check if the new full name matches any existing full name
    if (in_array($newFullName, $existingFullNames)) {
        // Full name already exists
        $_SESSION['success'] = "First or Last Name is Already Registered";
        header("Location: add_user.php"); // Redirect back to the add user page
        exit();
    }

    // Step 4: SQL query for inserting the new user
    $sql = "INSERT INTO users (user_type, password, email, fname, lname, phone_number) 
            VALUES (:user_type, :password, :email, :fname, :lname, :phone_number)";
    $stmt = $conn->prepare($sql);
    $stmt->execute([
        ':user_type' => $_POST['user_type'], // Get user type from form
        ':password' => $hashpass,
        ':email' => $email,
        ':fname' => $firstname,
        ':lname' => $lastname,
        ':phone_number' => $Mnumber,
    ]);

    // Save audit trail for new user registration
    $userID = $_SESSION['U_id']; // ID of the admin or user who is adding the new user
    $userType = $_SESSION['U_type']; // Type of the admin or user
    $action = "New user registered: $firstname $lastname, Email: $email";
    save_audit_trail($userID, $action, $userType);

    // Set success message
    $_SESSION['success'] = "Account created successfully!";
    header("Location: view_user.php"); // Redirect back to the view user page
    exit();
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Close the database connection
$conn = null;
?>