<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php";  
session_start();

if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Check if an expired item has been removed
if (isset($_POST['remove'])) {
    $product_id = $_POST['product_id'];

    // Update the storage column to mark the item as removed
    $updateSql = "UPDATE product_detail SET storage = 'Removed' WHERE id = :product_id";
    $updateStmt = $conn->prepare($updateSql);
    $updateStmt->bindParam(':product_id', $product_id, PDO::PARAM_INT);
    $updateStmt->execute();

    $userID = $_SESSION['U_id'];
    $userType = $_SESSION['U_type'];
    $action = "Removed expired product from inventory";
    save_audit_trail($userID, $action, $userType);
    // Success message
    $_SESSION['message'] = "Item has been removed from storage.";
    header("Location: expired_items.php");
    exit();
}

// Pagination setup
$itemsPerPage = 20;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $itemsPerPage;

// Fetch expired products that are still in storage
$sqlExpired = "
    SELECT pd.id, pd.product_code, pd.remaining_stock, pd.expiration_date, p.name, pd.storage
    FROM product_detail pd
    JOIN product p ON pd.product_id = p.id
    WHERE pd.expiration_date < NOW()
    AND pd.expiration_date != '0000-00-00'
    AND pd.storage != 'Removed'
    LIMIT :offset, :itemsPerPage";

$expiredStmt = $conn->prepare($sqlExpired);
$expiredStmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$expiredStmt->bindParam(':itemsPerPage', $itemsPerPage, PDO::PARAM_INT);
$expiredStmt->execute();
$expiredProducts = $expiredStmt->fetchAll(PDO::FETCH_ASSOC);

// Count total expired products for pagination
$sqlCountExpired = "
    SELECT COUNT(*) AS total
    FROM product_detail pd
    WHERE pd.expiration_date < NOW()
    AND pd.expiration_date != '0000-00-00'
    AND pd.storage != 'Removed'";
$countStmt = $conn->query($sqlCountExpired);
$totalExpired = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPagesExpired = ceil($totalExpired / $itemsPerPage);

// Fetch expired products that have been removed from storage
$sqlRemoved = "
    SELECT pd.product_code, pd.remaining_stock, pd.expiration_date, p.name
    FROM product_detail pd
    JOIN product p ON pd.product_id = p.id
    WHERE pd.storage = 'Removed'
    LIMIT :offset, :itemsPerPage";

$removedStmt = $conn->prepare($sqlRemoved);
$removedStmt->bindParam(':offset', $offset, PDO::PARAM_INT);
$removedStmt->bindParam(':itemsPerPage', $itemsPerPage, PDO::PARAM_INT);
$removedStmt->execute();
$removedProducts = $removedStmt->fetchAll(PDO::FETCH_ASSOC);

// Count total removed products for pagination
$sqlCountRemoved = "
    SELECT COUNT(*) AS total
    FROM product_detail pd
    WHERE pd.storage = 'Removed'";
$countRemovedStmt = $conn->query($sqlCountRemoved);
$totalRemoved = $countRemovedStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPagesRemoved = ceil($totalRemoved / $itemsPerPage);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>Expired Items</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
         body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 300px; /* Matches the width of the sidebar */
            width: 70%;
        }
        .alert {
            margin-top: 20px;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
            vertical-align: middle;
            text-align: center;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .hding1{
            width: 500px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: 0% 0% 0% 21%;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <a href="product_list.php" class="btn btn-secondary mt-4">Back</a>
        <div class="container mt-4">
            <h2 class="hding1">Expired Products in Storage</h2>

            <?php if (isset($_SESSION['message'])): ?>
                <div class="alert alert-warning">
                    <?php
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    ?>
                </div>
            <?php elseif (!empty($expiredProducts)): ?>
                <div class="alert alert-danger">
                    You need to remove the expired items from the inventory.
                </div>
            <?php endif; ?>

            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Code</th>
                        <th>Remaining Stock</th>
                        <th>Expiration Date</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($expiredProducts) {
                        foreach ($expiredProducts as $product) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($product['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($product['product_code']) . "</td>";
                            echo "<td>" . htmlspecialchars($product['remaining_stock']) . "</td>";
                            echo "<td>" . htmlspecialchars($product['expiration_date']) . "</td>";
                            echo '<td>
                                    <form method="POST" action="">
                                        <input type="hidden" name="product_id" value="' . $product['id'] . '">
                                        <button type="submit" name="remove" class="btn btn-danger btn-sm">Remove from Storage</button>
                                    </form>
                                </td>';
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No expired products from the inventory</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <!-- Pagination links for expired products -->
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $totalPagesExpired; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>

            <h2 class="hding1">Removed Expired Products</h2>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Product Name</th>
                        <th>Product Code</th>
                        <th>Remaining Stock</th>
                        <th>Expiration Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($removedProducts) {
                        foreach ($removedProducts as $removed) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($removed['name']) . "</td>";
                            echo "<td>" . htmlspecialchars($removed['product_code']) . "</td>";
                            echo "<td>" . htmlspecialchars($removed['remaining_stock']) . "</td>";
                            echo "<td>" . htmlspecialchars($removed['expiration_date']) . "</td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No expired products have been removed</td></tr>";
                    }
                    ?>
                </tbody>
            </table>

            <!-- Pagination links for removed products -->
            <nav aria-label="Page navigation">
                <ul class="pagination">
                    <?php for ($i = 1; $i <= $totalPagesRemoved; $i++): ?>
                        <li class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
