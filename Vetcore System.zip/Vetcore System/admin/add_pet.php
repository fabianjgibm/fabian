<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php"; 
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $owner_id = $_POST['owner_id'];
    $pet_name = $_POST['pet_name'];
    $pet_type = $_POST['pet_type'];
    $breed = $_POST['breed'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $birthday = $_POST['birthday'];
    $registration_date = date('Y-m-d'); // Current date

    // Check if the owner exists
    $stmt = $conn->prepare("SELECT id FROM users WHERE id = :owner_id AND user_type = 'customer'");
    $stmt->execute([':owner_id' => $owner_id]);
    $ownerExists = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$ownerExists) {
        echo "<div class='alert alert-danger tar1'>This owner does not exist. Please select a valid owner.</div>";
    } else {
        // Read the image file contents
        $pet_image = file_get_contents($_FILES['pet_image']['tmp_name']);

        // Generate a unique image name
        $stmt = $conn->prepare("SELECT MAX(pet_id) as max_id FROM pet_details");
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $new_id = ($row['max_id'] !== null ? $row['max_id'] : 0) + 1; // Increment the max id by 1
        $image_name = 'Pet_' . $new_id; // Generate the new image name

        // Insert pet details into the database
        $sql = "INSERT INTO pet_details (owner_id, pet_name, pet_type, breed, age, gender, birthday, registration_date, pet_image, image_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $conn->prepare($sql);
        
        if ($stmt->execute([$owner_id, $pet_name, $pet_type, $breed, $age, $gender, $birthday, $registration_date, $pet_image, $image_name])) {
            // Save audit trail for adding a new pet
            $userID = $_SESSION['U_id']; // Get the user ID from the session
            $userType = $_SESSION['U_type']; // Get the user type from the session
            $action = "Registered a new pet: $pet_name (Owner ID: $owner_id)";
            save_audit_trail($userID, $action, $userType);

            $_SESSION['success'] = "Pet added successfully!";
            header("Location: view_pet.php"); // Redirect back to the view pet page
            exit();
        } else {
            echo "<div class='alert alert-danger'>Error: " . $stmt->errorInfo()[2] . "</div>"; // Use errorInfo for detailed error
        }
    }

    $stmt = null; // Optional: set to null to free up resources
}

// No need to explicitly close the connection; PHP will handle it when the script ends
$conn = null; // Optional: set to null to explicitly close the connection
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <title>Add Pet</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
        }
        .search-result-item {
            cursor: pointer;
            padding: 10px;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .search-result-item:hover {
            background-color: #e2e2e2;
        }
        #search_results {
            max-height: 200px;
            overflow-y: auto;
        }
        .form-card {
            max-width: 600px;
            margin: 50px auto;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        /* Header Styling */
        .form-card-header {
            background-color: #00a651;
            color: white;
            padding: 20px;
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            text-align: center;
        }

        /* Adjust content position */
        .content {
            margin-left: 475px; /* Adjust according to the navbar width */
            padding: 20px;
        }
        .tar1{
            width: 412px;
            margin-top: 20px;
            margin-left: 565px;
            margin-bottom: -50px;
        }
        .tar2{
            margin-left: 44%;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php include 'admin_navbar.php'; ?>
<div class="d-flex">
    <div class="content">
        <div class="form-card">
            <div class="form-card-header">
                <h2>Add Pet</h2>
            </div>
            <div class="card-body p-4">
                <form method="POST" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="owner_name" class="form-label">Owner Name</label>
                            <input type="text" class="form-control" id="search_pet" name="owner_name" placeholder="Search Owner" required>                            <div id="search_results" class="position-absolute bg-white border" style="z-index: 1000; max-height: 200px; overflow-y: auto;"></div>
                            <input type="hidden" id="owner_id" name="owner_id">
                        </div>
                        <div class="col-md-6">
                            <label for="pet_name" class="form-label">Pet Name</label>
                            <input type="text" class="form-control" id="pet_name" name="pet_name" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pet_type" class="form-label">Pet Type</label>
                            <input type="text" class="form-control" id="pet_type" name="pet_type" required>
                        </div>
                        <div class="col-md-6">
                            <label for="breed" class="form-label">Breed</label>
                            <input type="text" class="form-control" id="breed" name="breed" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="age" class="form-label">Age</label>
                            <input type="number" class="form-control" id="age" name="age" required>
                        </div>
                        <div class="col-md-6">
                            <label for="gender" class="form-label">Gender</label>
                            <select class="form-select" id="gender" name="gender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="birthday" class="form-label">Birthday</label>
                            <input type="date" class="form-control" id="birthday" name="birthday" required>
                        </div>
                        <div class="col-md-6">
                            <label for="pet_image" class="form-label">Pet Image</label>
                            <input type="file" class="form-control" id="pet_image" name="pet_image" accept="image/*" required>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center mt-4">
                        <button type="submit" class="btn btn-primary">Add Pet</button>
                    </div>
                    <a href="pet_details.php" class="tar2 btn btn-success">Back</a>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
$(document).ready(function() {
    $('#search_pet').on('input', function() {
        var query = $(this).val();

        // Allow searching for existing owners
        if (query.length > 0) {
            $.ajax({
                url: '../logics/search_user.php', // Path to your PHP search script
                method: 'POST',
                data: {query: query},
                success: function(data) {
                    $('#search_results').html(data);
                }
            });
        } else {
            $('#search_results').html(''); // Clear results if the query is empty
        }
    });

    // Set the owner name when a search result is clicked
    $(document).on('click', '.search-result-item', function() {
        var ownerId = $(this).data('owner-id');
        var ownerName = $(this).data('owner-name');

        // Set the owner ID in the hidden input
        $('#owner_id').val(ownerId); 

        // Display selected owner in the search field
        $('#search_pet').val(ownerName);

        // Clear search results
        $('#search_results').html('');

        // Optionally, make the search field readonly to prevent further editing
        $('#search_pet').prop('readonly', true);
    });

    // Optional: If you want to allow users to clear the selection
    $('#search_pet').on('focus', function() {
        // If the input is readonly, allow clearing it
        if ($(this).prop('readonly')) {
            $(this).prop('readonly', false).val('');
            $('#owner_id').val(''); // Clear the owner ID as well
            $('#search_results').html(''); // Clear any displayed results
        }
    });
});

</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
