<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php"; // Include your SQL connection file
session_start();

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Initialize variables
$itemName = '';
$itemPrice = '';
$category = '';
$imageName = '';
$stockLimit = ''; // Add stock limit variable
$expiration = ''; // Add expiration variable

if (isset($_POST['add_item'])) { 
    $itemName = isset($_POST['Iname']) ? $_POST['Iname'] : '';
    $itemPrice = isset($_POST['Iprice']) ? $_POST['Iprice'] : '';
    $stockLimit = isset($_POST['stock_limit']) ? $_POST['stock_limit'] : ''; // Get stock limit
    $expiration = isset($_POST['expiration']) ? $_POST['expiration'] : ''; // Get expiration status
    $category = !empty($_POST['ctgry']) ? $_POST['ctgry'] : (isset($_POST['new_category']) ? $_POST['new_category'] : '');

    if (isset($_FILES['fileToUpload']) && $_FILES['fileToUpload']['error'] == UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['fileToUpload']['tmp_name'];
        $fileContent = file_get_contents($fileTmpPath);
        
        $imageName = generateImageName($conn); // Generate a unique image name
        
        // Insert the item into the product table
        $sql = "INSERT INTO product (category, name, price, image, image_name, stock_limit, expiration) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$category, $itemName, $itemPrice, $fileContent, $imageName, $stockLimit, $expiration]);

        // Save audit trail for adding the product
        $userID = $_SESSION['U_id'];
        $userType = $_SESSION['U_type'];
        $action = "Added new product: $itemName";
        save_audit_trail($userID, $action, $userType);

        $_SESSION['success'] = "New Product Added!!";
        header("Location: manage_products.php");
        exit();
    } else {
        $errorCode = $_FILES['fileToUpload']['error'] ?? null;
        if ($errorCode) {
            switch ($errorCode) {
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    echo "<script>alert('File size exceeds the maximum limit.');</script>";
                    break;
                case UPLOAD_ERR_NO_FILE:
                    echo "<script>alert('No file was uploaded. Please select a file.');</script>";
                    break;
                default:
                    echo "<script>alert('File upload error.');</script>";
                    break;
            }
        }
    }
}

// Function to generate the next product image name
function generateImageName($conn) {
    // Get the highest existing image name number
    $sql = "SELECT image_name FROM product WHERE image_name LIKE 'prodimg%'";
    $stmt = $conn->query($sql);
    $existingNames = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    $maxNumber = 0;
    foreach ($existingNames as $name) {
        preg_match('/(\d+)$/', $name, $matches);
        if (!empty($matches) && isset($matches[1])) {
            $number = (int)$matches[1];
            if ($number > $maxNumber) {
                $maxNumber = $number;
            }
        }
    }

    return 'prodimg' . ($maxNumber + 1); // Generate the next image name
}

// Fetch existing categories
$sqlCategories = "SELECT DISTINCT category FROM product";
$categoryStmt = $conn->query($sqlCategories);
$categories = $categoryStmt->fetchAll(PDO::FETCH_COLUMN);

// Close connection at the end
$conn = null;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Item</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .content {
            margin-left: 300px; /* Matches the width of the sidebar */
            width: 70%;
        }
        .content1 {
            margin-bottom: 2%;
        } 
        .vm{
            margin-bottom: 10px;
        }   
    </style>
</head>
<body>
<?php include 'admin_navbar.php'; ?>
<div class="content">
<div class="container content1 mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-lg">
                <div class="card-header bg-success text-white">
                    <h3 class="text-center">Add Item</h3>
                </div>
                <div class="card-body">
                    <form method="POST" action="add_item.php" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="category_select" class="form-label">Select Category:</label>
                            <select name="ctgry" id="category_select" class="form-select" onchange="toggleCategoryInput()">
                                <option value="" selected>-- Select a Category --</option>
                                <?php foreach ($categories as $existingCategory): ?>
                                    <option value="<?php echo htmlspecialchars($existingCategory); ?>"><?php echo htmlspecialchars($existingCategory); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="new_category" class="form-label">Enter New Category:</label>
                            <input type="text" name="new_category" id="new_category" class="form-control" onkeyup="searchCategory()" placeholder="Enter new category">
                        </div>
                        <div class="mb-3">
                            <label for="Iname" class="form-label">Name:</label>
                            <input type="text" name="Iname" id="Iname" class="form-control" value="<?php echo htmlspecialchars($itemName); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="Iprice" class="form-label">Price:</label>
                            <input type="number" name="Iprice" id="Iprice" class="form-control" value="<?php echo htmlspecialchars($itemPrice); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="stock_limit" class="form-label">Stock Limit:</label>
                            <input type="number" name="stock_limit" id="stock_limit" class="form-control" value="<?php echo htmlspecialchars($stockLimit); ?>" required> <!-- New input for stock limit -->
                        </div>
                        <div class="mb-3">
                            <label for="fileToUpload" class="form-label">Image:</label>
                            <input type="file" name="fileToUpload" id="fileToUpload" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label for="expiration" class="form-label">Has Expiration:</label>
                            <select name="expiration" id="expiration" class="form-select" required>
                                <option value="" selected>-- Select --</option>
                                <option value="Yes">Yes</option>
                                <option value="No">No</option>
                            </select>
                        </div>
                        <div class="text-center">
                            <input type="submit" name="add_item" class="btn btn-primary" value="Add Item">
                        </div>
                    </form>
                </div>
                <div class="text-center mt-1 vm">
                <a href="manage_products.php" class="btn btn-secondary">Cancel</a>
            </div>
            </div>
        </div>
    </div>
</div>
    </div>
<script>
    function toggleCategoryInput() {
        const categorySelect = document.getElementById('category_select');
        const newCategoryInput = document.getElementById('new_category');

        // Check if the selected value is the first option
        if (categorySelect.value === "") {
            newCategoryInput.disabled = false; // Enable new category input if no category is selected
        } else {
            newCategoryInput.disabled = true; // Disable new category input if a category is selected
            newCategoryInput.value = ""; // Clear the new category input
        }
    }
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
