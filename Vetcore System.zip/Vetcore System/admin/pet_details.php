<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Get pet details
if (isset($_GET['pet_id'])) {
    $pet_id = $_GET['pet_id'];
    $sql = "SELECT pd.*, CONCAT(u.fname, ' ', u.lname) AS owner_name FROM pet_details pd JOIN users u ON pd.owner_id = u.id WHERE pd.pet_id = :pet_id";
    $stmt = $conn->prepare($sql);
    $stmt->execute([':pet_id' => $pet_id]);
    $pet = $stmt->fetch(PDO::FETCH_ASSOC);
} else {
    header("Location: view_pet.php");
    exit();
}
// Get vaccination details
$sql = "SELECT vd.vaccination_date, vd.veterinarian, 
        GROUP_CONCAT(vg.vaccine_name SEPARATOR ', ') AS vaccine_names
        FROM vaccination_details vd 
        LEFT JOIN vaccines_given vg ON vd.vaccination_id = vg.vaccination_id 
        WHERE vd.pet_id = :pet_id
        GROUP BY vd.vaccination_date, vd.veterinarian
        ORDER BY vd.vaccination_date DESC";
$stmt = $conn->prepare($sql);
$stmt->execute([':pet_id' => $pet_id]);
$vaccinations = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql_next = "SELECT schedule 
             FROM pet_details
             WHERE pet_id = :pet_id 
             ORDER BY schedule ASC 
             LIMIT 1";
$stmt_next = $conn->prepare($sql_next);
$stmt_next->execute([':pet_id' => $pet_id]);
$next_vaccination = $stmt_next->fetch(PDO::FETCH_ASSOC);

// Format the upcoming date (if available)
$upcoming_vaccination_date = $next_vaccination ? date('F j, Y', strtotime($next_vaccination['schedule'])) : "No upcoming vaccination";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .pet-detail-container {
            margin-top: -60px;
            background-color: #fff; /* White background for the details container */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            width: 50%;
            margin-left: 450px;
        }
        .pet-name {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 20px;
            color: #00a651; /* Green color for the pet name */
        }
        .pet-image {
            display: block;
            margin: 0 auto;
            width: 200px;
            height: auto;
            border-radius: 10px;
            border: 2px solid #00a651; /* Green border around the image */
        }
        .pet-info {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
            padding: 10px;
            background-color: #f0f0f0; /* Light gray background for info sections */
            border-radius: 8px;
        }
        .text-center1 {
            margin-left: 78%;
            margin-top: 4%; /* Center the content */
        }

        .back-button {
            margin: 10px auto; /* Add margin for spacing */
        }
        .table-bordered {
            border: 2px solid black;
        }

        .table th, .table td {
            border: 2px solid black;
        }

        .table thead th {
            background-color: #00a651;
            color: white;
        }

        .text-center h3 {
            margin-top: 30px;
            font-weight: bold;
        }
    </style>
</head>
<body>
<?php include 'admin_navbar.php'; ?>
        <div class="text-center1">
            <a href="view_pet.php" class="btn btn-success back-button">Back</a>
        </div>
    <div class="container pet-detail-container">
        <img src="data:image/jpeg;base64,<?php echo base64_encode($pet['pet_image']); ?>" class="pet-image" alt="<?php echo htmlspecialchars($pet['pet_name']); ?>">
        <h2 class="pet-name"><?php echo htmlspecialchars($pet['pet_name']); ?></h2>
        <div class="pet-info">
            <div><strong>Pet Type:</strong> <?php echo htmlspecialchars($pet['pet_type']); ?></div>
            <div><strong>Breed:</strong> <?php echo htmlspecialchars($pet['breed']); ?></div>
        </div>
        <div class="pet-info">
            <div><strong>Age:</strong> <?php echo htmlspecialchars($pet['age']); ?></div>
            <div><strong>Gender:</strong> <?php echo htmlspecialchars($pet['gender']); ?></div>
        </div>
        <div class="pet-info">
            <div><strong>Owner's Name:</strong> <?php echo htmlspecialchars($pet['owner_name']); ?></div>
            <div><strong>Birthday:</strong> <?php echo htmlspecialchars($pet['birthday']); ?></div>
        </div>
        <div class="text-center">
            <a href="vaccination.php?pet_id=<?php echo $pet['pet_id']; ?>" class="btn btn-success back-button">Add vaccination</a>
        </div>
        
        <!-- Vaccination Details Section -->
        <h3 class="text-center">Upcoming Vaccination</h3>
        <?php if ($upcoming_vaccination_date) { ?>
            <p class="text-center" style="font-size: 1.5rem; font-weight: bold;">
                <?php echo htmlspecialchars($upcoming_vaccination_date); ?>
            </p>
        <?php } ?>
        <div class="table-responsive">
            <table class="table table-bordered text-center">
                <thead class="bg-success text-white">
                    <tr>
                        <th>Date of Vaccination</th>
                        <th>Vaccine Given</th>
                        <th>Name of the Veterinarian</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vaccinations as $vaccination) { ?>
                    <tr>
                        <td><?php echo htmlspecialchars($vaccination['vaccination_date']); ?></td>
                        <td><?php echo htmlspecialchars($vaccination['vaccine_names']); ?></td>
                        <td><?php echo htmlspecialchars($vaccination['veterinarian']); ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>