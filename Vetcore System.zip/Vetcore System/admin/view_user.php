<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Pagination variables
$limit = 25; // Limit per page
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1; // Current page
$offset = ($page - 1) * $limit; // Offset for SQL query

// Filter variables
$user_type_filter = isset($_GET['user_type']) ? $_GET['user_type'] : '';

// Build SQL query with filters
$sql_users = "SELECT * FROM users WHERE user_type != 'admin'";

// Apply user type filter
if ($user_type_filter) {
    $sql_users .= " AND user_type = :user_type";
}

$sql_users .= " LIMIT :limit OFFSET :offset";
$stmt_users = $conn->prepare($sql_users);

// Bind values
if ($user_type_filter) {
    $stmt_users->bindValue(':user_type', $user_type_filter);
}
$stmt_users->bindValue(':limit', $limit, PDO::PARAM_INT);
$stmt_users->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt_users->execute();
$users = $stmt_users->fetchAll(PDO::FETCH_ASSOC);

// Get total number of users for pagination
$total_users_query = "SELECT COUNT(*) FROM users WHERE user_type != 'admin'";
if ($user_type_filter) {
    $total_users_query .= " AND user_type = :user_type";
}

$stmt_total = $conn->prepare($total_users_query);
if ($user_type_filter) {
    $stmt_total->bindValue(':user_type', $user_type_filter);
}
$stmt_total->execute();
$total_users = $stmt_total->fetchColumn();
$total_pages = ceil($total_users / $limit); // Total pages
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>View Users</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; /* Keep it cover for a full background */
            background-position: center; /* Center the image */
            background-repeat: no-repeat; /* Prevent the image from repeating */
            background-attachment: fixed; /* Keep the background fixed */
            color: #333;
        }
        .sidebar {
            width: 200px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 0;
        }

        .sidebar img {
            max-width: 100px;
            border-radius: 50%;
        }

        .sidebar h4 {
            margin-top: 10px;
            font-size: 1.5rem;
        }

        .nav-link:hover {
            background-color: #007e3a;
        }

        .content {
            margin-left: 200px;
            padding: 20px;
            width: calc(100% - 200px);
        }
        .hding1{
            width: 300px;
            background-color: #00a651;
            color: white;
            border-radius: 10px;
            text-align: center;
            margin: -2% 0% 5% 34%;
        }
        .styled-table {
            border-collapse: collapse;
            margin: 25px 0;
            font-size: 0.9em;
            font-family: sans-serif;
            width: 100%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
            background-color: #f8f9fa;
        }
        .styled-table thead tr {
            background-color: #009879;
            color: #ffffff;
            text-align: left;
        }
        .styled-table th,
        .styled-table td {
            padding: 12px 15px;
        }
        .styled-table tbody tr {
            border-bottom: 1px solid #dddddd;
        }

        .styled-table tbody tr:nth-of-type(even) {
            background-color: #f3f3f3;
        }

        .styled-table tbody tr:last-of-type {
            border-bottom: 2px solid #009879;
        }
        .styled-table tbody tr.active-row {
            font-weight: bold;
            color: #009879;
        }
        .t1{
            margin-left: -500px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
    <?php if (isset($_SESSION['success'])): ?>
        <div class="alert alert-success mb-0 d-flex align-items-center justify-content-center" role="alert" style="width: auto; height: 60px;">
            <span>
                <?php 
                echo $_SESSION['success']; 
                unset($_SESSION['success']); // Clear the message after displaying
                ?>
            </span>
        </div>
    <?php endif; ?>
        <div class="container mt-4">
            <h2 class="hding1">Users List</h2>
            <!-- Filter Form -->
            <form method="GET" class="mb-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="col-md-3">
                        <select name="user_type" class="form-select" aria-label="User Type Filter">
                            <option value="">View All</option>
                            <option value="veterinarian" <?php echo ($user_type_filter === 'veterinarian') ? 'selected' : ''; ?>>Veterinarian</option>
                            <option value="staff" <?php echo ($user_type_filter === 'staff') ? 'selected' : ''; ?>>Staff</option>
                            <option value="customer" <?php echo ($user_type_filter === 'customer') ? 'selected' : ''; ?>>Customer</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary t1">Filter</button>
                    <div>
                        <a href="add_user.php" class="btn btn-success">Add User</a>
                        <a href="audit.php" class="btn btn-success">View Audit trail</a>
                    </div>
                </div>
            </form>

            <table class="styled-table">
                <thead>
                    <tr>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>User Type</th>
                        <th>Phone Number</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($users): ?>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['fname']); ?></td>
                                <td><?php echo htmlspecialchars($user['lname']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['user_type']); ?></td>
                                <td><?php echo htmlspecialchars($user['phone_number']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center">No users found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Pagination Links -->
            <nav>
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <li class="page-item <?php echo ($i === $page) ? 'active' : ''; ?>">
                            <a class="page-link" href="?page=<?php echo $i; ?>&user_type=<?php echo htmlspecialchars($user_type_filter); ?>"><?php echo $i; ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
