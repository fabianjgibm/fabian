<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

$today = date('Y-m-d');

// Fetch today's vaccinations
$sql_today = "SELECT pd.pet_id, pd.pet_name, pd.pet_image, pd.schedule, CONCAT(u.fname, ' ', u.lname) AS owner_name 
              FROM pet_details pd
              JOIN users u ON pd.owner_id = u.id
              WHERE pd.schedule = :today";
$stmt_today = $conn->prepare($sql_today);
$stmt_today->execute([':today' => $today]);
$todays_vaccinations = $stmt_today->fetchAll(PDO::FETCH_ASSOC);

// Fetch upcoming vaccinations for the week
$week_later = date('Y-m-d', strtotime('+7 days'));
$sql_week = "SELECT pd.pet_id, pd.pet_name, pd.pet_image, pd.schedule, CONCAT(u.fname, ' ', u.lname) AS owner_name 
             FROM pet_details pd
             JOIN users u ON pd.owner_id = u.id
             WHERE pd.schedule BETWEEN :today AND :week_later";
$stmt_week = $conn->prepare($sql_week);
$stmt_week->execute([':today' => $today, ':week_later' => $week_later]);
$upcoming_vaccinations = $stmt_week->fetchAll(PDO::FETCH_ASSOC);

// Fetch missed vaccinations
$sql_missed = "SELECT pd.pet_id, pd.pet_name, pd.pet_image, pd.schedule, CONCAT(u.fname, ' ', u.lname) AS owner_name 
               FROM pet_details pd
               JOIN users u ON pd.owner_id = u.id
               WHERE pd.schedule < :today AND pd.schedule IS NOT NULL";
$stmt_missed = $conn->prepare($sql_missed);
$stmt_missed->execute([':today' => $today]);
$missed_vaccinations = $stmt_missed->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vaccination Schedules</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover; 
            background-position: center; 
            background-repeat: no-repeat; 
        }
        .content {
            margin-left: 200px;
            width: calc(100% - 200px);
        }
        .t1 {
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 0px;
            height: 47px;
        }
        .vaccination-section h3 {
            font-size: 1.5em;
            font-weight: bold;
            text-align: center;
            background-color: white;
            border-radius: 8px;
            height: 47px;
            line-height: 47px;
            color: #fff;
        }
        .vaccination-section img {
            width: 100px;
            height: 100px;
            margin-bottom: 10px;
        }
        .list-group-item {
            background-color: white;
            border: none;
        }
        .text-success { color: #28a745; }
        .text-warning { color: #ffc107; }
        .text-danger { color: #dc3545; }
        .tar2{
            margin-top: -50px;
            margin-left: 46%;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="container mt-5">
        <a href="pet_details.php" class="tar2 btn btn-success">Back</a>
            <h1 class="t1">Vaccination Schedule</h1>
            <div class="row text-center">
                <!-- Upcoming Vaccinations Section -->
                <div class="col-md-4 vaccination-section">
                    <h3 class="text-success">Upcoming</h3>
                    <div class="list-group">
                        <?php if ($upcoming_vaccinations): ?>
                            <?php foreach ($upcoming_vaccinations as $vaccination): ?>
                                <div class="list-group-item">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle">
                                    <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                    <p>Owner: <?php echo htmlspecialchars($vaccination['owner_name']); ?></p>
                                    <p>Scheduled for <?php echo (new DateTime($vaccination['schedule']))->format('F j, Y'); ?>.</p>
                                    <a href="pet_details.php?pet_id=<?php echo htmlspecialchars($vaccination['pet_id']); ?>" class="btn btn-info">View</a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="background-color: white;">No upcoming vaccinations this week.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Today's Vaccinations Section -->
                <div class="col-md-4 vaccination-section">
                    <h3 class="text-warning">Today</h3>
                    <div class="list-group">
                        <?php if ($todays_vaccinations): ?>
                            <?php foreach ($todays_vaccinations as $vaccination): ?>
                                <div class="list-group-item">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle">
                                    <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                    <p>Owner: <?php echo htmlspecialchars($vaccination['owner_name']); ?></p>
                                    <a href="pet_details.php?pet_id=<?php echo htmlspecialchars($vaccination['pet_id']); ?>" class="btn btn-info">View</a>
                                    <p>Vaccination scheduled for today.</p>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="background-color: white;">No vaccinations scheduled for today.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Missed Vaccinations Section -->
                <div class="col-md-4 vaccination-section">
                    <h3 class="text-danger">Missed</h3>
                    <div class="list-group">
                        <?php if ($missed_vaccinations): ?>
                            <?php foreach ($missed_vaccinations as $vaccination): ?>
                                <div class="list-group-item">
                                    <img src="data:image/jpeg;base64,<?php echo base64_encode($vaccination['pet_image']); ?>" alt="<?php echo htmlspecialchars($vaccination['pet_name']); ?>" class="img-thumbnail rounded-circle">
                                    <h5><?php echo htmlspecialchars($vaccination['pet_name']); ?></h5>
                                    <p>Owner: <?php echo htmlspecialchars($vaccination['owner_name']); ?></p>
                                    <p>Missed on <?php echo (new DateTime($vaccination['schedule']))->format('F j, Y'); ?>.</p>
                                    <a href="pet_details.php?pet_id=<?php echo htmlspecialchars($vaccination['pet_id']); ?>" class="btn btn-info">View</a>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="background-color: white;">No missed vaccinations.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

