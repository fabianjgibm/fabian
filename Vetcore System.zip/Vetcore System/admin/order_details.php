<?php
require "../logics/sqlcon.php";
session_start();

// Check if user is logged in
if (!isset($_SESSION['U_id'])) {
    header("Location: ../login.php");
    exit();
}
$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

$id = $_SESSION['U_id'];
if (isset($_GET['filter'])) {
    $filter = htmlspecialchars($_GET['filter']);

    // Redirect to completed_order.php if filter is 'Collected'
    if ($filter === 'Collected') {
        $page = 'completed_order.php';
    } else {
        $page = 'manage_order.php?filter=' . $filter;
    }
} else {
    // Default to 'Pending' if no filter is provided
    $page = 'manage_order.php?filter=Pending';
}
// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}

// Get order number from URL
$order_number = isset($_GET['order_number']) ? $_GET['order_number'] : '';

// Retrieve order details
$sql = "SELECT o.*, u.fname, u.lname
        FROM orders o
        JOIN users u ON o.customer_id = u.id
        WHERE o.order_number = :order_number";
$stmt = $conn->prepare($sql);
$stmt->execute([':order_number' => $order_number]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$order) {
    echo "Order not found.";
    exit();
}

// Format the order date
$order_date_time = new DateTime($order['order_date_time']);
$formatted_date = $order_date_time->format('F j, Y g:i A');

// Initialize total amount
$total_amount = 0;

// Retrieve products in the order
$sql = "SELECT p.name, p.price, p.image, o.quantity, p.image_name
        FROM orders o
        JOIN product p ON o.product_id = p.id
        WHERE o.order_number = :order_number";
$stmt = $conn->prepare($sql);
$stmt->execute([':order_number' => $order_number]);
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Order Details</title>
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .sidebar {
            width: 200px;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            padding-top: 0;
        }

        .sidebar img {
            max-width: 100px;
            border-radius: 50%;
        }

        .sidebar h4 {
            margin-top: 10px;
            font-size: 1.5rem;
        }

        .nav-link:hover {
            background-color: #007e3a;
        }

        .content {
            margin-left: 300px;
            padding: 20px;
            width: 70%;
        }

        /* Card styling */
        .product-card {
            width: 180px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            text-align: center;
            margin-bottom: 20px;
        }

        .product-card img {
            border-radius: 8px 8px 0 0;
            object-fit: cover;
            height: 150px;
        }

        .product-card .card-body {
            padding: 10px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .product-card .card-body h5 {
            margin-bottom: auto;
        }

        .product-quantity {
            background-color: #f8f9fa;
            padding: 10px;
            font-size: 14px;
            border-top: 1px solid #ddd;
            border-radius: 0 0 8px 8px;
        }

        /* Flexbox container for products and order details */
        .order-container {
            display: flex;
            gap: 20px; /* Space between products and order details */
        }

        .product-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            flex: 1; /* Allow the product container to grow */
        }

        .order-details {
            width: 300px; /* Adjust the width as needed */
            text-align: left;
            margin-top: -55px;
            height: 40%;
            margin-right: -130px;

        }

        .details-row {
            display: flex;
            justify-content: space-between;
        }

        .total-amount {
            font-weight: bold;
            text-align: center;
        }
        .t1{
            font-size: 2em;
            font-weight: bold;
            color: white;
            text-align: center;
            background-color: #28a745;
            border-radius: 8px;
            margin-top: 20px;
            height: 47px;
            width: 66.3%;
        }
        .custom-container {
            margin-left: -100px; /* Adjust the value as needed */
            width: 100%;
        }
        .color1{
            background-color: white;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="container mt-6 me-n3 custom-container">
        <div class="mb-4">
            <a href="<?php echo $page; ?>" class="btn btn-primary">Back to Orders</a>
        </div>

            <h3 class="t1">Ordered Products:</h3>
            <div class="order-container"> <!-- Flexbox container for products and order details -->
                <div class="product-container">
                    <?php
                    // Initialize total amount
                    $total_amount = 0;

                    // Display ordered products
                    foreach ($products as $product) {
                        // Calculate total amount for each product
                        $total_amount += $product['price'] * $product['quantity'];
                    ?>
                    <div class="product-card">
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($product['image']); ?>" 
                             alt="<?php echo htmlspecialchars($product['image_name']); ?>" 
                             class="card-img-top">
                        <div class="card-body color1">
                            <h5 class="card-title"><?php echo htmlspecialchars($product['name']); ?></h5>
                        </div>
                        <div class="product-quantity">
                            <p>Quantity: <?php echo htmlspecialchars($product['quantity']); ?></p>
                        </div>
                    </div>
                    <?php
                    }
                    ?>
                </div>

                <div class="order-details card ">
                    <div class="card-header bg-success text-white">
                        <h4 class="card-title mb-1">Order Details</h4>
                    </div>
                    <div class="card-body">
                                <p><strong>Order Number:<br></strong> <?php echo htmlspecialchars($order['order_number']); ?></p>
                                <p><strong>Order Status:<br></strong> <?php echo htmlspecialchars($order['order_status']); ?></p>
                                <p><strong>Order Status:<br></strong> <?php echo htmlspecialchars($order['payment_option']); ?></p>
                                <p><strong>Customer Name:<br></strong> <?php echo htmlspecialchars($order['fname'] . ' ' . $order['lname']); ?></p>
                                <p><strong>Order Date:<br></strong> <?php echo htmlspecialchars($formatted_date); ?></p>
                        <div class="total-amount text-center">
                            <p class="h5"><strong>Total Amount:<br></strong> ₱<?php echo htmlspecialchars($total_amount); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
