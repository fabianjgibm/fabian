<?php
require "../logics/sqlcon.php";
require "../logics/audit_trail.php"; 
session_start();

$id = $_SESSION['U_id'];

// Retrieve user information
$sql = "SELECT * FROM users WHERE id = :id";
$stmt = $conn->prepare($sql);
$stmt->execute([':id' => $id]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if ($result) {
    $_SESSION['U_id'] = $result['id'];
    $_SESSION['U_type'] = $result['user_type'];
    $fname = $result['fname'];
    $lname = $result['lname'];
} else {
    header("Location: ../login.php");
    exit();
}
// Check if the product ID is set in the URL
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch the product details based on the product ID
    $sql = "SELECT id, name, image, price, expiration, stock_limit FROM product WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$product_id]);
    $product = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the product exists
    if (!$product) {
        echo "<script>alert('Product not found.'); window.location.href='manage_stock.php';</script>";
        exit;
    }
}

// Rest of your existing code...
if (isset($_POST['add_stock'])) {
    $product_id = $_POST['product_id'];
    $expiration_date = $_POST['expiration_date'] ?? null; // Use null if not set
    $stock = $_POST['stock'];
    $status = "In inventory";

    // Validate stock
    if ($stock < 0) {
        echo "<script>alert('Stock cannot be negative.');</script>";
    } else {
        // Get the current date details
        $currentDate = new DateTime();
        $year = $currentDate->format('y'); // Last two digits of the year
        $monthLetter = $currentDate->format('F')[0]; // First letter of the month
        $dayOfMonth = $currentDate->format('d'); // Day of the month
        $daySuffix = $currentDate->format('D'); // Short day name (e.g., Mon, Tue)

        // Convert the day suffix to a two-letter code
        $dayMap = [
            'Mon' => 'MO',
            'Tue' => 'TU',
            'Wed' => 'WE',
            'Thu' => 'TH',
            'Fri' => 'FR',
            'Sat' => 'SA',
            'Sun' => 'SU'
        ];
        $dayCode = $dayMap[$daySuffix]; // Get the two-letter code for the day

        // Count how many products have been added today
        $sqlCount = "SELECT COUNT(*) FROM product_detail 
                     WHERE DATE(added_date) = CURDATE() AND product_id = ?";
        $countStmt = $conn->prepare($sqlCount);
        $countStmt->execute([$product_id]);
        $count = $countStmt->fetchColumn() + 1; // Increment for new code

        // Generate the product code in the format YYMDDN (YY - year, M - month, DD - day, N - counter)
        $product_code = sprintf('%s%s%s%02d%d', $year, $monthLetter, $dayCode, $dayOfMonth, $count);

        // Check if the product code already exists and increment if necessary
        $sqlCheck = "SELECT COUNT(*) FROM product_detail WHERE product_code = ?";
        do {
            $checkCode = sprintf('%s%s%s%02d%d', $year, $monthLetter, $dayCode, $dayOfMonth, $count);
            $countStmt = $conn->prepare($sqlCheck);
            $countStmt->execute([$checkCode]);
            $exists = $countStmt->fetchColumn();

            if ($exists) {
                $count++; // Increment the count if the code exists
            }
        } while ($exists);

        // Check total remaining stock for the product, excluding expired items and counting items with no expiration date
        $sqlTotalStock = "SELECT SUM(remaining_stock) 
                          FROM product_detail 
                          WHERE product_id = ? 
                          AND (expiration_date > NOW() OR expiration_date = '0000-00-00' OR expiration_date IS NULL)";
        $totalStockStmt = $conn->prepare($sqlTotalStock);
        $totalStockStmt->execute([$product_id]);
        $totalRemainingStock = $totalStockStmt->fetchColumn();

        // Fetch the stock limit from the product table
        $sqlLimit = "SELECT stock_limit FROM product WHERE id = ?";
        $limitStmt = $conn->prepare($sqlLimit);
        $limitStmt->execute([$product_id]);
        $stockLimit = $limitStmt->fetchColumn();

        // Check if adding the new stock exceeds the stock limit
        if ($totalRemainingStock + $stock > $stockLimit) {
            echo "<script>alert('Cannot add stock. Total remaining stock would exceed the stock limit of $stockLimit.');</script>";
        } else {
            // Insert the stock with the new product code
            if ($expiration_date) {
                // If expiration date is provided
                $sqlAddStock = "INSERT INTO product_detail (product_id, product_code, stock, remaining_stock, expiration_date, storage) 
                                VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sqlAddStock);
                $stmt->execute([$product_id, $checkCode, $stock, $stock, $expiration_date, $status]);
            } else {
                // If no expiration date is provided
                $sqlAddStock = "INSERT INTO product_detail (product_id, product_code, stock, remaining_stock, storage) 
                                VALUES (?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sqlAddStock);
                $stmt->execute([$product_id, $checkCode, $stock, $stock, $status]);
            }

            // Save audit trail for adding stock
            $userID = $_SESSION['U_id']; // Get the user ID from the session
            $userType = $_SESSION['U_type']; // Get the user type from the session
            $action = "Added stock for product ID: $product_id, Stock: $stock, Product Code: $checkCode";
            save_audit_trail($userID, $action, $userType);

            $_SESSION['success'] = "Stock added successfully. Product code: $checkCode";
            header("Location: product_list.php"); // Redirect back to the manage products page
            exit();
        }
    }
}
// Close connection at the end
$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/jpg" href="../images/vetcore logo.jpg" sizes="16x16">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Add Stock</title>
    <style>
        body {
            background-image: url('../images/pawprint1.jpg'); /* Replace with your image path */
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .search-item {
            padding: 10px;
            cursor: pointer;
            border: 1px solid #ddd;
            background-color: #f9f9f9;
            margin-bottom: 5px;
            border-radius: 5px;
        }
        .search-item:hover {
            background-color: #e2e2e2;
        }
        #product_list {
            max-height: 200px;
            overflow-y: auto;
        }
        .content {
            margin-left: 300px; /* Matches the width of the sidebar */
            width: 70%;
        }
    </style>
</head>
<body>
    <?php include 'admin_navbar.php'; ?>
    <div class="content">
        <div class="container mt-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="card shadow-lg">
                        <div class="card-header bg-success text-white">
                            <h3 class="card-title">Add Stock for <?php echo htmlspecialchars($product['name']); ?></h3>
                        </div>
                        <div class="card-body">
                            <!-- Display product image -->
                            <div class="mb-3 text-center">
                                <img src='data:image/jpeg;base64,<?php echo base64_encode($product['image']); ?>' alt='Product Image' class='item-image' style='max-width: 200px; max-height: 200px;' />
                            </div>
                            <form method="post" action="add_stock.php?id=<?php echo $product_id; ?>">
                                <input type="hidden" id="selected_product_id" name="product_id" value="<?php echo $product_id; ?>" required>
                                <?php if ($product['expiration'] === 'Yes'): ?>
                                    <div class="mb-3">
                                        <label for="expiration_date" class="form-label">Expiration Date:</label>
                                        <input type="date" id="expiration_date" name="expiration_date" class="form-control" required>
                                    </div>
                                <?php endif; ?>
                                <div class="mb-3">
                                    <label for="stock" class="form-label">Stock:</label>
                                    <input type="number" id="stock" name="stock" class="form-control" required>
                                </div>
                                <button type="submit" name="add_stock" class="btn btn-primary w-100">Add Stock</button>
                            </form>
                            <div class="text-center mt-3">
                                <a href="manage_products.php" class="btn btn-secondary">Cancel</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
