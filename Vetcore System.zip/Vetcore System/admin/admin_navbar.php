<?php
$current_page = basename($_SERVER['PHP_SELF']); // Get the current page name

// Get the user type from session
$user_type = isset($_SESSION['U_type']) ? $_SESSION['U_type'] : '';

// Set navbar title based on user type
if ($user_type == 'staff') {
    $navbar_title = 'Welcome Staff';
} elseif ($user_type == 'veterinarian') {
    $navbar_title = 'Welcome Veterinarian';
} else {
    $navbar_title = 'Admin Panel';
}
?>

<div class="d-flex">
  <nav class="sidebar vh-100" style="background-color: #00a651;">
    <div class="text-center py-4">
      <!-- Logo Section -->
      <img src="../images/vetcore logo.jpg" alt="Admin Logo" class="img-fluid" style="max-width: 100px;">
      <h4 class="text-white mt-2"><?php echo $navbar_title; ?></h4>
    </div>
    <ul class="nav flex-column">
      <?php if ($user_type == 'staff' || $user_type == 'admin' || $user_type == 'veterinarian'): ?>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'dashboard.php') ? 'active' : ''; ?>" href="dashboard.php">Dashboard</a>
        </li>
      <?php endif; ?>
      <?php if ($user_type == 'admin' || $user_type == 'veterinarian' || $user_type == 'staff'): ?>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'manage_order.php' || $current_page == 'completed_order.php') ? 'active' : ''; ?>" href="manage_order.php">Manage Orders</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'view_user.php') ? 'active' : ''; ?>" href="view_user.php">View Users Info</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'manage_products.php') ? 'active' : ''; ?>" href="manage_products.php">Manage Products</a>
        </li>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'product_list.php') ? 'active' : ''; ?>" href="product_list.php">Manage Stock</a>
        </li>
        <?php if ($user_type == 'admin' || $user_type == 'veterinarian'): ?>
          <li class="nav-item">
            <a class="nav-link text-white <?php echo ($current_page == 'view_pet.php') ? 'active' : ''; ?>" href="view_pet.php">Pets & Vaccination</a>
          </li>
        <?php endif; ?>
        <li class="nav-item">
          <a class="nav-link text-white <?php echo ($current_page == 'reports.php') ? 'active' : ''; ?>" href="reports.php">Sales</a>
        </li>
      <?php endif; ?>
      <li class="nav-item">
        <a class="nav-link text-white" href="../logout.php">Logout</a>
      </li>
    </ul>
  </nav>
</div>


<!-- Inline CSS -->
<style>
  .sidebar {
    width: 200px;
    position: fixed;
    top: 0;
    left: 0;
    height: 100%;
    padding-top: 0;
  }

  .sidebar img {
    max-width: 100px; /* Adjust the size of the logo */
    border-radius: 50%; /* Makes the logo round */
  }

  .sidebar h4 {
    margin-top: 10px;
    font-size: 1.5rem;
  }

  .nav-link:hover {
    background-color: #007e3a; /* Darker shade of green for hover effect */
  }

  .nav-link.active {
    background-color: #005b2a; /* Active link color */
    font-weight: bold; /* Make active link bold */
  }
</style>
