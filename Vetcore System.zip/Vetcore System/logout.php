<?php
// logout.php
session_start();
require "logics/sqlcon.php"; // Include the database connection
require "logics/audit_trail.php"; // Include the audit trail script

// Capture the necessary session data before clearing it
if (isset($_SESSION['U_id']) && isset($_SESSION['U_type'])) {
    $userID = $_SESSION['U_id'];
    $userType = $_SESSION['U_type'];
    
    // Save the logout action in the audit trail
    save_audit_trail($userID, "User logged out", $userType);
}

session_unset(); // Clear all session variables
session_destroy(); // Destroy the session

header("Location: login.php"); // Redirect to the login page
exit();
?>
